import { describe, expect, it } from "vitest";
import { scoreV1, type AmazonKeywordEvidence, type GoogleKeyword, type ScoreInput } from "./score_v1";

const NICHE = "indoor herb garden";
const months = (vals: number[]) => vals.map((v, i) => ({ year: 2025 + Math.floor(i / 12), month: (i % 12) + 1, search_volume: v }));
const flat = (v: number) => months(Array(12).fill(v));

function google(volume: number, cpc: number, history = flat(volume)): GoogleKeyword[] {
  return [
    { keyword: "indoor herb garden", search_volume: volume, cpc, competition: "HIGH", competition_index: 80, monthly_searches: history },
    { keyword: "indoor herb garden kit", search_volume: Math.round(volume / 2), cpc, competition: "HIGH", competition_index: 80, monthly_searches: history.map((m) => ({ ...m, search_volume: Math.round(m.search_volume / 2) })) },
    { keyword: "best indoor herb garden", search_volume: Math.round(volume / 4), cpc, competition: "HIGH", competition_index: 70, monthly_searches: null },
    { keyword: "herb garden indoor ideas", search_volume: Math.round(volume / 5), cpc: cpc / 2, competition: "LOW", competition_index: 20, monthly_searches: null },
  ];
}
function amazon(strong: boolean, bought: number | null = 500): AmazonKeywordEvidence[] {
  const n = strong ? 60 : 8;
  return ["indoor herb garden kit", "indoor herb garden"].map((keyword) => ({
    keyword,
    results_count: strong ? 200000 : 400,
    products: Array.from({ length: n }, () => ({ relevant: true, bought_past_month: bought })),
    metrics: {
      relevant_product_count: n,
      paid_result_ratio: strong ? 0.45 : 0.05,
      median_rating: strong ? 4.6 : 3.9,
      median_review_count: strong ? 8000 : 15,
      amazon_choice_count: strong ? 4 : 0,
      best_seller_count: strong ? 3 : 0,
      strong_competitor_ratio: strong ? 0.7 : 0.0,
      products_with_bought_past_month: bought === null ? 0 : n,
    },
  }));
}
const input = (g: GoogleKeyword[] | null, a: AmazonKeywordEvidence[] | null): ScoreInput => ({ niche: NICHE, google: g, amazon: a });

describe("score_v1", () => {
  it("A. low demand / strong competition -> low score", () => {
    const r = scoreV1(input(google(80, 0.3), amazon(true)));
    expect(r.opportunity_score_display!).toBeLessThan(40);
  });
  it("B. high demand / weak competition -> high score", () => {
    const r = scoreV1(input(google(60000, 3), amazon(false)));
    expect(r.opportunity_score_display!).toBeGreaterThanOrEqual(75);
  });
  it("C. high demand / strong competition -> strong demand, reduced final", () => {
    const strong = scoreV1(input(google(60000, 3), amazon(true)));
    const weak = scoreV1(input(google(60000, 3), amazon(false)));
    expect(strong.components.demand.score!).toBeGreaterThan(85);
    expect(strong.components.competition.score!).toBeLessThan(35);
    expect(strong.opportunity_score!).toBeLessThan(weak.opportunity_score! - 10);
  });
  it("D. low demand / weak competition -> constrained by demand", () => {
    const r = scoreV1(input(google(80, 0.3), amazon(false)));
    expect(r.components.competition.score!).toBeGreaterThan(70);
    expect(r.opportunity_score_display!).toBeLessThan(60);
  });
  it("E. seasonal spike is not exceptional", () => {
    const hist = months([100, 100, 100, 100, 100, 100, 100, 100, 100, 150, 600, 900]);
    const r = scoreV1(input(google(1000, 1, hist), amazon(false)));
    expect(r.components.trend.inputs["trend_classification"]).toBe("seasonal");
    expect(r.components.trend.score!).toBeLessThanOrEqual(65);
  });
  it("F. declining niche -> low trend", () => {
    const hist = months([2000, 2000, 2000, 2000, 2000, 2000, 1900, 1900, 1800, 1000, 900, 800]);
    const r = scoreV1(input(google(1000, 1, hist), amazon(false)));
    expect(r.components.trend.inputs["trend_classification"]).toBe("declining");
    expect(r.components.trend.score!).toBeLessThan(30);
  });
  it("G. missing Amazon purchase signal is reweighted, not zero", () => {
    const r = scoreV1(input(google(5000, 2), amazon(false, null)));
    const pi = r.components.purchase_intent;
    expect(pi.status).toBe("ok");
    expect(pi.sub_scores!["marketplace_purchase"]!.score).toBeNull();
    expect(pi.sub_scores!["marketplace_purchase"]!.effective_weight).toBe(0);
    expect(pi.reweighted).toBe(true);
    const cpc = pi.sub_scores!["cpc"]!, com = pi.sub_scores!["commercial_keywords"]!;
    expect(pi.score!).toBeCloseTo((cpc.score! * 0.35 + com.score! * 0.25) / 0.6, 1);
  });
  it("H. missing all Amazon data -> competition insufficient", () => {
    const r = scoreV1(input(google(5000, 2), null));
    expect(r.components.competition.status).toBe("insufficient_data");
    expect(r.components.competition.score).toBeNull();
  });
  it("I. insufficient overall evidence -> no final score", () => {
    const r = scoreV1(input(null, amazon(false)));
    expect(r.opportunity_score).toBeNull();
    expect(r.classification).toBe("Insufficient data");
    expect(r.confidence).toBe("insufficient");
  });
  it("J. deterministic", () => {
    const i = input(google(4321, 1.7), amazon(true));
    const runs = Array.from({ length: 5 }, () => JSON.stringify(scoreV1(i)));
    expect(new Set(runs).size).toBe(1);
  });
});
