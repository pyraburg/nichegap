// NicheGap Opportunity Score engine — score_v1.
// Pure, deterministic functions: same evidence in -> same score out.
// All weights, anchors and thresholds live in SCORE_V1_CONFIG.
// Authoritative scoring runs server-side only (see scoring.functions.ts).

export const SCORE_VERSION = "score_v1";

export const SCORE_V1_CONFIG = {
  weights: { demand: 0.4, competition: 0.25, purchase_intent: 0.2, trend: 0.15 },
  demand: {
    keyword_weights: [1, 0.5, 0.35, 0.25, 0.15],
    // [monthly searches, score] — interpolated on log10(volume).
    anchors: [[1, 0], [100, 20], [500, 35], [1000, 45], [5000, 65], [10000, 75], [50000, 90], [100000, 97], [1000000, 100]] as Array<[number, number]>,
  },
  competition: {
    sub_weights: { saturation: 0.35, strength: 0.45, paid_pressure: 0.2 },
    saturation_mix: { relevant_products: 0.6, results_count: 0.4 },
    relevant_products_anchors: [[0, 100], [10, 85], [25, 65], [50, 35], [80, 15], [120, 5]] as Array<[number, number]>,
    results_count_anchors_log: [[10, 100], [1000, 80], [10000, 55], [100000, 30], [1000000, 10]] as Array<[number, number]>,
    strength_mix: { reviews: 0.35, strong_ratio: 0.3, rating: 0.2, badges: 0.15 },
    reviews_anchors_log: [[1, 100], [10, 85], [100, 60], [1000, 30], [10000, 10], [100000, 0]] as Array<[number, number]>,
    rating_anchors: [[3.5, 85], [3.8, 75], [4.0, 65], [4.3, 45], [4.6, 25], [4.8, 15], [5, 10]] as Array<[number, number]>,
    badge_ratio_multiplier: 200, // opp = 100 - badge_ratio*200
    paid_ratio_multiplier: 150, // opp = 100 - paid_ratio*150
    min_sub_scores: 2,
  },
  purchase_intent: {
    sub_weights: { cpc: 0.35, commercial_keywords: 0.25, marketplace_purchase: 0.4 },
    cpc_anchors: [[0, 0], [0.25, 15], [0.5, 30], [1, 50], [2, 70], [4, 85], [8, 97], [16, 100]] as Array<[number, number]>,
    cpc_keyword_sample: 20,
    commercial_modifiers: ["best", "buy", "kit", "system", "starter", "set", "price", "review", "reviews", "top", "for sale", "with", "under", "cheap", "deal"],
    commercial_full_score_share: 0.4, // 40%+ commercial keywords -> 100
    purchase_anchors_log: [[1, 5], [100, 30], [1000, 55], [5000, 75], [20000, 90], [100000, 100]] as Array<[number, number]>,
    min_sub_scores: 2,
  },
  trend: {
    min_months: 6,
    seasonal_ratio: 1.5, // peak >= 1.5x 12-month average
    seasonal_clamp: [45, 65] as [number, number],
    growth_anchors: [[-1, 10], [-0.3, 20], [-0.1, 45], [0, 55], [0.1, 60], [0.3, 80], [1, 95]] as Array<[number, number]>,
    // The decline band starts at 30 just below -30%
  },
  bands: [
    [90, "Exceptional Signal"], [75, "Strong Opportunity"], [60, "Promising Opportunity"],
    [40, "Limited / Needs Validation"], [0, "Weak Opportunity"],
  ] as Array<[number, string]>,
  min_components: 3,
} as const;

// ---------- Evidence shapes (match research_data.processed_data) ----------
export interface GoogleKeyword {
  keyword: string;
  search_volume: number | null;
  cpc: number | null;
  competition: string | null;
  competition_index: number | null;
  monthly_searches?: Array<{ year: number; month: number; search_volume: number | null }> | null;
}
export interface AmazonKeywordEvidence {
  keyword: string;
  results_count: number | null;
  products: Array<{ relevant: boolean; bought_past_month: number | null; review_count?: number | null; rating?: number | null }>;
  metrics: {
    relevant_product_count: number;
    paid_result_ratio: number | null;
    median_rating: number | null;
    median_review_count: number | null;
    amazon_choice_count: number;
    best_seller_count: number;
    strong_competitor_ratio: number | null;
    products_with_bought_past_month: number;
  };
}
export interface ScoreInput {
  niche: string;
  google: GoogleKeyword[] | null;
  amazon: AmazonKeywordEvidence[] | null;
}

export interface Explanation { code: string; text: string; facts: Record<string, unknown> }
export interface SubScore { score: number | null; weight: number; effective_weight: number; inputs: Record<string, unknown>; missing?: boolean }
export interface Component {
  confidence?: "high" | "medium" | "low" | "insufficient";
  status: "ok" | "insufficient_data";
  score: number | null;
  weight: number;
  sub_scores?: Record<string, SubScore>;
  inputs: Record<string, unknown>;
  reweighted: boolean;
  missing: string[];
  explanation: Explanation;
}
export interface ScoreResult {
  score_version: string;
  opportunity_score: number | null; // high precision
  opportunity_score_display: number | null;
  classification: string;
  confidence: "high" | "medium" | "low" | "insufficient";
  evidence_completeness_percent: number;
  evidence_categories: Record<string, boolean>;
  components: { demand: Component; competition: Component; purchase_intent: Component; trend: Component };
  weights: typeof SCORE_V1_CONFIG.weights;
  effective_weights: Record<string, number>;
  missing_evidence: string[];
  reweighting: string[];
  evidence_quality_score?: number | null;
  evidence_quality_factors?: Record<string, number | null>;
  config?: unknown;
}

// ---------- helpers ----------
export const r2 = (n: number) => Math.round(n * 100) / 100;
export const clamp = (n: number, lo = 0, hi = 100) => Math.min(hi, Math.max(lo, n));
export const isNum = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);

export function interpolate(x: number, anchors: ReadonlyArray<readonly [number, number]>): number {
  const first = anchors[0]!, last = anchors[anchors.length - 1]!;
  if (x <= first[0]) return first[1];
  if (x >= last[0]) return last[1];
  for (let i = 1; i < anchors.length; i++) {
    const [x1, y1] = anchors[i]!; const [x0, y0] = anchors[i - 1]!;
    if (x <= x1) return y0 + ((x - x0) / (x1 - x0)) * (y1 - y0);
  }
  return last[1];
}
export function logInterpolate(x: number, anchors: ReadonlyArray<readonly [number, number]>): number {
  if (x <= 0) return anchors[0]![1] === 100 ? 100 : 0;
  return interpolate(Math.log10(Math.max(x, 1)), anchors.map(([a, b]) => [Math.log10(a), b] as [number, number]));
}

export const stem = (w: string) => w.toLowerCase().replace(/(ing|es|s)$/, "");
export const STOP = new Set(["for", "the", "and", "with", "a", "an", "of", "to", "in", "on", "best", "how", "what"]);
export function nicheWords(text: string) {
  return [...new Set(text.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2 && !STOP.has(w)).map(stem))];
}
function overlap(keyword: string, words: string[]) {
  const kw = new Set(keyword.toLowerCase().split(/[^a-z0-9]+/).map(stem));
  return words.filter((w) => kw.has(w)).length;
}
/** Relevant = shares at least min(2, |niche words|) word stems with the niche. */
export function relevantKeywords(google: GoogleKeyword[], niche: string) {
  const words = nicheWords(niche);
  const need = Math.min(2, words.length);
  return google.filter((k) => need > 0 && overlap(k.keyword, words) >= need);
}
export const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

/** Primary keyword + up to 4 strongest relevant supporting keywords. */
export function demandKeywordSet(google: GoogleKeyword[], niche: string) {
  const rel = relevantKeywords(google, niche).filter((k) => isNum(k.search_volume));
  const sorted = rel.slice().sort((a, b) => (b.search_volume! - a.search_volume!) || a.keyword.localeCompare(b.keyword));
  const exact = sorted.find((k) => norm(k.keyword) === norm(niche));
  const primary = exact ?? sorted[0];
  if (!primary) return [];
  return [primary, ...sorted.filter((k) => k !== primary).slice(0, SCORE_V1_CONFIG.demand.keyword_weights.length - 1)];
}

export function combine(subs: Record<string, { score: number | null; weight: number }>) {
  const avail = Object.entries(subs).filter(([, s]) => isNum(s.score));
  const total = avail.reduce((t, [, s]) => t + s.weight, 0);
  const out: Record<string, number> = {};
  let score = 0;
  for (const [k, s] of avail) { out[k] = s.weight / total; score += (s.score as number) * (s.weight / total); }
  return { score: avail.length ? score : null, effective: out, available: avail.length, missing: Object.keys(subs).filter((k) => !isNum(subs[k]!.score)) };
}
const insufficient = (weight: number, code: string, text: string, inputs: Record<string, unknown> = {}, missing: string[] = []): Component => ({
  status: "insufficient_data", score: null, weight, inputs, reweighted: false, missing, explanation: { code, text, facts: inputs },
});
export const mean = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null);

// ---------- components ----------
export function scoreDemand(input: ScoreInput): Component {
  const w = SCORE_V1_CONFIG.weights.demand;
  if (!input.google?.length) return insufficient(w, "no_google_evidence", "No Google keyword evidence is available.", {}, ["google_search_volume"]);
  const set = demandKeywordSet(input.google, input.niche);
  if (!set.length) return insufficient(w, "no_relevant_volume", "No relevant keyword with a measured search volume was found.", {}, ["google_search_volume"]);
  const kw = SCORE_V1_CONFIG.demand.keyword_weights;
  const contributions = set.map((k, i) => ({ keyword: k.keyword, search_volume: k.search_volume!, weight: kw[i]!, weighted: r2(k.search_volume! * kw[i]!) }));
  const weighted = contributions.reduce((t, c) => t + c.weighted, 0);
  const score = logInterpolate(weighted, SCORE_V1_CONFIG.demand.anchors);
  return {
    status: "ok", score: r2(score), weight: w, reweighted: false, missing: [],
    inputs: { weighted_search_volume: Math.round(weighted), contributions, relevant_keyword_count: relevantKeywords(input.google, input.niche).length },
    explanation: {
      code: "weighted_search_volume",
      text: `Weighted monthly search demand is approximately ${Math.round(weighted).toLocaleString("en-US")} searches across the primary keyword "${contributions[0]!.keyword}" (${contributions[0]!.search_volume.toLocaleString("en-US")}/mo) and ${contributions.length - 1} supporting keyword${contributions.length === 2 ? "" : "s"}.`,
      facts: { weighted_search_volume: Math.round(weighted), contributions },
    },
  };
}

function amazonAggregate(amazon: AmazonKeywordEvidence[]) {
  const withRel = amazon.filter((a) => a.metrics.relevant_product_count > 0);
  const pick = (f: (a: AmazonKeywordEvidence) => number | null, rows = withRel) => mean(rows.map(f).filter(isNum));
  const badgeRatios = withRel.map((a) => (a.metrics.amazon_choice_count + a.metrics.best_seller_count) / a.metrics.relevant_product_count);
  return {
    keywords: amazon.length,
    keywords_with_relevant_products: withRel.length,
    mean_relevant_product_count: mean(amazon.map((a) => a.metrics.relevant_product_count)),
    mean_results_count: pick((a) => a.results_count, amazon),
    mean_median_review_count: pick((a) => a.metrics.median_review_count),
    mean_median_rating: pick((a) => a.metrics.median_rating),
    mean_strong_competitor_ratio: pick((a) => a.metrics.strong_competitor_ratio),
    mean_badge_ratio: mean(badgeRatios),
    mean_paid_result_ratio: pick((a) => a.metrics.paid_result_ratio),
  };
}

export function scoreCompetition(input: ScoreInput): Component {
  const C = SCORE_V1_CONFIG.competition, w = SCORE_V1_CONFIG.weights.competition;
  if (!input.amazon?.length) return insufficient(w, "no_amazon_evidence", "No Amazon marketplace evidence is available.", {}, ["amazon_supply", "amazon_competitor_metrics"]);
  const a = amazonAggregate(input.amazon);

  const satParts = combine({
    relevant_products: { score: isNum(a.mean_relevant_product_count) ? interpolate(a.mean_relevant_product_count, C.relevant_products_anchors) : null, weight: C.saturation_mix.relevant_products },
    results_count: { score: isNum(a.mean_results_count) ? logInterpolate(a.mean_results_count, C.results_count_anchors_log) : null, weight: C.saturation_mix.results_count },
  });
  const strParts = combine({
    reviews: { score: isNum(a.mean_median_review_count) ? logInterpolate(a.mean_median_review_count, C.reviews_anchors_log) : null, weight: C.strength_mix.reviews },
    strong_ratio: { score: isNum(a.mean_strong_competitor_ratio) ? 100 * (1 - a.mean_strong_competitor_ratio) : null, weight: C.strength_mix.strong_ratio },
    rating: { score: isNum(a.mean_median_rating) ? interpolate(a.mean_median_rating, C.rating_anchors) : null, weight: C.strength_mix.rating },
    badges: { score: isNum(a.mean_badge_ratio) ? clamp(100 - a.mean_badge_ratio * C.badge_ratio_multiplier) : null, weight: C.strength_mix.badges },
  });
  const paid = isNum(a.mean_paid_result_ratio) ? clamp(100 - a.mean_paid_result_ratio * C.paid_ratio_multiplier) : null;

  const subsRaw = { saturation: satParts.score, strength: strParts.score, paid_pressure: paid };
  const comb = combine({
    saturation: { score: subsRaw.saturation, weight: C.sub_weights.saturation },
    strength: { score: subsRaw.strength, weight: C.sub_weights.strength },
    paid_pressure: { score: subsRaw.paid_pressure, weight: C.sub_weights.paid_pressure },
  });
  const inputs = { ...a, saturation_detail: satParts, strength_detail: strParts };
  if (comb.available < C.min_sub_scores) return insufficient(w, "too_few_competition_signals", "Not enough relevant Amazon competitor evidence to score competition.", inputs, comb.missing);

  const sub_scores: Record<string, SubScore> = {};
  for (const k of Object.keys(C.sub_weights) as Array<keyof typeof C.sub_weights>) {
    const s = subsRaw[k];
    sub_scores[k] = { score: isNum(s) ? r2(s) : null, weight: C.sub_weights[k], effective_weight: r2(comb.effective[k] ?? 0), inputs: {}, missing: !isNum(s) };
  }
  const score = comb.score!;
  const supply = (a.mean_relevant_product_count ?? 0) >= 50 ? "high" : (a.mean_relevant_product_count ?? 0) >= 20 ? "moderate" : "low";
  const strength = (strParts.score ?? 50) < 35 ? "dominated by established, heavily reviewed competitors" : (strParts.score ?? 50) < 60 ? "a mix of established competitors and lower-review products" : "mostly lower-review, less established products";
  return {
    status: "ok", score: r2(score), weight: w, sub_scores, inputs,
    reweighted: comb.missing.length > 0 || strParts.missing.length > 0 || satParts.missing.length > 0,
    missing: [...comb.missing, ...strParts.missing.map((m) => `strength.${m}`), ...satParts.missing.map((m) => `saturation.${m}`)],
    explanation: {
      code: "marketplace_competition",
      text: `Marketplace supply is ${supply} (about ${Math.round(a.mean_relevant_product_count ?? 0)} relevant products per search across ${a.keywords} Amazon searches), with ${strength}${isNum(a.mean_paid_result_ratio) ? `; ${Math.round(a.mean_paid_result_ratio * 100)}% of results are sponsored` : ""}.`,
      facts: { supply, mean_relevant_product_count: a.mean_relevant_product_count, mean_median_review_count: a.mean_median_review_count, mean_median_rating: a.mean_median_rating, mean_strong_competitor_ratio: a.mean_strong_competitor_ratio, mean_paid_result_ratio: a.mean_paid_result_ratio },
    },
  };
}

export function isCommercial(keyword: string) {
  const k = ` ${keyword.toLowerCase()} `;
  return SCORE_V1_CONFIG.purchase_intent.commercial_modifiers.some((m) => k.includes(` ${m} `));
}

export function scorePurchaseIntent(input: ScoreInput): Component {
  const P = SCORE_V1_CONFIG.purchase_intent, w = SCORE_V1_CONFIG.weights.purchase_intent;
  const rel = input.google ? relevantKeywords(input.google, input.niche) : [];

  // A. CPC — search-volume weighted mean CPC of the top relevant keywords.
  const cpcSample = rel.filter((k) => isNum(k.cpc) && isNum(k.search_volume) && k.search_volume! > 0)
    .sort((a, b) => (b.search_volume! - a.search_volume!) || a.keyword.localeCompare(b.keyword)).slice(0, P.cpc_keyword_sample);
  const volSum = cpcSample.reduce((t, k) => t + k.search_volume!, 0);
  const weightedCpc = cpcSample.length ? cpcSample.reduce((t, k) => t + k.cpc! * k.search_volume!, 0) / volSum : null;
  const cpcScore = isNum(weightedCpc) ? interpolate(weightedCpc, P.cpc_anchors) : null;

  // B. Commercial keyword share among relevant keywords.
  const commercial = rel.filter((k) => isCommercial(k.keyword));
  const share = rel.length ? commercial.length / rel.length : null;
  const commercialScore = isNum(share) ? clamp((share / P.commercial_full_score_share) * 100) : null;

  // C. Marketplace purchase activity — absent bought_past_month is unknown, not zero.
  let purchaseScore: number | null = null;
  const perKw: Array<{ keyword: string; known_products: number; bought_past_month_total: number }> = [];
  for (const a of input.amazon ?? []) {
    const known = a.products.filter((p) => p.relevant && isNum(p.bought_past_month));
    if (known.length) perKw.push({ keyword: a.keyword, known_products: known.length, bought_past_month_total: known.reduce((t, p) => t + (p.bought_past_month as number), 0) });
  }
  if (perKw.length) purchaseScore = mean(perKw.map((k) => logInterpolate(k.bought_past_month_total, P.purchase_anchors_log)));

  const comb = combine({
    cpc: { score: cpcScore, weight: P.sub_weights.cpc },
    commercial_keywords: { score: commercialScore, weight: P.sub_weights.commercial_keywords },
    marketplace_purchase: { score: purchaseScore, weight: P.sub_weights.marketplace_purchase },
  });
  const inputs = {
    weighted_cpc: isNum(weightedCpc) ? r2(weightedCpc) : null, cpc_keywords_used: cpcSample.length,
    relevant_keywords: rel.length, commercial_keywords: commercial.length, commercial_share: isNum(share) ? r2(share) : null,
    commercial_examples: commercial.slice(0, 5).map((k) => k.keyword), marketplace_purchase: perKw,
  };
  if (comb.available < P.min_sub_scores) return insufficient(w, "too_few_intent_signals", "Not enough commercial evidence to score purchase intent.", inputs, comb.missing);

  const vals = { cpc: cpcScore, commercial_keywords: commercialScore, marketplace_purchase: purchaseScore };
  const sub_scores: Record<string, SubScore> = {};
  for (const k of Object.keys(P.sub_weights) as Array<keyof typeof P.sub_weights>) {
    const s = vals[k];
    sub_scores[k] = { score: isNum(s) ? r2(s) : null, weight: P.sub_weights[k], effective_weight: r2(comb.effective[k] ?? 0), inputs: {}, missing: !isNum(s) };
  }
  const parts = [
    isNum(weightedCpc) ? `weighted CPC is $${weightedCpc.toFixed(2)}` : "CPC unavailable",
    isNum(share) ? `${Math.round(share * 100)}% of ${rel.length} relevant keywords carry commercial modifiers` : null,
    perKw.length ? `${perKw.reduce((t, k) => t + k.known_products, 0)} Amazon products show "bought in past month" activity (${perKw.reduce((t, k) => t + k.bought_past_month_total, 0).toLocaleString("en-US")}+ purchases)` : "Amazon purchase activity unavailable (reweighted)",
  ].filter(Boolean);
  return {
    status: "ok", score: r2(comb.score!), weight: w, sub_scores, inputs,
    reweighted: comb.missing.length > 0, missing: comb.missing,
    explanation: { code: "purchase_intent", text: `${parts.join("; ")}.`.replace(/^./, (c) => c.toUpperCase()), facts: inputs },
  };
}

export function monthlySeries(keywords: GoogleKeyword[]) {
  const map = new Map<string, { year: number; month: number; total: number }>();
  for (const k of keywords) for (const m of k.monthly_searches ?? []) {
    if (!isNum(m.search_volume) || !isNum(m.year) || !isNum(m.month)) continue;
    const key = `${m.year}-${String(m.month).padStart(2, "0")}`;
    const e = map.get(key) ?? { year: m.year, month: m.month, total: 0 };
    e.total += m.search_volume; map.set(key, e);
  }
  return [...map.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, v]) => ({ key, ...v }));
}

export function scoreTrend(input: ScoreInput): Component {
  const T = SCORE_V1_CONFIG.trend, w = SCORE_V1_CONFIG.weights.trend;
  const set = input.google ? demandKeywordSet(input.google, input.niche) : [];
  const series = monthlySeries(set);
  if (series.length < T.min_months) return insufficient(w, "insufficient_history", `Only ${series.length} months of search history available (need ${T.min_months}).`, { months: series.length, classification: "insufficient_data" }, ["monthly_search_history"]);

  const last = series.slice(-3), prev = series.slice(-6, -3);
  const recent = mean(last.map((s) => s.total))!, previous = mean(prev.map((s) => s.total))!;
  const year = series.slice(-12);
  const avg12 = mean(year.map((s) => s.total))!;
  const peak = year.reduce((a, b) => (b.total > a.total ? b : a));
  const low = year.reduce((a, b) => (b.total < a.total ? b : a));
  const seasonality = avg12 > 0 ? peak.total / avg12 : null;
  const growth = previous > 0 ? (recent - previous) / previous : recent > 0 ? 1 : 0;

  let score = interpolate(growth, T.growth_anchors);
  let classification = growth < -0.1 ? "declining" : growth > 0.1 ? "growing" : "stable";
  let seasonal_adjustment: string | null = null;
  const peakInWindow = [...last, ...prev].some((s) => s.key === peak.key);
  if (isNum(seasonality) && seasonality >= T.seasonal_ratio && peakInWindow) {
    const before = score;
    score = clamp(score, T.seasonal_clamp[0], T.seasonal_clamp[1]);
    classification = "seasonal";
    seasonal_adjustment = `Peak month ${peak.key} is ${seasonality.toFixed(2)}x the 12-month average and falls inside the comparison window; score clamped from ${r2(before)} to ${r2(score)}.`;
  }
  const inputs = {
    months: series.length, recent_average: Math.round(recent), previous_average: Math.round(previous),
    growth_rate: r2(growth), twelve_month_average: Math.round(avg12), peak_month: { month: peak.key, volume: peak.total },
    lowest_month: { month: low.key, volume: low.total }, seasonality_ratio: isNum(seasonality) ? r2(seasonality) : null,
    trend_classification: classification, seasonal_adjustment, series: series.map((s) => ({ month: s.key, volume: s.total })),
  };
  return {
    status: "ok", score: r2(score), weight: w, inputs, reweighted: false, missing: [],
    explanation: {
      code: `trend_${classification}`,
      text: `Search interest is ${classification}: the latest 3 months average ${Math.round(recent).toLocaleString("en-US")} vs ${Math.round(previous).toLocaleString("en-US")} in the prior 3 months (${growth >= 0 ? "+" : ""}${Math.round(growth * 100)}%). Peak/average ratio is ${isNum(seasonality) ? seasonality.toFixed(2) : "n/a"}.${seasonal_adjustment ? " Seasonal peak detected, so the score is not treated as permanent growth." : ""}`,
      facts: inputs,
    },
  };
}

export function classify(score: number) {
  return SCORE_V1_CONFIG.bands.find(([min]) => score >= min)![1];
}

export function evidenceCategories(input: ScoreInput) {
  const rel = input.google ? relevantKeywords(input.google, input.niche) : [];
  const set = input.google ? demandKeywordSet(input.google, input.niche) : [];
  const am = input.amazon ?? [];
  return {
    google_search_volume: set.length > 0,
    google_cpc: rel.some((k) => isNum(k.cpc)),
    google_competition: rel.some((k) => isNum(k.competition_index) || !!k.competition),
    monthly_search_history: monthlySeries(set).length >= SCORE_V1_CONFIG.trend.min_months,
    amazon_supply: am.length > 0,
    amazon_competitor_metrics: am.some((a) => isNum(a.metrics.median_review_count) || isNum(a.metrics.median_rating)),
    amazon_purchase_activity: am.some((a) => a.products.some((p) => p.relevant && isNum(p.bought_past_month))),
  };
}

export function scoreV1(input: ScoreInput): ScoreResult {
  const components = {
    demand: scoreDemand(input), competition: scoreCompetition(input),
    purchase_intent: scorePurchaseIntent(input), trend: scoreTrend(input),
  };
  const cats = evidenceCategories(input);
  const completeness = r2((Object.values(cats).filter(Boolean).length / Object.keys(cats).length) * 100);
  const avail = Object.entries(components).filter(([, c]) => c.status === "ok");
  const reweighting: string[] = [];
  for (const [k, c] of Object.entries(components)) if (c.reweighted) reweighting.push(`${k}: missing ${c.missing.join(", ")} — remaining sub-scores reweighted proportionally`);

  let final: number | null = null;
  const effective: Record<string, number> = {};
  if (avail.length >= SCORE_V1_CONFIG.min_components) {
    const tw = avail.reduce((t, [, c]) => t + c.weight, 0);
    final = 0;
    for (const [k, c] of avail) { effective[k] = r2(c.weight / tw); final += c.score! * (c.weight / tw); }
    final = clamp(final);
    if (avail.length < 4) reweighting.push(`final: ${Object.keys(components).filter((k) => !effective[k]).join(", ")} insufficient — remaining component weights reweighted proportionally`);
  }
  let confidence: ScoreResult["confidence"] = "insufficient";
  if (final !== null) {
    if (avail.length === 4 && completeness >= 85) confidence = "high";
    else if ((avail.length === 4 && completeness >= 60) || completeness >= 70) confidence = "medium";
    else confidence = "low";
  }
  return {
    score_version: SCORE_VERSION,
    opportunity_score: final === null ? null : Math.round(final * 10000) / 10000,
    opportunity_score_display: final === null ? null : Math.round(final),
    classification: final === null ? "Insufficient data" : classify(Math.round(final)),
    confidence, evidence_completeness_percent: completeness, evidence_categories: cats,
    components, weights: SCORE_V1_CONFIG.weights, effective_weights: effective,
    missing_evidence: Object.entries(cats).filter(([, v]) => !v).map(([k]) => k), reweighting,
  };
}
