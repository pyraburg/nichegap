import { describe, expect, it } from "vitest";
import { scoreV1_1, clusterKeywords, type AmazonKeywordEvidenceV11, type AmazonProductV11 } from "./score_v1_1";
import type { GoogleKeyword } from "./score_v1";

const NICHE = "indoor herb garden";
const hist = (vals: number[]) => vals.map((v, i) => ({ year: 2025 + Math.floor(i / 12), month: (i % 12) + 1, search_volume: v }));
const flat = (v: number) => hist(Array(12).fill(v));
const kw = (keyword: string, v: number, cpc = 1.5, h: ReturnType<typeof hist> | null = flat(v)): GoogleKeyword => ({ keyword, search_volume: v, cpc, competition: "HIGH", competition_index: 70, monthly_searches: h });

const baseGoogle = [kw("indoor herb garden", 5000), kw("indoor herb garden kit", 2000), kw("best indoor herb garden", 1500), kw("herb garden indoor planter", 900), kw("indoor herb garden with grow light", 700)];
const prod = (title: string, o: Partial<AmazonProductV11> = {}): AmazonProductV11 => ({ title, result_type: "amazon_serp", bought_past_month: 200, rating: 4.1, review_count: 40, is_amazon_choice: false, is_best_seller: false, ...o });
const onTopic = (keyword: string, n = 30, o: Partial<AmazonProductV11> = {}): AmazonKeywordEvidenceV11 => ({
  keyword, results_count: 2000, categories: null, products: Array.from({ length: n }, (_, i) => prod(`Indoor Herb Garden Kit ${i}`, o)),
});
const baseAmazon = [onTopic("indoor herb garden kit"), onTopic("indoor herb garden"), onTopic("best indoor herb garden")];

describe("score_v1_1", () => {
  it("K. near-duplicate keywords do not materially inflate demand", () => {
    const dupes = [...baseGoogle, kw("indoor herbs garden", 5000), kw("herb garden indoors", 5000), kw("inside herb garden", 5000), kw("interior herb garden", 5000)];
    const a = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: baseAmazon });
    const b = scoreV1_1({ niche: NICHE, google: dupes, amazon: baseAmazon });
    expect(b.components.demand.score! - a.components.demand.score!).toBeLessThan(2);
  });
  it("L. identical volumes across near-identical keywords are clustered", () => {
    const cl = clusterKeywords([kw("herb garden for inside", 9900), kw("inside herb garden", 9900), kw("interior herb garden", 9900), kw("herbs for indoor herb garden", 9900)]);
    expect(cl.length).toBe(1);
    expect(cl[0]!.members.length).toBe(4);
    expect(cl[0]!.representative_volume).toBe(9900);
  });
  it("M. off-topic high-sales Amazon keyword does not inflate purchase intent", () => {
    const offTopic: AmazonKeywordEvidenceV11 = { keyword: "grow light for basil", results_count: 50000, categories: null, products: Array.from({ length: 60 }, (_, i) => prod(`LED Grow Light Bar ${i}`, { bought_past_month: 5000 })) };
    const a = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: baseAmazon });
    const b = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: [...baseAmazon, offTopic] });
    expect(Math.abs(b.components.purchase_intent.score! - a.components.purchase_intent.score!)).toBeLessThan(2);
  });
  it("N. off-topic heavily reviewed products do not reduce competition opportunity", () => {
    const mixed = baseAmazon.map((a) => ({ ...a, products: [...a.products, ...Array.from({ length: 30 }, (_, i) => prod(`Smart Home Speaker ${i}`, { review_count: 90000, rating: 4.8, is_best_seller: true, bought_past_month: 9000 }))] }));
    const a = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: baseAmazon });
    const b = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: mixed });
    expect(Math.abs(b.components.competition.score! - a.components.competition.score!)).toBeLessThan(3);
  });
  it("O. seasonal spike followed by decline -> possible seasonality, not structural decline", () => {
    const h = hist([400, 400, 450, 700, 1200, 1300, 900, 500, 420, 300, 310, 300]);
    const g = baseGoogle.map((k) => ({ ...k, monthly_searches: h }));
    const r = scoreV1_1({ niche: NICHE, google: g, amazon: baseAmazon });
    expect(r.components.trend.inputs["trend_classification"]).toBe("seasonal");
    expect(r.components.trend.inputs["seasonality_confidence"]).toBe("low");
    expect(r.components.trend.confidence).toBe("low");
  });
  it("P. sparse bought_past_month coverage still scores but with lower confidence/quality", () => {
    const sparse = baseAmazon.map((a) => ({ ...a, products: a.products.map((p, i) => ({ ...p, bought_past_month: i < 3 ? 200 : null })) }));
    const full = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: baseAmazon });
    const r = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: sparse });
    expect(r.components.purchase_intent.status).toBe("ok");
    expect(r.components.purchase_intent.confidence).toBe("low");
    expect(r.evidence_quality_score!).toBeLessThan(full.evidence_quality_score!);
  });
  it("Q. one outlier purchase count cannot dominate", () => {
    const outlier = baseAmazon.map((a) => ({ ...a, products: a.products.map((p, i) => ({ ...p, bought_past_month: i === 0 ? 10_000_000 : 200 })) }));
    const a = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: baseAmazon });
    const b = scoreV1_1({ niche: NICHE, google: baseGoogle, amazon: outlier });
    expect(b.components.purchase_intent.sub_scores!["marketplace_purchase"]!.score! - a.components.purchase_intent.sub_scores!["marketplace_purchase"]!.score!).toBeLessThan(5);
  });
  it("R. 100% completeness but poor-quality evidence", () => {
    const poor = [onTopic("indoor herb garden kit", 4, { bought_past_month: null }), { ...onTopic("garden hose", 30), products: Array.from({ length: 30 }, (_, i) => prod(`Garden Hose ${i}`, { bought_past_month: i === 0 ? 50 : null })) }];
    poor[0]!.products[0]!.bought_past_month = 10;
    const g = baseGoogle.slice(0, 2).map((k) => ({ ...k, monthly_searches: hist(Array(6).fill(1000)) }));
    const r = scoreV1_1({ niche: NICHE, google: g, amazon: poor });
    expect(r.evidence_completeness_percent).toBe(100);
    expect(r.evidence_quality_score!).toBeLessThan(60);
  });
  it("S. deterministic", () => {
    const i = { niche: NICHE, google: baseGoogle, amazon: baseAmazon };
    expect(new Set(Array.from({ length: 5 }, () => JSON.stringify(scoreV1_1(i)))).size).toBe(1);
  });
});
