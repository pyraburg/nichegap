// NicheGap Opportunity Score engine — score_v1_1 (evidence-quality refinement of score_v1).
// Final component weights are unchanged. score_v1 remains available and untouched.
// Everything here is deterministic; all thresholds live in SCORE_V1_1_CONFIG.
import {
  SCORE_V1_CONFIG, classify, clamp, combine, evidenceCategories, interpolate, isCommercial, isNum,
  logInterpolate, mean, monthlySeries, nicheWords, norm, r2, relevantKeywords, stem,
  type Component, type GoogleKeyword, type ScoreResult, type SubScore,
} from "./score_v1";

export const SCORE_VERSION_V1_1 = "score_v1_1";
type Conf = "high" | "medium" | "low" | "insufficient";

export const SCORE_V1_1_CONFIG = {
  base: "score_v1",
  weights: SCORE_V1_CONFIG.weights,
  clustering: {
    // Generic English token normalization (not niche-specific).
    synonyms: { indoors: "indoor", inside: "indoor", interior: "indoor", gardening: "garden", gardens: "garden", growing: "grow", grower: "grow", lights: "light", lamp: "light", lamps: "light" } as Record<string, string>,
    drop_tokens: ["for", "the", "and", "a", "an", "of", "to", "in", "on", "my", "your", "at"],
    jaccard_threshold: 0.75, // same token set after normalization => 1.0
    same_volume_jaccard_threshold: 0.5, // identical volume + moderate overlap => same cluster
  },
  amazon_keyword_relevance: {
    weights: { niche_overlap: 50, google_cluster_overlap: 35, commercial_modifier: 15 },
    top_clusters: 10,
    tiers: [[80, 1], [60, 0.75], [40, 0.4], [0, 0]] as Array<[number, number]>,
  },
  product_relevance: {
    weights: { niche_title: 60, keyword_title: 30, category: 10 },
    min_score_for_scoring: 50,
  },
  purchase: {
    cap_multiple_of_median: 5, // winsorize: each product capped at 5x the keyword's median known value
    coverage_conf: { high: 0.5, medium: 0.25 },
  },
  trend: {
    seasonal_peak_ratio: 1.4,
    seasonal_score_clamp: [45, 60] as [number, number],
    spike_score_clamp: [45, 65] as [number, number],
  },
  competition_conf: { high_products: 60, medium_products: 20, high_keywords: 3 },
  demand_conf: { high_clusters: 5, medium_clusters: 3 },
  quality_floor_for_high: 75,
} as const;

// ---------- input shapes ----------
export interface AmazonProductV11 {
  title: string | null; asin?: string | null; result_type: string | null;
  bought_past_month: number | null; rating: number | null; review_count: number | null;
  is_amazon_choice: boolean; is_best_seller: boolean; relevant?: boolean;
}
export interface AmazonKeywordEvidenceV11 { keyword: string; results_count: number | null; categories?: string[] | null; products: AmazonProductV11[] }
export interface ScoreInputV11 { niche: string; google: GoogleKeyword[] | null; amazon: AmazonKeywordEvidenceV11[] | null }

// ---------- tokens & clustering ----------
const C = SCORE_V1_1_CONFIG;
export function tokens(text: string): string[] {
  const drop = new Set<string>(C.clustering.drop_tokens);
  return [...new Set(
    text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter((t) => t && !drop.has(t))
      .map((t) => C.clustering.synonyms[t] ?? t).map((t) => C.clustering.synonyms[stem(t)] ?? stem(t)),
  )].sort();
}
const jaccard = (a: string[], b: string[]) => {
  const A = new Set(a), B = new Set(b);
  const inter = [...A].filter((x) => B.has(x)).length;
  const uni = new Set([...a, ...b]).size;
  return uni ? inter / uni : 0;
};
export interface KeywordCluster {
  representative_keyword: string; representative_volume: number; tokens: string[];
  members: Array<{ keyword: string; search_volume: number | null; similarity: number; reason: string }>;
}
export function clusterKeywords(keywords: GoogleKeyword[]): KeywordCluster[] {
  const sorted = keywords.filter((k) => isNum(k.search_volume))
    .slice().sort((a, b) => (b.search_volume! - a.search_volume!) || a.keyword.localeCompare(b.keyword));
  const clusters: KeywordCluster[] = [];
  for (const k of sorted) {
    const t = tokens(k.keyword);
    let best: { c: KeywordCluster; sim: number; reason: string } | null = null;
    for (const c of clusters) {
      const sim = jaccard(t, c.tokens);
      let reason = "";
      if (sim === 1) reason = "same normalized token set";
      else if (sim >= C.clustering.jaccard_threshold) reason = `token jaccard ${r2(sim)} >= ${C.clustering.jaccard_threshold}`;
      else if (k.search_volume === c.representative_volume && sim >= C.clustering.same_volume_jaccard_threshold) reason = `identical volume and token jaccard ${r2(sim)} >= ${C.clustering.same_volume_jaccard_threshold}`;
      if (reason && (!best || sim > best.sim)) best = { c, sim, reason };
    }
    if (best) best.c.members.push({ keyword: k.keyword, search_volume: k.search_volume, similarity: r2(best.sim), reason: best.reason });
    else clusters.push({ representative_keyword: k.keyword, representative_volume: k.search_volume!, tokens: t, members: [{ keyword: k.keyword, search_volume: k.search_volume, similarity: 1, reason: "representative (highest volume)" }] });
  }
  return clusters;
}

// ---------- relevance ----------
const share = (needles: string[], hay: string[]) => {
  if (!needles.length) return 0;
  const H = new Set(hay); return needles.filter((n) => H.has(n)).length / needles.length;
};
export function amazonKeywordRelevance(keyword: string, niche: string, topClusters: KeywordCluster[]) {
  const W = C.amazon_keyword_relevance.weights;
  const nt = tokens(niche).filter((t) => nicheWords(niche).length === 0 || t.length > 2);
  const kt = tokens(keyword);
  const nicheOverlap = share(nt, kt);
  const clusterOverlap = topClusters.length ? Math.max(...topClusters.map((c) => jaccard(kt, c.tokens))) : 0;
  const commercial = isCommercial(keyword) ? 1 : 0;
  const score = r2(nicheOverlap * W.niche_overlap + clusterOverlap * W.google_cluster_overlap + commercial * W.commercial_modifier);
  const weight = C.amazon_keyword_relevance.tiers.find(([min]) => score >= min)![1];
  return {
    keyword, amazon_keyword_relevance_score: score, weight,
    reasons: [
      `niche token overlap ${Math.round(nicheOverlap * 100)}% (x${W.niche_overlap})`,
      `best Google top-cluster similarity ${r2(clusterOverlap)} (x${W.google_cluster_overlap})`,
      commercial ? `commercial modifier present (+${W.commercial_modifier})` : "no commercial modifier",
    ],
  };
}
export function productRelevance(p: AmazonProductV11, niche: string, keyword: string, categories: string[] | null | undefined) {
  const W = C.product_relevance.weights;
  const tt = tokens(p.title ?? "");
  const nt = tokens(niche).filter((t) => t.length > 2);
  const kt = tokens(keyword).filter((t) => t.length > 2);
  const catTokens = tokens((categories ?? []).join(" "));
  const catHit = categories?.length ? (share(nt, catTokens) > 0 ? 1 : 0) : null;
  // Missing category is unknown: reweight title signals to 100.
  const raw = share(nt, tt) * W.niche_title + share(kt, tt) * W.keyword_title + (catHit ?? 0) * W.category;
  const score = r2(catHit === null ? (raw / (W.niche_title + W.keyword_title)) * 100 : raw);
  return { product_relevance_score: score, relevant_for_scoring: score >= C.product_relevance.min_score_for_scoring };
}

const median = (xs: number[]) => {
  if (!xs.length) return null;
  const s = xs.slice().sort((a, b) => a - b); const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
};
const wmean = (pairs: Array<[number | null, number]>) => {
  const v = pairs.filter(([x, w]) => isNum(x) && w > 0) as Array<[number, number]>;
  const tw = v.reduce((t, [, w]) => t + w, 0);
  return tw ? v.reduce((t, [x, w]) => t + x * w, 0) / tw : null;
};
const insufficient = (weight: number, code: string, text: string, inputs: Record<string, unknown> = {}, missing: string[] = []): Component => ({
  status: "insufficient_data", score: null, weight, inputs, reweighted: false, missing, confidence: "insufficient", explanation: { code, text, facts: inputs },
});
const confRank: Record<Conf, number> = { insufficient: 0, low: 1, medium: 2, high: 3 };
const minConf = (...cs: Conf[]) => cs.reduce((a, b) => (confRank[b] < confRank[a] ? b : a));

// ---------- prepared evidence ----------
function prepare(input: ScoreInputV11) {
  const rel = input.google ? relevantKeywords(input.google, input.niche) : [];
  const clusters = clusterKeywords(rel);
  const top = clusters.slice(0, C.amazon_keyword_relevance.top_clusters);
  const amazon = (input.amazon ?? []).map((a) => {
    const kr = amazonKeywordRelevance(a.keyword, input.niche, top);
    const products = a.products.map((p) => ({ ...p, ...productRelevance(p, input.niche, a.keyword, a.categories) }));
    const scoring = products.filter((p) => p.relevant_for_scoring);
    return { ...a, kr, products, scoring };
  });
  return { rel, clusters, amazon };
}

// ---------- components ----------
function demand(input: ScoreInputV11, prep: ReturnType<typeof prepare>): Component {
  const w = C.weights.demand;
  if (!input.google?.length) return insufficient(w, "no_google_evidence", "No Google keyword evidence is available.", {}, ["google_search_volume"]);
  if (!prep.clusters.length) return insufficient(w, "no_relevant_volume", "No relevant keyword with a measured search volume was found.", {}, ["google_search_volume"]);
  const kw = SCORE_V1_CONFIG.demand.keyword_weights;
  const exact = prep.clusters.find((c) => c.members.some((m) => norm(m.keyword) === norm(input.niche)));
  const primary = exact ?? prep.clusters[0]!;
  const used = [primary, ...prep.clusters.filter((c) => c !== primary).slice(0, kw.length - 1)];
  const contributions = used.map((c, i) => ({ cluster: c.representative_keyword, representative_volume: c.representative_volume, members: c.members.length, weight: kw[i]!, weighted: r2(c.representative_volume * kw[i]!) }));
  const weighted = contributions.reduce((t, c) => t + c.weighted, 0);
  const score = logInterpolate(weighted, SCORE_V1_CONFIG.demand.anchors);
  const confidence: Conf = used.length >= C.demand_conf.high_clusters ? "high" : used.length >= C.demand_conf.medium_clusters ? "medium" : "low";
  const merged = prep.rel.filter((k) => isNum(k.search_volume)).length - prep.clusters.length;
  return {
    status: "ok", score: r2(score), weight: w, reweighted: false, missing: [], confidence,
    inputs: {
      weighted_search_volume: Math.round(weighted), contributions,
      relevant_keyword_count: prep.rel.length, cluster_count: prep.clusters.length, keywords_merged_into_clusters: merged,
      keyword_clusters: used.map((c) => ({ representative_keyword: c.representative_keyword, representative_volume: c.representative_volume, cluster_members: c.members })),
      top_clusters_overview: prep.clusters.slice(0, 15).map((c) => ({ representative_keyword: c.representative_keyword, representative_volume: c.representative_volume, member_count: c.members.length })),
    },
    explanation: {
      code: "clustered_weighted_search_volume",
      text: `Weighted monthly search demand is approximately ${Math.round(weighted).toLocaleString("en-US")} searches across ${used.length} distinct keyword clusters (primary "${primary.representative_keyword}", ${primary.representative_volume.toLocaleString("en-US")}/mo). ${merged} near-duplicate keywords were grouped so they are not counted twice.`,
      facts: { weighted_search_volume: Math.round(weighted), contributions },
    },
  };
}

function competition(input: ScoreInputV11, prep: ReturnType<typeof prepare>): Component {
  const CC = SCORE_V1_CONFIG.competition, w = C.weights.competition;
  if (!input.amazon?.length) return insufficient(w, "no_amazon_evidence", "No Amazon marketplace evidence is available.", {}, ["amazon_supply", "amazon_competitor_metrics"]);
  const included = prep.amazon.filter((a) => a.kr.weight > 0);
  const kwAudit = prep.amazon.map((a) => ({ ...a.kr, products_total: a.products.length, products_for_scoring: a.scoring.length }));
  if (!included.length) return insufficient(w, "no_relevant_amazon_keywords", "All Amazon searches were below the relevance threshold.", { amazon_keywords: kwAudit }, ["amazon_supply"]);

  const per = included.map((a) => {
    const s = a.scoring;
    const strong = s.filter((p) => (p.review_count ?? 0) >= 100 && (p.rating ?? 0) >= 4.3 && (p.bought_past_month ?? 0) > 0);
    return {
      weight: a.kr.weight, relevant_count: s.length, results_count: a.results_count,
      median_reviews: median(s.map((p) => p.review_count).filter(isNum)),
      median_rating: median(s.map((p) => p.rating).filter(isNum)),
      strong_ratio: s.length ? strong.length / s.length : null,
      badge_ratio: s.length ? s.filter((p) => p.is_amazon_choice || p.is_best_seller).length / s.length : null,
      paid_ratio: s.length ? s.filter((p) => p.result_type === "amazon_paid").length / s.length : null,
    };
  });
  const agg = (f: (x: (typeof per)[number]) => number | null) => wmean(per.map((x) => [f(x), x.weight]));
  const a = {
    mean_relevant_product_count: agg((x) => x.relevant_count), mean_results_count: agg((x) => x.results_count),
    mean_median_review_count: agg((x) => x.median_reviews), mean_median_rating: agg((x) => x.median_rating),
    mean_strong_competitor_ratio: agg((x) => x.strong_ratio), mean_badge_ratio: agg((x) => x.badge_ratio), mean_paid_result_ratio: agg((x) => x.paid_ratio),
  };
  const sat = combine({
    relevant_products: { score: isNum(a.mean_relevant_product_count) ? interpolate(a.mean_relevant_product_count, CC.relevant_products_anchors) : null, weight: CC.saturation_mix.relevant_products },
    results_count: { score: isNum(a.mean_results_count) ? logInterpolate(a.mean_results_count, CC.results_count_anchors_log) : null, weight: CC.saturation_mix.results_count },
  });
  const str = combine({
    reviews: { score: isNum(a.mean_median_review_count) ? logInterpolate(a.mean_median_review_count, CC.reviews_anchors_log) : null, weight: CC.strength_mix.reviews },
    strong_ratio: { score: isNum(a.mean_strong_competitor_ratio) ? 100 * (1 - a.mean_strong_competitor_ratio) : null, weight: CC.strength_mix.strong_ratio },
    rating: { score: isNum(a.mean_median_rating) ? interpolate(a.mean_median_rating, CC.rating_anchors) : null, weight: CC.strength_mix.rating },
    badges: { score: isNum(a.mean_badge_ratio) ? clamp(100 - a.mean_badge_ratio * CC.badge_ratio_multiplier) : null, weight: CC.strength_mix.badges },
  });
  const paid = isNum(a.mean_paid_result_ratio) ? clamp(100 - a.mean_paid_result_ratio * CC.paid_ratio_multiplier) : null;
  const vals = { saturation: sat.score, strength: str.score, paid_pressure: paid };
  const comb = combine({
    saturation: { score: vals.saturation, weight: CC.sub_weights.saturation },
    strength: { score: vals.strength, weight: CC.sub_weights.strength },
    paid_pressure: { score: vals.paid_pressure, weight: CC.sub_weights.paid_pressure },
  });
  const totalScoring = included.reduce((t, x) => t + x.scoring.length, 0);
  const totalProducts = prep.amazon.reduce((t, x) => t + x.products.length, 0);
  const inputs = { ...a, amazon_keywords: kwAudit, products_total: totalProducts, products_used_for_scoring: totalScoring, products_excluded: totalProducts - totalScoring, saturation_detail: sat, strength_detail: str };
  if (comb.available < CC.min_sub_scores) return insufficient(w, "too_few_competition_signals", "Not enough relevant Amazon competitor evidence after relevance filtering.", inputs, comb.missing);
  const sub_scores: Record<string, SubScore> = {};
  for (const k of Object.keys(CC.sub_weights) as Array<keyof typeof CC.sub_weights>) {
    const s = vals[k];
    sub_scores[k] = { score: isNum(s) ? r2(s) : null, weight: CC.sub_weights[k], effective_weight: r2(comb.effective[k] ?? 0), inputs: {}, missing: !isNum(s) };
  }
  const confidence: Conf = totalScoring >= C.competition_conf.high_products && included.length >= C.competition_conf.high_keywords ? "high" : totalScoring >= C.competition_conf.medium_products ? "medium" : "low";
  const downweighted = prep.amazon.filter((x) => x.kr.weight > 0 && x.kr.weight < 1).length;
  const excluded = prep.amazon.length - included.length;
  return {
    status: "ok", score: r2(comb.score!), weight: w, sub_scores, inputs, confidence,
    reweighted: comb.missing.length > 0, missing: comb.missing,
    explanation: {
      code: "marketplace_competition_filtered",
      text: `Using ${included.length} of ${prep.amazon.length} Amazon searches (${excluded} excluded, ${downweighted} down-weighted for relevance) and ${totalScoring} of ${totalProducts} products that match the niche: about ${Math.round(a.mean_relevant_product_count ?? 0)} relevant products per search, median ${Math.round(a.mean_median_review_count ?? 0).toLocaleString("en-US")} reviews, ${isNum(a.mean_strong_competitor_ratio) ? Math.round(a.mean_strong_competitor_ratio * 100) : "?"}% strong competitors${isNum(a.mean_paid_result_ratio) ? `, ${Math.round(a.mean_paid_result_ratio * 100)}% sponsored` : ""}.`,
      facts: inputs,
    },
  };
}

function purchaseIntent(input: ScoreInputV11, prep: ReturnType<typeof prepare>): Component {
  const P = SCORE_V1_CONFIG.purchase_intent, w = C.weights.purchase_intent;
  const rel = prep.rel;
  const cpcSample = rel.filter((k) => isNum(k.cpc) && isNum(k.search_volume) && k.search_volume! > 0)
    .sort((a, b) => (b.search_volume! - a.search_volume!) || a.keyword.localeCompare(b.keyword)).slice(0, P.cpc_keyword_sample);
  const volSum = cpcSample.reduce((t, k) => t + k.search_volume!, 0);
  const weightedCpc = cpcSample.length ? cpcSample.reduce((t, k) => t + k.cpc! * k.search_volume!, 0) / volSum : null;
  const cpcScore = isNum(weightedCpc) ? interpolate(weightedCpc, P.cpc_anchors) : null;
  // Commercial share is measured on distinct clusters, so duplicates do not inflate it.
  const repKws = prep.clusters.map((c) => c.representative_keyword);
  const commercial = repKws.filter((k) => isCommercial(k));
  const shareC = repKws.length ? commercial.length / repKws.length : null;
  const commercialScore = isNum(shareC) ? clamp((shareC / P.commercial_full_score_share) * 100) : null;

  const perKw: Array<{ keyword: string; weight: number; scoring_products: number; known_products: number; coverage: number; median_known: number; cap: number; capped_total: number; raw_total: number; score: number }> = [];
  let known = 0, scoringTotal = 0;
  for (const a of prep.amazon) {
    if (a.kr.weight <= 0) continue;
    scoringTotal += a.scoring.length;
    const vals = a.scoring.map((p) => p.bought_past_month).filter(isNum);
    known += vals.length;
    if (!vals.length) continue;
    const med = median(vals)!;
    const cap = med * C.purchase.cap_multiple_of_median;
    const capped = vals.reduce((t, v) => t + Math.min(v, cap), 0);
    perKw.push({ keyword: a.keyword, weight: a.kr.weight, scoring_products: a.scoring.length, known_products: vals.length, coverage: r2(vals.length / a.scoring.length), median_known: med, cap, capped_total: capped, raw_total: vals.reduce((t, v) => t + v, 0), score: r2(logInterpolate(capped, P.purchase_anchors_log)) });
  }
  const purchaseScore = perKw.length ? wmean(perKw.map((k) => [k.score, k.weight])) : null;
  const coverage = scoringTotal ? known / scoringTotal : null;

  const comb = combine({
    cpc: { score: cpcScore, weight: P.sub_weights.cpc },
    commercial_keywords: { score: commercialScore, weight: P.sub_weights.commercial_keywords },
    marketplace_purchase: { score: purchaseScore, weight: P.sub_weights.marketplace_purchase },
  });
  const inputs = {
    weighted_cpc: isNum(weightedCpc) ? r2(weightedCpc) : null, cpc_keywords_used: cpcSample.length,
    distinct_clusters: repKws.length, commercial_clusters: commercial.length, commercial_share: isNum(shareC) ? r2(shareC) : null,
    commercial_examples: commercial.slice(0, 5), purchase_signal_coverage: isNum(coverage) ? r2(coverage) : null,
    purchase_rule: `per keyword: cap each product's bought_past_month at ${C.purchase.cap_multiple_of_median}x the median known value, sum, log-scale; keywords weighted by relevance tier; missing values are unknown, not zero`,
    marketplace_purchase: perKw,
  };
  if (comb.available < P.min_sub_scores) return insufficient(w, "too_few_intent_signals", "Not enough commercial evidence to score purchase intent.", inputs, comb.missing);
  const vals = { cpc: cpcScore, commercial_keywords: commercialScore, marketplace_purchase: purchaseScore };
  const sub_scores: Record<string, SubScore> = {};
  for (const k of Object.keys(P.sub_weights) as Array<keyof typeof P.sub_weights>) {
    const s = vals[k];
    sub_scores[k] = { score: isNum(s) ? r2(s) : null, weight: P.sub_weights[k], effective_weight: r2(comb.effective[k] ?? 0), inputs: {}, missing: !isNum(s) };
  }
  const confidence: Conf = !isNum(coverage) || !perKw.length ? "low"
    : coverage >= C.purchase.coverage_conf.high ? "high" : coverage >= C.purchase.coverage_conf.medium ? "medium" : "low";
  const parts = [
    isNum(weightedCpc) ? `Weighted CPC is $${weightedCpc.toFixed(2)}` : "CPC unavailable",
    isNum(shareC) ? `${Math.round(shareC * 100)}% of ${repKws.length} distinct keyword clusters carry commercial modifiers` : null,
    perKw.length ? `"bought in past month" is visible for ${Math.round((coverage ?? 0) * 100)}% of relevant products (outliers capped at ${C.purchase.cap_multiple_of_median}x median)` : "Amazon purchase activity unavailable (reweighted)",
  ].filter(Boolean);
  return { status: "ok", score: r2(comb.score!), weight: w, sub_scores, inputs, confidence, reweighted: comb.missing.length > 0, missing: comb.missing, explanation: { code: "purchase_intent_v1_1", text: `${parts.join("; ")}.`, facts: inputs } };
}

function trend(input: ScoreInputV11, prep: ReturnType<typeof prepare>): Component {
  const T = SCORE_V1_CONFIG.trend, w = C.weights.trend;
  const used = prep.clusters.slice(0, SCORE_V1_CONFIG.demand.keyword_weights.length);
  const repSet = new Set(used.map((c) => c.representative_keyword));
  const series = monthlySeries(prep.rel.filter((k) => repSet.has(k.keyword)));
  if (series.length < T.min_months) return insufficient(w, "insufficient_history", `Only ${series.length} months of search history available (need ${T.min_months}).`, { months: series.length, trend_classification: "insufficient_data", seasonality_confidence: "insufficient" }, ["monthly_search_history"]);
  const last = series.slice(-3), prev = series.slice(-6, -3), year = series.slice(-12);
  const recent = mean(last.map((s) => s.total))!, previous = mean(prev.map((s) => s.total))!, avg12 = mean(year.map((s) => s.total))!;
  const peak = year.reduce((a, b) => (b.total > a.total ? b : a)), low = year.reduce((a, b) => (b.total < a.total ? b : a));
  const ratio = avg12 > 0 ? peak.total / avg12 : null;
  const sd = Math.sqrt(mean(year.map((s) => (s.total - avg12) ** 2))!);
  const cv = avg12 > 0 ? sd / avg12 : null;
  const growth = previous > 0 ? (recent - previous) / previous : recent > 0 ? 1 : 0;
  let score = interpolate(growth, T.growth_anchors);
  let cls = growth < -0.1 ? "declining" : growth > 0.1 ? "growing" : "stable";
  let seasonality_confidence: Conf = "insufficient";
  let note: string | null = null;
  const peakIdx = series.findIndex((s) => s.key === peak.key);
  const recentStart = series.length - 3;
  const pronounced = isNum(ratio) && ratio >= C.trend.seasonal_peak_ratio;
  const years = series.length >= 24 ? 2 : 1;
  if (pronounced && peakIdx >= recentStart - 3) {
    // Spike inside the comparison window: do not treat as permanent growth.
    const b = score; score = clamp(score, ...C.trend.spike_score_clamp); cls = "seasonal";
    seasonality_confidence = years >= 2 ? "medium" : "low";
    note = `Peak ${peak.key} (${r2(ratio!)}x average) falls inside the comparison window; possible seasonal spike, score clamped ${r2(b)} -> ${r2(score)}.`;
  } else if (pronounced && peakIdx < recentStart && growth < 0 && series.length >= 12) {
    // Decline following an isolated peak: possible seasonality, not proven structural decline.
    const b = score; score = clamp(score, ...C.trend.seasonal_score_clamp); cls = "seasonal";
    seasonality_confidence = years >= 2 ? "medium" : "low";
    note = `Recent decline follows a pronounced peak in ${peak.key} (${r2(ratio!)}x the 12-month average). With ${years === 1 ? "only one year" : "two or more years"} of history this is a possible seasonal signal, not proven seasonality; score moved ${r2(b)} -> ${r2(score)}.`;
  } else if (series.length >= 12) seasonality_confidence = pronounced ? "low" : "medium";
  const confidence: Conf = series.length < 12 ? "low" : cls === "seasonal" && years < 2 ? "low" : series.length < 24 ? "medium" : "high";
  const inputs = {
    months: series.length, recent_3_month_average: Math.round(recent), previous_3_month_average: Math.round(previous),
    growth_rate: r2(growth), twelve_month_average: Math.round(avg12), peak_month: { month: peak.key, volume: peak.total }, lowest_month: { month: low.key, volume: low.total },
    peak_to_average_ratio: isNum(ratio) ? r2(ratio) : null, coefficient_of_variation: isNum(cv) ? r2(cv) : null,
    trend_classification: cls, seasonality_confidence, seasonal_note: note, series: series.map((s) => ({ month: s.key, volume: s.total })),
  };
  const label = cls === "seasonal" ? "showing a possible seasonal signal" : cls;
  return {
    status: "ok", score: r2(score), weight: w, inputs, confidence, reweighted: false, missing: [],
    explanation: {
      code: `trend_${cls}`,
      text: `Search interest is ${label}: latest 3 months average ${Math.round(recent).toLocaleString("en-US")} vs ${Math.round(previous).toLocaleString("en-US")} before (${growth >= 0 ? "+" : ""}${Math.round(growth * 100)}%); peak ${peak.key} is ${isNum(ratio) ? r2(ratio) : "n/a"}x the 12-month average, volatility (CV) ${isNum(cv) ? r2(cv) : "n/a"}.${note ? ` ${note}` : ""}`,
      facts: inputs,
    },
  };
}

// ---------- quality & final ----------
function qualityFactors(prep: ReturnType<typeof prepare>, comps: Record<string, Component>) {
  const relWithVol = prep.rel.filter((k) => isNum(k.search_volume)).length;
  const independence = relWithVol ? Math.min(100, (prep.clusters.length / relWithVol) * 100 * 2) : null; // 50%+ distinct => 100
  const amzRel = prep.amazon.length ? mean(prep.amazon.map((a) => a.kr.amazon_keyword_relevance_score)) : null;
  const totalP = prep.amazon.reduce((t, a) => t + a.products.length, 0);
  const scoringP = prep.amazon.filter((a) => a.kr.weight > 0).reduce((t, a) => t + a.scoring.length, 0);
  const prodRel = totalP ? (prep.amazon.reduce((t, a) => t + a.scoring.length, 0) / totalP) * 100 : null;
  const cov = comps["purchase_intent"]!.inputs["purchase_signal_coverage"];
  const months = (comps["trend"]!.inputs["months"] as number | undefined) ?? 0;
  return {
    keyword_independence: isNum(independence) ? r2(independence) : null,
    amazon_keyword_relevance: isNum(amzRel) ? r2(amzRel) : null,
    product_relevance: isNum(prodRel) ? r2(prodRel) : null,
    purchase_signal_coverage: isNum(cov) ? r2(cov * 100) : null,
    historical_depth: r2(Math.min(100, (months / 24) * 100)),
    sample_size: totalP ? r2(Math.min(100, scoringP)) : null, // 100+ scoring products => 100
  };
}

export function scoreV1_1(input: ScoreInputV11): ScoreResult {
  const prep = prepare(input);
  const components = { demand: demand(input, prep), competition: competition(input, prep), purchase_intent: purchaseIntent(input, prep), trend: trend(input, prep) };
  // Completeness uses the same categories as score_v1 (fields present), independent of quality.
  const cats = evidenceCategories({ niche: input.niche, google: input.google, amazon: (input.amazon ?? []).map((a) => ({ keyword: a.keyword, results_count: a.results_count, products: a.products.map((p) => ({ relevant: p.relevant ?? true, bought_past_month: p.bought_past_month })), metrics: { relevant_product_count: a.products.length, paid_result_ratio: null, median_rating: median(a.products.map((p) => p.rating).filter(isNum)), median_review_count: median(a.products.map((p) => p.review_count).filter(isNum)), amazon_choice_count: 0, best_seller_count: 0, strong_competitor_ratio: null, products_with_bought_past_month: 0 } })) });
  const completeness = r2((Object.values(cats).filter(Boolean).length / Object.keys(cats).length) * 100);
  const factors = qualityFactors(prep, components);
  const fv = Object.values(factors).filter(isNum);
  const quality = fv.length ? r2(fv.reduce((a, b) => a + b, 0) / fv.length) : null;

  const avail = Object.entries(components).filter(([, c]) => c.status === "ok");
  const reweighting: string[] = [];
  for (const [k, c] of Object.entries(components)) if (c.reweighted) reweighting.push(`${k}: missing ${c.missing.join(", ")} — remaining sub-scores reweighted proportionally`);
  let final: number | null = null;
  const effective: Record<string, number> = {};
  if (avail.length >= SCORE_V1_CONFIG.min_components) {
    const tw = avail.reduce((t, [, c]) => t + c.weight, 0);
    final = 0;
    for (const [k, c] of avail) { effective[k] = r2(c.weight / tw); final += c.score! * (c.weight / tw); }
    final = clamp(final);
    if (avail.length < 4) reweighting.push(`final: ${Object.keys(components).filter((k) => !effective[k]).join(", ")} insufficient — remaining component weights reweighted proportionally`);
  }
  let confidence: Conf = "insufficient";
  if (final !== null) {
    confidence = avail.length === 4 && completeness >= 85 ? "high" : (avail.length === 4 && completeness >= 60) || completeness >= 70 ? "medium" : "low";
    const compConfs = avail.map(([, c]) => c.confidence ?? "low") as Conf[];
    const lowCount = compConfs.filter((c) => c === "low").length;
    if (isNum(quality) && quality < 50) confidence = minConf(confidence, "low");
    else if ((isNum(quality) && quality < C.quality_floor_for_high) || lowCount > 0) confidence = minConf(confidence, "medium");
    if (lowCount >= 2) confidence = minConf(confidence, "low");
  }
  return {
    score_version: SCORE_VERSION_V1_1,
    opportunity_score: final === null ? null : Math.round(final * 10000) / 10000,
    opportunity_score_display: final === null ? null : Math.round(final),
    classification: final === null ? "Insufficient data" : classify(Math.round(final)),
    confidence, evidence_completeness_percent: completeness, evidence_categories: cats,
    evidence_quality_score: quality, evidence_quality_factors: factors,
    components, weights: SCORE_V1_CONFIG.weights, effective_weights: effective,
    missing_evidence: Object.entries(cats).filter(([, v]) => !v).map(([k]) => k), reweighting,
    config: SCORE_V1_1_CONFIG,
  };
}
