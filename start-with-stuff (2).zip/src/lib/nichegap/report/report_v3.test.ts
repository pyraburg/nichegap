import { describe, expect, it } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { buildAiSection, buildReportV3, type AiAnalysisRow } from "./report_v3";
import { buildReportV2 } from "./report_v2";
import { buildReport } from "./report_v1";
import { scoreV1_1 } from "../scoring/score_v1_1";

const packet = {
  evidence: {
    google_keyword_groups: [{ id: "google_kw_001", type: "google_keyword_group", keyword: "basil grow light", monthly_search_volume: 1200, cpc_usd: 1.1, google_ads_competition: "HIGH" }],
    amazon_searches: [], amazon_products: [{ id: "amazon_product_001", type: "amazon_product", title: "Herb Kit", price: 30, currency: "USD", rating: 4.3, review_count: 900 }],
    community_posts: [{ id: "community_post_001", type: "community_post", platform: "reddit", title: "Basil keeps dying", text: "My basil gets terrible light by the window", created_at: "2026-09-01T00:00:00Z", url: "https://www.reddit.com/r/x/1", author: "secret_user" }],
    community_comments: [{ id: "community_comment_001", type: "community_comment", post_id: "community_post_001", text: "It's whack-a-mole with gnats", created_at: "2026-09-02T00:00:00Z" }],
  },
};
const ids = ["google_kw_001", "amazon_product_001", "community_post_001", "community_comment_001"];
const output = {
  analysis_version: "ai_analysis_v1",
  executive_summary: { text: "Lighting is a recurring issue.", evidence_ids: ids },
  pain_point_clusters: [
    { title: "Lighting", description: "Light confusion", confidence: "high", evidence_ids: ids, evidence_count: 4 },
    { title: "Unsupported", description: "x", confidence: "insufficient", evidence_ids: [], evidence_count: 0 },
  ],
  unmet_needs: [{ need: "Light guidance", explanation: "people ask", confidence: "medium", evidence_ids: ["community_post_001", "google_kw_001"] }],
  existing_solution_complaints: [{ complaint: "Weak lights", solution_type: "grow lights", confidence: "low", evidence_ids: ["community_post_001", "ghost_id"] }],
  customer_language: [
    { phrase: "terrible light", kind: "verbatim", evidence_ids: ["community_post_001"] },
    { phrase: "plants hate the sun", kind: "paraphrase", evidence_ids: ["community_comment_001"] },
  ],
  opportunity_hypotheses: [{ hypothesis: "Light selector", rationale: "demand + complaints", confidence: "medium", evidence_ids: ids }],
  risks_and_uncertainties: [{ risk: "Crowded market", evidence_ids: ["amazon_product_001"] }],
  validation_recommendations: [{ recommendation: "Interview growers", addresses: "which pain matters", evidence_ids: ["community_post_001"] }],
};
const row = (o: Partial<AiAnalysisRow> = {}): AiAnalysisRow => ({ status: "completed", model: "gpt-5.4-mini", analysis_version: "ai_analysis_v1", evidence_packet_hash: "abc",
  completed_at: "2026-10-06T22:47:00Z", validated_output: output as never, evidence_packet: packet as never, ...o });

describe("report_v3 AI section", () => {
  it("renders a successful validated AI result", () => {
    const a = buildAiSection(row())!;
    expect(a.label).toBe("AI ANALYSIS");
    expect(a.problems).toHaveLength(1);
    expect(a.problems[0]!.evidence_count).toBe(4);
    expect(a.unmet_needs).toHaveLength(1);
    expect(a.hypotheses[0]!.evidence_count).toBe(4);
    expect(a.risks).toHaveLength(1);
    expect(a.validation_steps).toHaveLength(1);
  });
  it("omits the section when there is no AI result or it failed/was rejected", () => {
    expect(buildAiSection(null)).toBeNull();
    expect(buildAiSection(row({ status: "failed" }))).toBeNull();
    expect(buildAiSection(row({ status: "rejected", validated_output: null }))).toBeNull();
  });
  it("does not display insufficient items or invalid evidence references", () => {
    const a = buildAiSection(row())!;
    expect(a.problems.map((p) => p.title)).not.toContain("Unsupported");
    expect(a.complaints[0]!.evidence).toHaveLength(1);
    expect(JSON.stringify(a)).not.toContain("ghost_id");
  });
  it("distinguishes verified quotes from AI paraphrases and never quotes a paraphrase", async () => {
    const a = buildAiSection(row())!;
    expect(a.language.map((l) => l.verified_quote)).toEqual([true, false]);
    const { AiAnalysisSection } = await import("../../../routes/_authenticated/research_.$id.report");
    const html = renderToStaticMarkup(createElement(AiAnalysisSection, { a }));
    expect(html).toContain("Verified quote");
    expect(html).toContain("<q class=\"rp-quote\">terrible light</q>");
    expect(html).toMatch(/AI paraphrase<\/span> <span class="rp-para">plants hate the sun<\/span>/);
    expect(html).not.toMatch(/<q[^>]*>plants hate the sun/);
    expect(html).toContain("AI analysis");
    expect(html).toContain("not guaranteed business opportunities");
  });
  it("resolves evidence for traceability with market-data fields and safe links", () => {
    const a = buildAiSection(row())!;
    const kinds = Object.values(a.evidence).map((e) => e.kind).sort();
    expect(kinds).toEqual(["Amazon product", "Community comment", "Community discussion", "Google search demand"]);
    const g = Object.values(a.evidence).find((e) => e.kind === "Google search demand") as { monthly_searches: number };
    expect(g.monthly_searches).toBe(1200);
    const c = Object.values(a.evidence).find((e) => e.kind === "Community comment") as { url: string | null; title: string };
    expect(c.url).toBe("https://www.reddit.com/r/x/1");
    expect(c.title).toBe("Comment on: Basil keeps dying");
  });
  it("redacts identity fields and internal identifiers", () => {
    const s = JSON.stringify(buildAiSection(row()));
    expect(s).not.toMatch(/secret_user|author|community_post_001|google_kw_001|amazon_product_001/);
    expect(Object.keys(buildAiSection(row())!.evidence).every((k) => /^E\d+$/.test(k))).toBe(true);
  });
  it("keeps v1/v2 compatibility and an identical score block", () => {
    const result = scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null });
    const job = { id: "j", query: "indoor herb garden", target_country: "US", language: "en", completed_at: null, created_at: "2026-10-01T00:00:00Z" };
    const run = { id: "r", score_version: "score_v1_1", created_at: "2026-10-01T00:00:00Z", evidence_hash: "h", result } as never;
    const ev = { google: null, amazon: [] };
    const v1 = buildReport(job, run, ev, "t"), v2 = buildReportV2(job, run, ev, null, "t");
    const v3 = buildReportV3(job, run, ev, null, row(), "t");
    expect(v3.score).toEqual(v1.score);
    expect(v3.community).toEqual(v2.community);
    expect(v3.report_version).toBe("report_v3");
    expect(buildReportV3(job, run, ev, null, null, "t").ai).toBeNull();
  });
});
