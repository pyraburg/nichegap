// Customer Opportunity Report v1 — deterministic snapshot builder.
// Uses ONLY stored evidence + a stored score result. No AI, no rescoring.
import type { ScoreResult, Component, GoogleKeyword } from "../scoring/score_v1";
import { productRelevance, type AmazonKeywordEvidenceV11 } from "../scoring/score_v1_1";

export const REPORT_VERSION = "report_v1";

export const REPORT_V1_RULES = {
  band: { high: 70, medium: 45 }, // component band: >=70 high, >=45 medium, else low
  quality_low: 50,
  strong_competitor_high: 0.4,
  sponsored_high: 0.25,
  purchase_coverage_low: 0.5,
  history_months_confident: 24,
  max_clusters: 8,
  max_sample_products: 5,
} as const;

type Band = "high" | "medium" | "low" | "insufficient";
const R = REPORT_V1_RULES;
const isNum = (v: unknown): v is number => typeof v === "number" && Number.isFinite(v);
export const band = (c: Component): Band =>
  c.status !== "ok" || !isNum(c.score) ? "insufficient" : c.score >= R.band.high ? "high" : c.score >= R.band.medium ? "medium" : "low";
const median = (xs: number[]) => {
  if (!xs.length) return null;
  const s = xs.slice().sort((a, b) => a - b); const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
};
const r2 = (n: number) => Math.round(n * 100) / 100;

export interface ReportJob { id: string; query: string; target_country: string; language: string; completed_at: string | null; created_at: string }
export interface ReportScoreRun { id: string; score_version: string; created_at: string; evidence_hash: string; result: ScoreResult }
export interface ReportEvidence {
  google: { keywords: GoogleKeyword[]; collected_at: string | null } | null;
  amazon: Array<AmazonKeywordEvidenceV11 & { collected_at?: string | null; currency?: string | null }>;
}
export interface Statement { rule: string; text: string }

export function buildReport(job: ReportJob, run: ReportScoreRun, ev: ReportEvidence, generatedAt: string) {
  const r = run.result;
  const c = r.components;
  const q = r.evidence_quality_factors ?? {};
  const sufficient = r.opportunity_score_display !== null;

  // ---------- Demand ----------
  const kwByName = new Map((ev.google?.keywords ?? []).map((k) => [k.keyword, k]));
  const overview = (c.demand.inputs["top_clusters_overview"] as Array<{ representative_keyword: string; representative_volume: number; member_count: number }> | undefined) ?? [];
  const clusters = overview.slice(0, R.max_clusters).map((o) => {
    const k = kwByName.get(o.representative_keyword);
    return { representative_keyword: o.representative_keyword, monthly_search_volume: o.representative_volume, grouped_keywords: o.member_count, cpc: k?.cpc ?? null, google_ads_competition: k?.competition ?? null };
  });
  const primary = (c.demand.inputs["contributions"] as Array<{ cluster: string; representative_volume: number }> | undefined)?.[0] ?? null;

  // ---------- Marketplace ----------
  const kwAudit = (c.competition.inputs["amazon_keywords"] as Array<{ keyword: string; amazon_keyword_relevance_score: number; weight: number; reasons: string[]; products_total: number; products_for_scoring: number }> | undefined) ?? [];
  const included = new Set(kwAudit.filter((k) => k.weight > 0).map((k) => k.keyword));
  const scoringProducts = ev.amazon.filter((a) => included.has(a.keyword)).flatMap((a) =>
    a.products.filter((p) => productRelevance(p, job.query, a.keyword, a.categories).relevant_for_scoring).map((p) => ({ ...p, search: a.keyword })));
  const prices = scoringProducts.map((p) => (p as { price?: number | null }).price).filter(isNum);
  const seenTitles = new Set<string>();
  const sample = scoringProducts.slice()
    .sort((a, b) => (b.review_count ?? -1) - (a.review_count ?? -1) || (a.title ?? "").localeCompare(b.title ?? ""))
    .filter((p) => { const t = (p.title ?? "").toLowerCase(); if (!t || seenTitles.has(t)) return false; seenTitles.add(t); return true; })
    .slice(0, R.max_sample_products)
    .map((p) => ({ title: p.title, price: (p as { price?: number | null }).price ?? null, rating: p.rating, review_count: p.review_count, bought_past_month: p.bought_past_month, is_amazon_choice: p.is_amazon_choice, is_best_seller: p.is_best_seller }));
  const ci = c.competition.inputs;
  const currency = ev.amazon.flatMap((a) => a.products).map((p) => (p as { currency?: string | null }).currency).find(Boolean) ?? null;
  const marketplace = {
    amazon_searches_analyzed: kwAudit.length || ev.amazon.length,
    amazon_searches_used: included.size,
    searches: kwAudit.map((k) => ({ keyword: k.keyword, relevance_score: k.amazon_keyword_relevance_score, weight: k.weight, status: k.weight === 0 ? "excluded" : k.weight < 1 ? "down-weighted" : "full weight", reasons: k.reasons })),
    products_total: (ci["products_total"] as number | undefined) ?? null,
    relevant_products_analyzed: (ci["products_used_for_scoring"] as number | undefined) ?? null,
    products_excluded: (ci["products_excluded"] as number | undefined) ?? null,
    median_price: prices.length ? r2(median(prices)!) : null, currency,
    median_rating: isNum(ci["mean_median_rating"]) ? r2(ci["mean_median_rating"]) : null,
    median_review_count: isNum(ci["mean_median_review_count"]) ? Math.round(ci["mean_median_review_count"]) : null,
    strong_competitor_ratio: isNum(ci["mean_strong_competitor_ratio"]) ? r2(ci["mean_strong_competitor_ratio"]) : null,
    sponsored_ratio: isNum(ci["mean_paid_result_ratio"]) ? r2(ci["mean_paid_result_ratio"]) : null,
    amazon_choice_count: scoringProducts.filter((p) => p.is_amazon_choice).length,
    best_seller_count: scoringProducts.filter((p) => p.is_best_seller).length,
    sample_products: sample,
  };

  // ---------- Purchase ----------
  const pi = c.purchase_intent.inputs;
  const purchase = {
    weighted_cpc: (pi["weighted_cpc"] as number | null) ?? null,
    commercial_share: (pi["commercial_share"] as number | null) ?? null,
    distinct_clusters: (pi["distinct_clusters"] as number | null) ?? null,
    commercial_examples: (pi["commercial_examples"] as string[] | undefined) ?? [],
    purchase_signal_coverage: (pi["purchase_signal_coverage"] as number | null) ?? null,
    marketplace_purchase_score: c.purchase_intent.sub_scores?.["marketplace_purchase"]?.score ?? null,
    cpc_score: c.purchase_intent.sub_scores?.["cpc"]?.score ?? null,
    commercial_score: c.purchase_intent.sub_scores?.["commercial_keywords"]?.score ?? null,
  };

  // ---------- Trend ----------
  const ti = c.trend.inputs;
  const months = (ti["months"] as number | undefined) ?? 0;
  const trend = {
    classification: (ti["trend_classification"] as string | undefined) ?? "insufficient_data",
    recent_average: ti["recent_3_month_average"] ?? ti["recent_average"] ?? null,
    previous_average: ti["previous_3_month_average"] ?? ti["previous_average"] ?? null,
    growth_rate: ti["growth_rate"] ?? null,
    twelve_month_average: ti["twelve_month_average"] ?? null,
    peak_month: ti["peak_month"] ?? null,
    seasonality_ratio: ti["peak_to_average_ratio"] ?? ti["seasonality_ratio"] ?? null,
    seasonality_confidence: ti["seasonality_confidence"] ?? null,
    months_of_history: months,
    series: ti["series"] ?? [],
    history_note: months < R.history_months_confident
      ? `Only ${months} months of search history are available. At least ${R.history_months_confident} months would be needed to confirm a recurring seasonal pattern.`
      : null,
  };

  // ---------- Quality ----------
  const qText: Record<string, [string, string, string]> = {
    keyword_independence: ["Keyword independence", "Many keyword variations were closely related, so NicheGap grouped them to reduce double counting.", "Keyword groups were largely distinct from one another."],
    amazon_keyword_relevance: ["Amazon search relevance", "Some marketplace searches were only partially related to the original niche.", "Marketplace searches closely matched the original niche."],
    product_relevance: ["Product relevance", "A large share of returned Amazon products did not match the niche and were excluded.", "Most returned Amazon products matched the niche."],
    purchase_signal_coverage: ["Purchase visibility", "Amazon showed recent-purchase counts for only part of the relevant products.", "Amazon showed recent-purchase counts for most relevant products."],
    historical_depth: ["History depth", "Limited search history is available, which restricts trend confidence.", "Sufficient search history is available."],
    sample_size: ["Sample size", "Few relevant marketplace products were available to analyze.", "Enough relevant marketplace products were analyzed."],
  };
  const quality = Object.entries(qText).map(([k, [label, weak, ok]]) => {
    const v = (q as Record<string, number | null>)[k];
    return { key: k, label, score: isNum(v) ? Math.round(v) : null, text: !isNum(v) ? "Not available for this research." : v < 70 ? weak : ok };
  });

  // ---------- Findings (deterministic rules) ----------
  const bd = band(c.demand), bc = band(c.competition), bp = band(c.purchase_intent), bt = band(c.trend);
  const nClusters = (c.demand.inputs["cluster_count"] as number | undefined) ?? clusters.length;
  const findings: Statement[] = [];
  if (!sufficient) findings.push({ rule: "final_insufficient", text: "Insufficient evidence to calculate a reliable Opportunity Score." });
  if (bd === "high") findings.push({ rule: "demand_high", text: nClusters >= 3 ? "Search evidence indicates substantial demand across several distinct keyword groups." : "Search demand is substantial but concentrated in few keyword groups." });
  else if (bd === "medium") findings.push({ rule: "demand_medium", text: "Search evidence indicates moderate demand." });
  else if (bd === "low") findings.push({ rule: "demand_low", text: "Measured search demand is limited." });
  else findings.push({ rule: "demand_insufficient", text: "There was not enough search evidence to assess demand." });
  if (bc === "high") findings.push({ rule: bd === "high" ? "demand_high_competition_high" : "competition_high", text: bd === "high" ? "Demand appears strong and the analyzed marketplace competition looks comparatively favorable." : "The analyzed marketplace competition looks comparatively favorable." });
  else if (bc === "medium") findings.push({ rule: bd === "high" ? "demand_high_competition_medium" : "competition_medium", text: bd === "high" ? "Demand appears strong, but established marketplace competition means differentiation will be important." : "Marketplace competition is moderate; differentiation will matter." });
  else if (bc === "low") findings.push({ rule: "competition_low", text: "Analyzed marketplace competition is strong; entering would require clear differentiation." });
  else findings.push({ rule: "competition_insufficient", text: "There was not enough relevant marketplace evidence to assess competition." });
  if (bp === "high") findings.push({ rule: "purchase_high", text: "There are meaningful commercial and marketplace buying signals." });
  else if (bp === "medium") findings.push({ rule: "purchase_medium", text: "Some commercial buying signals are present." });
  else if (bp === "low") findings.push({ rule: "purchase_low", text: "Commercial buying signals are limited." });
  else findings.push({ rule: "purchase_insufficient", text: "There was not enough evidence to assess buying intent." });
  const tcls = trend.classification;
  if (bt === "insufficient") findings.push({ rule: "trend_insufficient", text: "There is not enough search history to assess the trend." });
  else {
    findings.push({ rule: `trend_${tcls}`, text: tcls === "seasonal" ? "Search interest shows a possible seasonal signal." : tcls === "growing" ? "Search interest has been growing recently." : tcls === "declining" ? "Search interest has declined recently." : "Search interest has been broadly stable recently." });
    if (c.trend.confidence === "low") findings.push({ rule: "trend_low_confidence", text: "Current history is not sufficient to confidently determine the long-term direction." });
  }

  // ---------- Cautions ----------
  const cautions: Statement[] = [];
  const qv = (k: string) => (q as Record<string, number | null>)[k];
  if (isNum(qv("keyword_independence")) && qv("keyword_independence")! < R.quality_low) cautions.push({ rule: "low_keyword_independence", text: "Many searches overlap, so apparent demand may represent fewer distinct customer needs." });
  if (isNum(qv("product_relevance")) && qv("product_relevance")! < R.quality_low) cautions.push({ rule: "low_product_relevance", text: "Many Amazon results were not closely related to the niche, so competitor comparisons rely on a filtered subset." });
  if (isNum(qv("amazon_keyword_relevance")) && qv("amazon_keyword_relevance")! < R.quality_low + 10) cautions.push({ rule: "low_amazon_search_relevance", text: "Some marketplace searches were only partially related to the niche and were down-weighted or excluded." });
  if (months < R.history_months_confident) cautions.push({ rule: "low_history_depth", text: "Long-term trend confidence is limited by available historical data." });
  if (isNum(marketplace.strong_competitor_ratio) && marketplace.strong_competitor_ratio >= R.strong_competitor_high) cautions.push({ rule: "high_strong_competitor_ratio", text: "Many relevant competitors already have established ratings and reviews." });
  if (isNum(marketplace.sponsored_ratio) && marketplace.sponsored_ratio >= R.sponsored_high) cautions.push({ rule: "high_sponsored_ratio", text: "Paid marketplace competition appears significant." });
  if (!isNum(purchase.purchase_signal_coverage)) cautions.push({ rule: "purchase_signal_unknown", text: "Amazon recent-purchase counts were not available, so marketplace buying activity is unknown." });
  else if (purchase.purchase_signal_coverage < R.purchase_coverage_low) cautions.push({ rule: "low_purchase_coverage", text: "Amazon showed recent-purchase counts for only part of the relevant products." });
  if (tcls === "seasonal") cautions.push({ rule: "possible_seasonality", text: "A possible seasonal pattern was detected; timing of launch and inventory may matter." });
  if (r.confidence === "low" || r.confidence === "insufficient") cautions.push({ rule: "low_overall_confidence", text: "Overall evidence confidence is low; treat the score as directional only." });

  // ---------- Validation steps ----------
  const steps: Statement[] = [{ rule: "always_keywords", text: "Review the highest-volume independent keyword groups to confirm they match the product you have in mind." }];
  if (bc === "low" || bc === "medium" || cautions.some((x) => x.rule === "high_strong_competitor_ratio")) {
    steps.push({ rule: "competition_review", text: "Inspect the strongest relevant competitors and compare their pricing and feature positioning." });
    steps.push({ rule: "competition_reviews_read", text: "Read customer reviews of leading products to identify recurring complaints and unmet needs." });
  }
  if (bp === "low" || bp === "insufficient" || cautions.some((x) => x.rule === "low_purchase_coverage" || x.rule === "purchase_signal_unknown")) steps.push({ rule: "purchase_validate", text: "Gather additional commercial validation, such as pre-orders, a landing page test or supplier pricing." });
  if (c.trend.confidence === "low" || tcls === "seasonal" || bt === "insufficient") steps.push({ rule: "trend_history", text: "Gather longer trend history before relying on the trend direction or seasonality." });
  steps.push({ rule: "always_communities", text: "Validate the customer problem in communities and forums where your buyers discuss it." });
  steps.push({ rule: "always_test", text: "Test a simple product concept before investing heavily." });

  const comp = (x: Component, label: string, extra?: string) => ({
    label, status: x.status, score: isNum(x.score) ? r2(x.score) : null, weight: x.weight, confidence: x.confidence ?? null, explanation: x.explanation.text, note: extra ?? null,
  });

  return {
    report_version: REPORT_VERSION,
    generated_at: generatedAt,
    research: { research_query_id: job.id, query: job.query, target_country: job.target_country, language: job.language, research_date: job.completed_at ?? job.created_at },
    score: {
      score_run_id: run.id, score_version: run.score_version, scored_at: run.created_at, evidence_hash: run.evidence_hash,
      opportunity_score: r.opportunity_score, opportunity_score_display: r.opportunity_score_display, classification: r.classification,
      sufficient, confidence: r.confidence, evidence_completeness_percent: r.evidence_completeness_percent, evidence_quality_score: r.evidence_quality_score ?? null,
      components: {
        demand: comp(c.demand, "Demand"),
        competition: comp(c.competition, "Competition Opportunity", "Higher means the competitive environment appears more favorable."),
        purchase_intent: comp(c.purchase_intent, "Purchase Intent"),
        trend: comp(c.trend, "Trend"),
      },
    },
    demand: { weighted_search_demand: c.demand.inputs["weighted_search_volume"] ?? null, primary_keyword: primary?.cluster ?? null, primary_volume: primary?.representative_volume ?? null, independent_groups: nClusters, clusters },
    marketplace, purchase, trend, quality,
    findings, cautions, validation_steps: steps,
    provenance: {
      sources: [
        { name: "Google search & advertising data", provider: "DataForSEO", collected_at: ev.google?.collected_at ?? null },
        { name: "Amazon marketplace data", provider: "DataForSEO", collected_at: ev.amazon.map((a) => a.collected_at).filter(Boolean).sort()[0] ?? null },
      ],
      market: job.target_country, language: job.language, score_model: run.score_version, report_model: REPORT_VERSION, rules: REPORT_V1_RULES,
    },
  };
}
export type ReportSnapshot = ReturnType<typeof buildReport>;
