// Presentation-only helpers for the customer report page. Pure; never changes stored values.

/** Whole-number display of a 0–100 score (stored precise value is untouched). */
export function scoreDisplay(v: number | null | undefined): string | null {
  return typeof v === "number" && Number.isFinite(v) ? String(Math.round(v)) : null;
}

export const COMPONENT_COPY: Record<string, { name: string; plain: string }> = {
  demand: { name: "Demand", plain: "How many people search for this niche each month, across independent keyword groups." },
  competition: { name: "Competition Opportunity", plain: "How manageable the marketplace competition looks. A higher score means competition appears easier to enter, not that there is more competition." },
  purchase_intent: { name: "Purchase Intent", plain: "Signals that people are ready to buy, such as advertiser bids and recent marketplace purchases." },
  trend: { name: "Trend", plain: "Whether search interest is rising, stable or falling, and how seasonal it is." },
};

const RANK: Record<string, number> = { high: 3, medium: 2, low: 1, insufficient: 0 };

/** The hypothesis with the strongest validated support: highest confidence, then most evidence, then original order. */
export function strongestHypothesis<T extends { confidence: string; evidence_count: number }>(xs: T[] | null | undefined): T | null {
  if (!xs?.length) return null;
  return xs.map((x, i) => ({ x, i })).sort((a, b) => (RANK[b.x.confidence] ?? 0) - (RANK[a.x.confidence] ?? 0) || b.x.evidence_count - a.x.evidence_count || a.i - b.i)[0]!.x;
}

/** Plain-language band for a 0–100 component score. */
export function band(score: number | null | undefined, kind: "default" | "competition" = "default"): string {
  if (typeof score !== "number") return "Not enough data";
  if (kind === "competition") return score >= 70 ? "Favourable" : score >= 45 ? "Moderate" : "Crowded";
  return score >= 70 ? "Strong" : score >= 45 ? "Moderate" : "Limited";
}

export interface TocItem { id: string; label: string }
export function reportToc(hasAi: boolean): TocItem[] {
  return [
    { id: "overview", label: "Overview" },
    { id: "market-evidence", label: "Market Evidence" },
    { id: hasAi ? "customer-problems" : "community-evidence", label: "Customer Problems" },
    ...(hasAi ? [{ id: "opportunities", label: "Opportunities" }] : []),
    { id: "next-steps", label: "Next Steps" },
  ];
}
