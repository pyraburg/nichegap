import { describe, expect, it } from "vitest";
import { buildReport, type ReportScoreRun } from "./report_v1";
import { scoreV1_1, type AmazonKeywordEvidenceV11, type AmazonProductV11 } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";

const NICHE = "indoor herb garden";
const hist = (vals: number[]) => vals.map((v, i) => ({ year: 2025, month: i + 1, search_volume: v }));
const kw = (keyword: string, v: number, h = hist(Array(12).fill(v))): GoogleKeyword => ({ keyword, search_volume: v, cpc: 1.5, competition: "HIGH", competition_index: 70, monthly_searches: h });
const google = [kw("indoor herb garden", 5000), kw("indoor herb garden kit", 2000), kw("best indoor herb garden", 1500), kw("herb garden indoor planter", 900), kw("indoor herb garden with grow light", 700)];
const prod = (i: number, o: Partial<AmazonProductV11> = {}): AmazonProductV11 & { price: number } => ({ title: `Indoor Herb Garden Kit ${i}`, result_type: "amazon_serp", bought_past_month: 200, rating: 4.1, review_count: 40, is_amazon_choice: false, is_best_seller: false, price: 20 + i, ...o });
const amz = (o: Partial<AmazonProductV11> = {}): AmazonKeywordEvidenceV11[] =>
  ["indoor herb garden kit", "indoor herb garden", "best indoor herb garden"].map((keyword) => ({ keyword, results_count: 2000, categories: null, products: Array.from({ length: 30 }, (_, i) => prod(i, o)) }));
const job = { id: "j1", query: NICHE, target_country: "US", language: "en", completed_at: "2026-10-06T00:00:00Z", created_at: "2026-10-06T00:00:00Z" };

function make(g: GoogleKeyword[] | null, a: AmazonKeywordEvidenceV11[]) {
  const result = scoreV1_1({ niche: NICHE, google: g, amazon: a.length ? a : null });
  const run: ReportScoreRun = { id: "run-1", score_version: "score_v1_1", created_at: "2026-10-06T00:00:00Z", evidence_hash: "h", result };
  return buildReport(job, run, { google: g ? { keywords: g, collected_at: "2026-10-06" } : null, amazon: a }, "2026-10-06T01:00:00Z");
}
const rules = (xs: Array<{ rule: string }>) => xs.map((x) => x.rule);

describe("report_v1", () => {
  it("A. sufficient evidence -> full report", () => {
    const r = make(google, amz());
    expect(r.score.sufficient).toBe(true);
    expect(r.demand.clusters.length).toBeGreaterThan(0);
    expect(r.marketplace.relevant_products_analyzed).toBeGreaterThan(0);
    expect(r.validation_steps.length).toBeGreaterThan(2);
  });
  it("B/C. low-confidence trend is not overstated and history limitation shown", () => {
    const h = hist([400, 400, 450, 700, 1200, 1300, 900, 500, 420, 300, 310, 300]);
    const r = make(google.map((k) => ({ ...k, monthly_searches: h })), amz());
    expect(r.score.components.trend.confidence).toBe("low");
    expect(r.findings.map((f) => f.text)).toContain("Search interest shows a possible seasonal signal.");
    expect(r.findings.map((f) => f.rule)).toContain("trend_low_confidence");
    expect(r.trend.history_note).toMatch(/12 months/);
    expect(rules(r.cautions)).toContain("low_history_depth");
    expect(rules(r.validation_steps)).toContain("trend_history");
  });
  it("D. strong competition -> caution and competitor review step", () => {
    const r = make(google, amz({ review_count: 9000, rating: 4.7, is_best_seller: true, bought_past_month: 3000 }));
    expect(rules(r.cautions)).toContain("high_strong_competitor_ratio");
    expect(rules(r.validation_steps)).toContain("competition_review");
  });
  it("E. missing purchase counts stay unknown, not zero", () => {
    const r = make(google, amz({ bought_past_month: null }));
    expect(r.purchase.marketplace_purchase_score).toBeNull();
    expect(r.marketplace.sample_products.every((p) => p.bought_past_month === null)).toBe(true);
    expect(rules(r.cautions)).toContain("low_purchase_coverage");
  });
  it("F. insufficient final score -> no fake score", () => {
    const r = make(null, amz());
    expect(r.score.sufficient).toBe(false);
    expect(r.score.opportunity_score_display).toBeNull();
    expect(r.findings[0]!.text).toBe("Insufficient evidence to calculate a reliable Opportunity Score.");
  });
  it("H. snapshot references the exact score run and is deterministic", () => {
    const a = make(google, amz()), b = make(google, amz());
    expect(a.score.score_run_id).toBe("run-1");
    expect(a.score.score_version).toBe("score_v1_1");
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
  });
});
