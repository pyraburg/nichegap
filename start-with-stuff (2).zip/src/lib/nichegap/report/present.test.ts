import { describe, expect, it } from "vitest";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { readFileSync } from "node:fs";
import { band, COMPONENT_COPY, reportToc, scoreDisplay, strongestHypothesis } from "./present";
import { buildReportV3, type AiAnalysisRow } from "./report_v3";
import { buildReport } from "./report_v1";
import { buildReportV2 } from "./report_v2";
import { scoreV1_1 } from "../scoring/score_v1_1";

const job = { id: "j", query: "indoor herb garden", target_country: "US", language: "en", completed_at: null, created_at: "2026-10-01T00:00:00Z" };
const result = scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null });
const run = { id: "r", score_version: "score_v1_1", created_at: "2026-10-01T00:00:00Z", evidence_hash: "h", result } as never;
const ev = { google: null, amazon: [] };
const packet = { evidence: { community_posts: [{ id: "community_post_001", type: "community_post", platform: "reddit", title: "Basil dying", text: "terrible light here", created_at: "2026-09-01T00:00:00Z", url: "https://www.reddit.com/r/x/1", author: "secret_user" }],
  google_keyword_groups: [{ id: "google_kw_001", type: "google_keyword_group", keyword: "basil grow light", monthly_search_volume: 900 }] } };
const ids = ["community_post_001", "google_kw_001"];
const out = {
  analysis_version: "ai_analysis_v1", executive_summary: { text: "Lighting matters.", evidence_ids: ids },
  pain_point_clusters: [{ title: "Lighting", description: "Confusing lights", confidence: "high", evidence_ids: ids, evidence_count: 2 }],
  unmet_needs: [], existing_solution_complaints: [], customer_language: [],
  opportunity_hypotheses: [
    { hypothesis: "Beginner kit", rationale: "r1", confidence: "medium", evidence_ids: ids },
    { hypothesis: "Light selector", rationale: "r2", confidence: "high", evidence_ids: ids },
  ],
  risks_and_uncertainties: [], validation_recommendations: [],
};
const aiRow: AiAnalysisRow = { status: "completed", model: "m", analysis_version: "ai_analysis_v1", evidence_packet_hash: "x", completed_at: null, validated_output: out as never, evidence_packet: packet as never };

describe("report presentation helpers", () => {
  it("rounds the Opportunity Score for display only", () => {
    expect(scoreDisplay(66.2955)).toBe("66");
    expect(scoreDisplay(66.5)).toBe("67");
    expect(scoreDisplay(null)).toBeNull();
    const v = 66.2955; scoreDisplay(v); expect(v).toBe(66.2955);
  });
  it("component copy explains weights and Competition Opportunity direction", () => {
    expect(Object.keys(COMPONENT_COPY)).toEqual(["demand", "competition", "purchase_intent", "trend"]);
    expect(COMPONENT_COPY["competition"]!.plain).toMatch(/higher score means competition appears easier/i);
  });
  it("bands without inventing data", () => {
    expect(band(null)).toBe("Not enough data");
    expect(band(53, "competition")).toBe("Moderate");
    expect(band(78)).toBe("Strong");
  });
  it("strongest hypothesis uses validated confidence then evidence; never invents a ranking when none exist", () => {
    expect(strongestHypothesis([{ confidence: "medium", evidence_count: 9, h: "a" }, { confidence: "high", evidence_count: 2, h: "b" }])!.h).toBe("b");
    expect(strongestHypothesis([{ confidence: "high", evidence_count: 2, h: "a" }, { confidence: "high", evidence_count: 2, h: "b" }])!.h).toBe("a");
    expect(strongestHypothesis([])).toBeNull();
  });
  it("navigation includes Opportunities only when AI analysis exists", () => {
    expect(reportToc(true).map((t) => t.label)).toEqual(["Overview", "Market Evidence", "Customer Problems", "Opportunities", "Next Steps"]);
    expect(reportToc(false).map((t) => t.id)).toEqual(["overview", "market-evidence", "community-evidence", "next-steps"]);
  });
});

describe("report page rendering", () => {
  it("snapshot with AI shows Opportunity to Validate, labels and no internals", async () => {
    const { Snapshot } = await import("../../../routes/_authenticated/research_.$id.report");
    const s = buildReportV3(job, run, ev, null, aiRow, "t");
    const html = renderToStaticMarkup(createElement(Snapshot, { s: s as never, ai: s.ai }));
    expect(html).toContain("Opportunity to Validate");
    expect(html).toContain("Light selector");
    expect(html).toContain("not a guaranteed business opportunity");
    expect(html).toContain("AI analysis");
    expect(html).toContain("NicheGap calculation");
    expect(html).not.toMatch(/secret_user|community_post_001|google_kw_001|ai_analysis_v1|score_v1|DataForSEO|Apify|OpenAI/);
  });
  it("snapshot without AI has no AI content or empty AI blocks", async () => {
    const { Snapshot } = await import("../../../routes/_authenticated/research_.$id.report");
    const s = buildReportV3(job, run, ev, null, null, "t");
    const html = renderToStaticMarkup(createElement(Snapshot, { s: s as never, ai: null }));
    expect(html).not.toMatch(/Opportunity to Validate|AI analysis/);
    expect(html).toContain("Not enough data");
  });
  it("evidence lists are collapsed by default", async () => {
    const { AiAnalysisSection } = await import("../../../routes/_authenticated/research_.$id.report");
    const s = buildReportV3(job, run, ev, null, aiRow, "t");
    const html = renderToStaticMarkup(createElement(AiAnalysisSection, { a: s.ai }));
    expect(html).toContain("View supporting evidence");
    expect(html).not.toMatch(/<details[^>]*open/);
    expect(html).toContain('id="customer-problems"');
    expect(html).toContain('id="opportunities"');
  });
  it("navigation renders touch-friendly links to every part", async () => {
    const { ReportToc } = await import("../../../routes/_authenticated/research_.$id.report");
    const html = renderToStaticMarkup(createElement(ReportToc, { hasAi: true }));
    for (const id of ["overview", "market-evidence", "customer-problems", "opportunities", "next-steps"]) expect(html).toContain(`href="#${id}"`);
    expect(html).toContain("Jump to section");
  });
  it("v1/v2/v3 snapshots keep an identical stored score", () => {
    const v1 = buildReport(job, run, ev, "t"), v2 = buildReportV2(job, run, ev, null, "t"), v3 = buildReportV3(job, run, ev, null, aiRow, "t");
    expect(v2.score).toEqual(v1.score);
    expect(v3.score).toEqual(v1.score);
  });
});

describe("responsive and print styles", () => {
  const css = readFileSync("src/styles.css", "utf8");
  it("mobile turns report tables into labelled cards", () => {
    expect(css).toMatch(/@media \(max-width: 640px\)[\s\S]*\.rp \.ng-table thead \{ display: none; \}/);
    expect(css).toContain("content: attr(data-label)");
  });
  it("print hides navigation and evidence accordions, adds page numbers and avoids card splits", () => {
    expect(css).toMatch(/counter\(page\)/);
    expect(css).toMatch(/\.rp-toc, \.rp-jump \{ display: none !important; \}/);
    expect(css).toMatch(/\.rp-ev \{ display: none !important; \}/);
    expect(css).toMatch(/\.rp-snapshot, \.rp-validate, \.rp-hyp/);
  });
});
