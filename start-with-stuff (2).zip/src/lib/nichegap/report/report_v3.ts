// Customer Opportunity Report v3 = report_v2 snapshot + "AI Opportunity Analysis".
// Uses ONLY an already server-validated ai_analysis_v1 result and its stored evidence packet.
// Nothing here calls a model, rewrites AI text, or touches the score.
import { buildReportV2, safeLink, snippet, type CommunityEvidenceRow } from "./report_v2";
import type { ReportEvidence, ReportJob, ReportScoreRun } from "./report_v1";
import type { AnalysisV1, Confidence } from "../ai/analysis_schema_v1";

export const REPORT_VERSION_V3 = "report_v3";
const SHOWN_CONFIDENCE: Confidence[] = ["high", "medium", "low"]; // "insufficient" findings are not shown

export interface AiAnalysisRow {
  status: string;
  model: string | null;
  analysis_version: string | null;
  evidence_packet_hash: string | null;
  completed_at: string | null;
  validated_output: AnalysisV1 | null;
  evidence_packet: { evidence?: Record<string, Array<Record<string, unknown> & { id: string; type: string }>> } | null;
}

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const str = (v: unknown) => (typeof v === "string" && v.trim() ? v : null);

/** Whitelisted, identity-free view of one evidence item for customer display. */
export function resolveEvidence(item: Record<string, unknown> & { type: string }, posts: Map<string, Record<string, unknown>>) {
  switch (item.type) {
    case "community_post":
      return { kind: "Community discussion", platform: item["platform"] === "reddit" ? "Reddit" : str(item["platform"]), title: str(item["title"]),
        snippet: snippet(str(item["text"])), date: str(item["created_at"]), url: safeLink(str(item["url"])) };
    case "community_comment": {
      const parent = posts.get(String(item["post_id"]));
      return { kind: "Community comment", platform: parent?.["platform"] === "reddit" ? "Reddit" : str(parent?.["platform"]), title: parent ? `Comment on: ${str(parent["title"]) ?? "discussion"}` : "Comment",
        snippet: snippet(str(item["text"])), date: str(item["created_at"]), url: safeLink(str(parent?.["url"])) };
    }
    case "google_keyword_group":
      return { kind: "Google search demand", title: str(item["keyword"]), monthly_searches: num(item["monthly_search_volume"]), cpc_usd: num(item["cpc_usd"]), competition: str(item["google_ads_competition"]) };
    case "amazon_search":
      return { kind: "Amazon search", title: str(item["keyword"]), results_count: num(item["results_count"]) };
    case "amazon_product":
      return { kind: "Amazon product", title: str(item["title"]), price: num(item["price"]), currency: str(item["currency"]), rating: num(item["rating"]), review_count: num(item["review_count"]) };
    default:
      return null;
  }
}
export type ResolvedEvidence = NonNullable<ReturnType<typeof resolveEvidence>>;

export function buildAiSection(row: AiAnalysisRow | null) {
  const o = row?.validated_output;
  if (!row || row.status !== "completed" || !o || !row.evidence_packet?.evidence) return null;
  const all = Object.values(row.evidence_packet.evidence).flat();
  const byId = new Map(all.map((x) => [x.id, x]));
  const posts = new Map(all.filter((x) => x.type === "community_post").map((x) => [x.id, x]));
  // Replace packet IDs with short display refs (E1, E2…) so no internal identifiers reach the customer.
  const refOf = new Map<string, string>();
  const evidence: Record<string, ResolvedEvidence> = {};
  const refs = (ids: string[] | undefined) => (ids ?? []).flatMap((id) => {
    const item = byId.get(id); if (!item) return [];
    let ref = refOf.get(id);
    if (!ref) { const r = resolveEvidence(item, posts); if (!r) return []; ref = `E${refOf.size + 1}`; refOf.set(id, ref); evidence[ref] = r; }
    return [ref];
  });
  const shown = <T extends { confidence: Confidence; evidence_ids: string[] }>(xs: T[] | undefined) =>
    (xs ?? []).filter((x) => SHOWN_CONFIDENCE.includes(x.confidence)).map((x) => ({ x, ev: refs(x.evidence_ids) })).filter((r) => r.ev.length > 0);

  return {
    label: "AI ANALYSIS",
    model: row.model, analysis_version: row.analysis_version, evidence_packet_hash: row.evidence_packet_hash, completed_at: row.completed_at,
    intro: "AI Analysis interprets the market and community evidence collected above. It does not create market statistics, and it does not change the Opportunity Score or its classification.",
    executive_summary: { text: o.executive_summary?.text ?? "", evidence: refs(o.executive_summary?.evidence_ids) },
    problems: shown(o.pain_point_clusters).map(({ x, ev }) => ({ title: x.title, description: x.description, confidence: x.confidence, evidence_count: ev.length, evidence: ev })),
    unmet_needs: shown(o.unmet_needs).map(({ x, ev }) => ({ need: x.need, explanation: x.explanation, confidence: x.confidence, evidence: ev })),
    complaints: shown(o.existing_solution_complaints).map(({ x, ev }) => ({ complaint: x.complaint, solution_type: x.solution_type ?? null, confidence: x.confidence, evidence: ev })),
    language: (o.customer_language ?? []).map((l) => ({ phrase: l.phrase, verified_quote: l.kind === "verbatim", evidence: refs(l.evidence_ids) })).filter((l) => l.evidence.length > 0),
    hypotheses: shown(o.opportunity_hypotheses).map(({ x, ev }) => ({ hypothesis: x.hypothesis, rationale: x.rationale, confidence: x.confidence, evidence_count: ev.length, evidence: ev })),
    risks: (o.risks_and_uncertainties ?? []).map((r) => ({ risk: r.risk, evidence: refs(r.evidence_ids) })).filter((r) => r.evidence.length > 0),
    validation_steps: (o.validation_recommendations ?? []).map((v) => ({ recommendation: v.recommendation, addresses: v.addresses, evidence: refs(v.evidence_ids) })),
    hypotheses_note: "These are evidence-grounded hypotheses to validate, not guaranteed business opportunities.",
    evidence,
  };
}
export type AiSection = NonNullable<ReturnType<typeof buildAiSection>>;

export function buildReportV3(job: ReportJob, run: ReportScoreRun, ev: ReportEvidence, community: CommunityEvidenceRow | null, ai: AiAnalysisRow | null, generatedAt: string) {
  const base = buildReportV2(job, run, ev, community, generatedAt);
  const section = buildAiSection(ai);
  return {
    ...base,
    report_version: REPORT_VERSION_V3,
    ai: section,
    provenance: { ...base.provenance, report_model: REPORT_VERSION_V3, ai_model: section ? section.model : null },
  };
}
export type ReportSnapshotV3 = ReturnType<typeof buildReportV3>;
