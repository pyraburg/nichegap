import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";
import { createElement } from "react";
import { buildCommunitySection, buildReportV2, snippet, safeLink, type CommunityEvidenceRow } from "./report_v2";
import { buildReport } from "./report_v1";
import { scoreV1_1 } from "../scoring/score_v1_1";

const disc = (id: string, o: Record<string, unknown> = {}) => ({ discussion_id: id, source_platform: "reddit", discussion_url: `https://www.reddit.com/r/x/comments/${id}/`, title: `Title ${id}`, body: "My basil keeps dying indoors, any help?", created_at: "2026-09-20T00:00:00Z", score: 5, comment_count: 3, author: "secret_user", author_fullname: "t2_secret", ...o });
const pa = (id: string, score: number, band = "high") => ({ discussion_id: id, platform: "reddit", relevance: { score, band }, recency: "d0_30", signals: { flags: { difficulty: true, help_seeking: true, frustration: false, replacement: false, purchase: false } } });
const row = (relevant: number, confidence: string, extra: Partial<CommunityEvidenceRow["processed_data"]> = {}): CommunityEvidenceRow => ({
  id: "rd1", collected_at: "2026-10-06T20:00:00Z",
  processed_data: {
    discussions: Array.from({ length: 8 }, (_, i) => disc(`d${i}`)),
    analysis: {
      version: "community_signals_v1",
      metrics: { relevant_discussions: relevant, relevant_comments: 124, signal_counts: { difficulty: 51, help_seeking: 41, purchase: 39, replacement: 27, frustration: 19 }, recency: { d0_30: 10, d31_90: 14, d91_365: 14, d365_plus: 0, unknown: 0 } },
      evidence_quality: { score: 89.25, confidence },
      post_analysis: [...Array.from({ length: 7 }, (_, i) => pa(`d${i}`, 100 - i)), pa("d7", 50, "weak")],
    },
    per_query: Array.from({ length: 8 }, (_, i) => ({ query: `q${i}` })),
    ...extra,
  },
});

describe("report_v2 community section", () => {
  const c = buildCommunitySection(row(38, "high"));
  it("produces customer metrics and a descriptive summary", () => {
    expect(c.status).toBe("ok");
    if (c.status === "missing") return;
    expect(c.metrics.relevant_discussions).toBe(38);
    expect(c.metrics.relevant_comments).toBe(124);
    expect(c.summary).toBe("NicheGap found 38 relevant public discussions and 124 relevant comments related to this market. The evidence contains repeated difficulty, help-seeking, purchase, alternative and frustration language. Community evidence quality is high.");
    expect(c.summary).not.toMatch(/pain point|struggle with|desperately|\bAI\b/);
  });
  it("limits samples to high-relevance discussions with whitelisted fields only", () => {
    if (c.status === "missing") return;
    expect(c.samples).toHaveLength(5);
    expect(JSON.stringify(c)).not.toMatch(/secret_user|t2_secret|author/);
    expect(c.samples[0]!.signals).toEqual(["difficulty", "help-seeking"]);
    expect(c.samples[0]!.snippet).toBe("My basil keeps dying indoors, any help?");
  });
  it("source links only from allowed hosts", () => {
    expect(safeLink("https://www.reddit.com/r/x/")).toBe("https://www.reddit.com/r/x/");
    expect(safeLink("javascript:alert(1)")).toBeNull();
    expect(safeLink("https://evil.example/")).toBeNull();
  });
  it("snippets keep original words and truncate at a word boundary", () => {
    const s = snippet("word ".repeat(100), 30)!;
    expect(s.endsWith("…")).toBe(true);
    expect(s.replace("…", "").trim().split(" ").every((w) => w === "word")).toBe(true);
  });
  it("insufficient community evidence shows no samples and a cautious summary", () => {
    const i = buildCommunitySection(row(3, "insufficient"));
    expect(i.status).toBe("insufficient");
    if (i.status === "missing") return;
    expect(i.samples).toHaveLength(0);
    expect(i.summary).toMatch(/not enough community evidence/);
  });
  it("missing community data is handled", () => {
    expect(buildCommunitySection(null).status).toBe("missing");
    expect(buildCommunitySection({ id: "x", collected_at: null, processed_data: null }).status).toBe("missing");
  });
  it("engagement shown only when genuinely available", () => {
    const r = row(38, "high"); r.processed_data!.discussions![0] = disc("d0", { score: null, comment_count: null }) as never;
    const s = buildCommunitySection(r);
    if (s.status === "missing") return;
    expect(s.samples[0]!.upvotes).toBeNull();
    expect(s.samples[0]!.comments).toBeNull();
  });
  it("renders the section with real-data label and no AI section", async () => {
    const { CommunitySection } = await import("../../../routes/_authenticated/research_.$id.report");
    const html = renderToStaticMarkup(createElement(CommunitySection, { c }));
    expect(html).toContain("Customer Problem Evidence");
    expect(html).toContain("Real market data");
    expect(html).toContain('rel="noopener noreferrer nofollow"');
    expect(html).not.toMatch(/AI analysis|secret_user/i);
  });
  it("score regression: v2 keeps the v1 score block identical", () => {
    const result = scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null });
    const job = { id: "j", query: "indoor herb garden", target_country: "US", language: "en", completed_at: null, created_at: "2026-10-01T00:00:00Z" };
    const run = { id: "r", score_version: "score_v1_1", created_at: "2026-10-01T00:00:00Z", evidence_hash: "h", result } as never;
    const v1 = buildReport(job, run, { google: null, amazon: [] }, "t");
    const v2 = buildReportV2(job, run, { google: null, amazon: [] }, row(38, "high"), "t");
    expect(v2.score).toEqual(v1.score);
    expect(v2.report_version).toBe("report_v2");
  });
});
