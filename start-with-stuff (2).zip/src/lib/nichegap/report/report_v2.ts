// Customer Opportunity Report v2 = report_v1 snapshot + "Customer Problem Evidence" (descriptive community data).
// Deterministic; uses only stored evidence. No AI, no rescoring, no pain-point interpretation.
import { buildReport, type ReportEvidence, type ReportJob, type ReportScoreRun } from "./report_v1";

export const REPORT_VERSION_V2 = "report_v2";
export const REPORT_V2_COMMUNITY_RULES = {
  max_samples: 5,
  sample_band: "high",
  snippet_chars: 240,
  allowed_link_prefixes: ["https://www.reddit.com/", "https://reddit.com/", "https://old.reddit.com/"],
} as const;
const R = REPORT_V2_COMMUNITY_RULES;

const SIGNAL_LABELS = { difficulty: "difficulty", help_seeking: "help-seeking", purchase: "purchase", replacement: "alternative", frustration: "frustration" } as const;
type SignalKey = keyof typeof SIGNAL_LABELS;
const SIGNAL_ORDER: SignalKey[] = ["difficulty", "help_seeking", "frustration", "replacement", "purchase"];

interface StoredDiscussion { discussion_id: string; source_platform: string; discussion_url: string | null; title: string | null; body: string | null; created_at: string | null; score: number | null; comment_count: number | null }
interface StoredPostAnalysis { discussion_id: string; platform: string; relevance: { score: number; band: string }; recency: string; signals: { flags: Record<string, boolean> } }
export interface CommunityEvidenceRow {
  id: string; collected_at: string | null;
  processed_data: {
    discussions?: StoredDiscussion[];
    analysis?: {
      version?: string;
      metrics?: { relevant_discussions?: number; relevant_comments?: number; total_discussions?: number; unique_discussions?: number; signal_counts?: Partial<Record<SignalKey, number>>; recency?: Record<string, number> };
      evidence_quality?: { score?: number; confidence?: string };
      post_analysis?: StoredPostAnalysis[];
    };
    per_query?: Array<{ query: string }>;
  } | null;
}

/** Original text, trimmed to a word boundary. Never rewritten. */
export function snippet(text: string | null, max: number = R.snippet_chars): string | null {
  if (!text) return null;
  const t = text.replace(/\s+/g, " ").trim();
  if (t.length <= max) return t;
  const cut = t.slice(0, max);
  const sp = cut.lastIndexOf(" ");
  return `${(sp > max * 0.6 ? cut.slice(0, sp) : cut).trim()}…`;
}
export const safeLink = (u: string | null) => (u && R.allowed_link_prefixes.some((p) => u.startsWith(p)) ? u : null);
const RECENCY_LABEL: Record<string, string> = { d0_30: "Last 30 days", d31_90: "31–90 days ago", d91_365: "3–12 months ago", d365_plus: "Over a year ago", unknown: "Date unknown" };

export function buildCommunitySection(row: CommunityEvidenceRow | null) {
  const a = row?.processed_data?.analysis;
  if (!row || !a?.metrics) {
    return { status: "missing" as const, summary: "Community discussion evidence has not been collected for this research yet.", research_data_id: null };
  }
  const m = a.metrics;
  const relevant = m.relevant_discussions ?? 0;
  const counts = Object.fromEntries(SIGNAL_ORDER.map((k) => [k, m.signal_counts?.[k] ?? 0])) as Record<SignalKey, number>;
  const confidence = a.evidence_quality?.confidence ?? "insufficient";
  const recency = ["d0_30", "d31_90", "d91_365", "d365_plus", "unknown"].map((k) => ({ key: k, label: RECENCY_LABEL[k]!, count: m.recency?.[k] ?? 0 }));
  const present = SIGNAL_ORDER.filter((k) => counts[k] > 0).sort((x, y) => counts[y] - counts[x] || SIGNAL_ORDER.indexOf(x) - SIGNAL_ORDER.indexOf(y));
  const list = (xs: string[]) => (xs.length <= 1 ? xs.join("") : `${xs.slice(0, -1).join(", ")} and ${xs[xs.length - 1]}`);
  const insufficient = confidence === "insufficient";
  const summary = insufficient
    ? `NicheGap found ${relevant} relevant public discussion${relevant === 1 ? "" : "s"} related to this market. This is not enough community evidence to draw conclusions.`
    : `NicheGap found ${relevant} relevant public discussions and ${m.relevant_comments ?? 0} relevant comments related to this market.${present.length ? ` The evidence contains repeated ${list(present.map((k) => SIGNAL_LABELS[k]))} language.` : ""} Community evidence quality is ${confidence}.`;

  const byId = new Map((row.processed_data?.discussions ?? []).map((d) => [d.discussion_id, d]));
  const samples = insufficient ? [] : (a.post_analysis ?? [])
    .filter((p) => p.relevance.band === R.sample_band && byId.has(p.discussion_id))
    .map((p) => ({ p, d: byId.get(p.discussion_id)! }))
    .sort((x, y) => y.p.relevance.score - x.p.relevance.score || (y.d.created_at ?? "").localeCompare(x.d.created_at ?? "") || x.d.discussion_id.localeCompare(y.d.discussion_id))
    .slice(0, R.max_samples)
    // Only whitelisted, non-identity fields are copied into the snapshot.
    .map(({ p, d }) => ({
      title: d.title, snippet: snippet(d.body) ?? null, platform: d.source_platform === "reddit" ? "Reddit" : d.source_platform,
      created_at: d.created_at, recency: RECENCY_LABEL[p.recency] ?? "Date unknown", relevance_band: p.relevance.band,
      signals: SIGNAL_ORDER.filter((k) => p.signals.flags[k]).map((k) => SIGNAL_LABELS[k]),
      url: safeLink(d.discussion_url),
      upvotes: typeof d.score === "number" ? d.score : null, comments: typeof d.comment_count === "number" ? d.comment_count : null,
    }));

  return {
    status: insufficient ? ("insufficient" as const) : ("ok" as const),
    research_data_id: row.id, collected_at: row.collected_at, analysis_version: a.version ?? null,
    summary,
    metrics: {
      relevant_discussions: relevant, relevant_comments: m.relevant_comments ?? 0,
      evidence_quality: typeof a.evidence_quality?.score === "number" ? a.evidence_quality.score : null, confidence,
      recency, signals: SIGNAL_ORDER.map((k) => ({ key: k, label: SIGNAL_LABELS[k], count: counts[k] })),
      searches: row.processed_data?.per_query?.length ?? null, platforms: ["Reddit"],
    },
    samples,
    notes: [
      "Signals count posts and comments containing words such as \u201chard\u201d, \u201chelp\u201d, \u201cworth it\u201d or \u201calternative\u201d. They are indicators only; NicheGap has not yet interpreted or ranked specific customer problems.",
      "Discussion excerpts are original public text, shortened. Usernames and profile details are not stored or shown.",
    ],
  };
}

export function buildReportV2(job: ReportJob, run: ReportScoreRun, ev: ReportEvidence, community: CommunityEvidenceRow | null, generatedAt: string) {
  const base = buildReport(job, run, ev, generatedAt);
  const section = buildCommunitySection(community);
  return {
    ...base,
    report_version: REPORT_VERSION_V2,
    community: section,
    provenance: {
      ...base.provenance,
      report_model: REPORT_VERSION_V2,
      sources: [...base.provenance.sources, ...(section.status !== "missing" ? [{ name: "Public community discussions (Reddit)", provider: "Apify", collected_at: section.collected_at ?? null }] : [])],
    },
  };
}
export type ReportSnapshotV2 = ReturnType<typeof buildReportV2>;
