// Server-only: Google demand + Amazon supply stages (shared by the legacy runner and pipeline_v1).
const PROVIDER = "dataforseo";
const GOOGLE_DATA_TYPE = "google_keyword_demand";
const GOOGLE_CACHE_DAYS = 30;

export type Admin = typeof import("@/integrations/supabase/client.server") extends { supabaseAdmin: infer A } ? A : never;

export interface Job {
  id: string;
  user_id: string;
  query: string;
  target_country: string;
  language: string;
  status: string;
  stage: string;
}


/** DataForSEO per-job ceiling check; logs a $0 refusal row internally when blocked. */
async function dfsGuard(admin: Admin, job: Job, userId: string, kind: "google" | "amazon", endpoint: string) {
  const { canStartDfsCall, dfsCostConfig, DFS_REFUSED_STATUS } = await import("./dataforseo-cost");
  const { data: rows } = await admin.from("external_api_usage").select("cost, cache_hit, status")
    .eq("provider", PROVIDER).eq("research_query_id", job.id);
  const gate = canStartDfsCall(rows ?? [], kind, dfsCostConfig(process.env));
  if (gate.allowed) return true;
  await admin.from("external_api_usage").insert({
    user_id: userId, research_query_id: job.id, provider: PROVIDER, endpoint,
    cost: 0, cache_hit: false, status: DFS_REFUSED_STATUS, cost_status: "final", cost_source: `refused:${gate.reason}`,
  });
  console.warn(`DataForSEO ceiling refusal job=${job.id} kind=${kind} reason=${gate.reason} spent=${gate.spent_usd}`);
  return false;
}

export async function runGoogleStage(admin: Admin, job: Job, userId: string) {
  const { fetchKeywordDemand, normalizeQuery, DFS_ENDPOINT } = await import("./dataforseo.server");
  const gf = await import("./google_fallback_v1");
  const now = new Date();
  const base = { research_query_id: job.id, provider: PROVIDER, target_country: job.target_country, language: job.language };

  return gf.runGoogleWithFallback(job.query, {
    normalize: normalizeQuery,
    findJobAttempt: async () => {
      const { data } = await admin.from("research_data").select("id, processed_data")
        .eq("research_query_id", job.id).eq("data_type", gf.GOOGLE_ATTEMPT_DATA_TYPE)
        .order("collected_at", { ascending: false }).limit(1).maybeSingle();
      return data ? { id: data.id, keywords: ((data.processed_data as { keywords?: import("./dataforseo.server").KeywordEvidence[] } | null)?.keywords) ?? [] } : null;
    },
    lookupCache: async (normalized) => {
      const { data } = await admin.from("research_data")
        .select("id, processed_data, collected_at, expires_at")
        .eq("provider", PROVIDER).in("data_type", [GOOGLE_DATA_TYPE, gf.GOOGLE_ATTEMPT_DATA_TYPE])
        .eq("normalized_query", normalized)
        .eq("target_country", job.target_country).eq("language", job.language)
        .eq("cache_hit", false)
        .gt("expires_at", new Date().toISOString())
        .order("collected_at", { ascending: false })
        .limit(1).maybeSingle();
      return data ?? null;
    },
    guard: () => dfsGuard(admin, job, userId, "google", DFS_ENDPOINT),
    fetch: (seed) => fetchKeywordDemand(seed, job.target_country, job.language),
    logUsage: async (r) => {
      await admin.from("external_api_usage").insert({
        user_id: userId, research_query_id: job.id, provider: PROVIDER,
        endpoint: DFS_ENDPOINT, cost: r.cost, cache_hit: r.cache_hit, status: r.status,
      });
    },
    insert: async (r) => {
      const expires = new Date(now.getTime() + GOOGLE_CACHE_DAYS * 86400000).toISOString();
      const { data, error } = await admin.from("research_data").insert({
        ...base, data_type: r.data_type, source_query: r.seed, normalized_query: normalizeQuery(r.seed),
        raw_data: r.raw as never, processed_data: r.processed as never, cache_hit: r.cache_hit,
        collected_at: r.collected_at ?? now.toISOString(), expires_at: r.expires_at ?? expires,
      }).select("id").single();
      if (error) throw error;
      return data.id;
    },
  });
}

export async function runAmazonStage(admin: Admin, job: Job, userId: string, handoff?: { keywords?: import("./dataforseo.server").KeywordEvidence[] }) {
  const am = await import("./amazon.server");
  const ac = await import("./amazon_collect_v1");
  const { dfsCostConfig } = await import("./dataforseo-cost");
  const { normalizeQuery } = await import("./dataforseo.server");
  const now = new Date();
  const locale = am.amazonLocale(job.target_country, job.language) ?? "unsupported";

  // Google handoff: in-process keywords when the same run just produced them; otherwise (background resume/restart)
  // read this job's own persisted Google evidence row — the durable handoff.
  let keywords = handoff?.keywords;
  if (!keywords) {
    const { data: googleRows } = await admin.from("research_data").select("processed_data")
      .eq("research_query_id", job.id).eq("data_type", GOOGLE_DATA_TYPE)
      .order("collected_at", { ascending: false }).limit(1);
    keywords = ((googleRows?.[0]?.processed_data as { keywords?: import("./dataforseo.server").KeywordEvidence[] } | null)?.keywords) ?? [];
  }
  if (!keywords.length) return { ok: false as const, error: "No keyword evidence available for marketplace research." };

  const selected = am.selectAmazonKeywords(keywords, job.query);
  if (!selected.length) return { ok: false as const, error: "No commercially relevant keywords could be selected." };
  const selectionRecord = selected.map((s) => ({ keyword: s.keyword, score: s.score, reasons: s.reasons }));

  // Resume: keywords already collected for this job are reused, never re-fetched or re-copied.
  const { data: have } = await admin.from("research_data").select("normalized_query")
    .eq("research_query_id", job.id).eq("data_type", am.AMAZON_DATA_TYPE);
  const already = new Set((have ?? []).map((r) => r.normalized_query));
  const todo = selectionRecord.map((s) => ({ keyword: s.keyword, normalized: normalizeQuery(s.keyword), selection: s }))
    .filter((s) => !already.has(s.normalized));

  const base = { research_query_id: job.id, provider: PROVIDER, data_type: am.AMAZON_DATA_TYPE, target_country: job.target_country, language: job.language };
  const res = await ac.collectAmazon(todo, {
    costConfig: dfsCostConfig(process.env),
    cacheKey: (n) => ac.amazonCacheKey({ endpoint: am.AMAZON_ENDPOINT, dataType: am.AMAZON_DATA_TYPE, country: job.target_country, locale, normalized: n }),
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
    lookupCache: async (norms) => {
      const { data, error } = await admin.from("research_data")
        .select("id, normalized_query, processed_data, collected_at, expires_at")
        .eq("provider", PROVIDER).eq("data_type", am.AMAZON_DATA_TYPE)
        .in("normalized_query", norms)
        .eq("target_country", job.target_country).eq("language", job.language)
        .eq("cache_hit", false).gt("expires_at", new Date().toISOString())
        .order("collected_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
    usageRows: async () => (await admin.from("external_api_usage").select("cost, cache_hit, status").eq("provider", PROVIDER).eq("research_query_id", job.id)).data ?? [],
    insertUsage: async (rows) => {
      const { error } = await admin.from("external_api_usage").insert(rows.map((r) => ({
        user_id: userId, research_query_id: job.id, provider: PROVIDER, endpoint: am.AMAZON_ENDPOINT,
        cost: r.cost, cache_hit: r.cache_hit, status: r.status,
        ...(r.cost_source ? { cost_status: "final", cost_source: r.cost_source } : {}),
      })));
      if (error) throw error;
    },
    insertEvidence: async (rows) => {
      const { error } = await admin.from("research_data").insert(rows.map((r) => r.cached ? {
        ...base, source_query: r.sel.keyword, normalized_query: r.sel.normalized,
        raw_data: { cached_from_research_data_id: r.cached.id },
        processed_data: { ...(r.cached.processed_data as object), selection: r.sel.selection } as never,
        cache_hit: true, collected_at: r.cached.collected_at, expires_at: r.cached.expires_at,
      } : {
        ...base, source_query: r.sel.keyword, normalized_query: r.sel.normalized,
        raw_data: r.fetched!.raw as never,
        processed_data: { ...am.normalizeAmazonResult(r.fetched!.result as Record<string, unknown>, r.sel.keyword, job.query, r.fetched!.collectedAt), selection: r.sel.selection } as never,
        collected_at: r.fetched!.collectedAt, expires_at: new Date(now.getTime() + am.AMAZON_CACHE_DAYS * 86400000).toISOString(),
      }));
      if (error) throw error;
    },
    claim: async (key) => {
      const { data, error } = await admin.rpc("claim_provider_fetch", { _key: key, _job: job.id, _ttl_seconds: ac.SINGLE_FLIGHT_LEASE_SECONDS });
      if (error) throw error;
      return (data as string | null) ?? null;
    },
    release: async (key, token) => { await admin.rpc("release_provider_fetch", { _key: key, _token: token }); },
    fetch: async (kw) => {
      const r = await am.fetchAmazonProducts(kw, job.target_country, job.language);
      return r.ok ? { ok: true, cost: r.cost, raw: r.raw, result: r.result } : { ok: false, cost: r.cost, raw: r.raw };
    },
  });
  if (res.ceiling) {
    console.warn(`DataForSEO ceiling refusal job=${job.id} kind=amazon`);
    return { ok: false as const, error: "DATAFORSEO_CEILING" };
  }
  if (!res.ok) {
    const failed = res.outcomes.filter((o) => o.kind !== "cache_hit" && o.kind !== "shared_hit" && o.kind !== "fetched").map((o) => o.keyword);
    return { ok: false as const, error: `Amazon marketplace research failed for "${failed.join('", "')}". Completed results were preserved; retry to resume.` };
  }
  return { ok: true as const, selected: selectionRecord };
}
