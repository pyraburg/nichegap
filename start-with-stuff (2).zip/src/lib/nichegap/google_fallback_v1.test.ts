/* eslint-disable @typescript-eslint/no-explicit-any */
import { describe, expect, it } from "vitest";
import { canStartDfsCall, dfsCostConfig } from "./dataforseo-cost";
import { deriveFallbackSeed, isRelevant, isUsableGoogleResult, runGoogleWithFallback, GOOGLE_ATTEMPT_DATA_TYPE, GOOGLE_DATA_TYPE, type GoogleFallbackDeps } from "./google_fallback_v1";
import type { KeywordEvidence } from "./dataforseo.server";

const kw = (keyword: string, search_volume: number | null): KeywordEvidence => ({ keyword, search_volume, competition: null, competition_index: null, cpc: null, low_top_of_page_bid: null, high_top_of_page_bid: null, monthly_searches: null });
const normalize = (q: string) => q.trim().toLowerCase().replace(/\s+/g, " ");

/** In-memory DB + mock provider. No network. Cost rows feed the real ceiling logic. */
function world(responses: Record<string, KeywordEvidence[] | "error">, opts: { spent?: number; crashAfterInsert?: number } = {}) {
  const rows: Array<{ id: string; data_type: string; seed: string; cache_hit: boolean; processed: any }> = [];
  const usage: Array<{ cost: number | null; cache_hit: boolean; status: string }> = opts.spent ? [{ cost: opts.spent, cache_hit: false, status: "success" }] : [];
  const fetches: string[] = []; let inserts = 0;
  const deps: GoogleFallbackDeps = {
    normalize,
    findJobAttempt: async () => { const r = rows.find((x) => x.data_type === GOOGLE_ATTEMPT_DATA_TYPE); return r ? { id: r.id, keywords: r.processed.keywords as KeywordEvidence[] } : null; },
    lookupCache: async () => null,
    guard: async () => { const g = canStartDfsCall(usage, "google", dfsCostConfig({})); if (!g.allowed) usage.push({ cost: 0, cache_hit: false, status: "refused_ceiling" }); return g.allowed; },
    fetch: async (seed) => { fetches.push(seed); const r = responses[seed]; return r === "error" || !r ? { ok: false, cost: 0.075, raw: {} } : { ok: true, cost: 0.075, raw: { seed }, keywords: r }; },
    logUsage: async (u) => { usage.push(u); },
    insert: async (r) => { const id = `rd${rows.length + 1}`; rows.push({ id, ...r }); inserts++; if (opts.crashAfterInsert === inserts) throw new Error("crash"); return id; },
  };
  return { deps, rows, usage, fetches, final: () => rows.filter((r) => r.data_type === GOOGLE_DATA_TYPE) };
}

describe("google_fallback_v1 seed derivation", () => {
  it("keeps intent, never single word", () => {
    expect(deriveFallbackSeed("meal planning for busy parents")).toBe("meal planning");
    expect(deriveFallbackSeed("make money online")).toBe("make money");
    expect(deriveFallbackSeed("indoor herb gardening")).toBeNull();
    expect(deriveFallbackSeed("money online")).toBeNull();
    expect(deriveFallbackSeed("weightloss for busy career women")).toBeNull(); // "weightloss" alone is 1 word
  });
  it("relevance ignores filler words, rejects unrelated broad terms", () => {
    expect(isRelevant("meal plans for the week", "meal planning")).toBe(true);
    expect(isRelevant("weekly meal planner", "meal planning")).toBe(false);
    expect(isRelevant("money", "make money")).toBe(false);
    expect(isRelevant("ways to make money from home", "make money")).toBe(true);
  });
  it("zero and null volumes are unusable", () => {
    expect(isUsableGoogleResult([kw("meal planning for busy parents", null), kw("meal planning for busy parents", 0)], "meal planning for busy parents")).toBe(false);
    expect(isUsableGoogleResult([kw("meal planning for busy parents", 10)], "meal planning for busy parents")).toBe(true);
  });
});

describe("google_fallback_v1 orchestration (mock-only)", () => {
  const Q = "meal planning for busy parents";
  it("useful first response: one call, no fallback", async () => {
    const w = world({ [Q]: [kw(Q, 50)] });
    const r = await runGoogleWithFallback(Q, w.deps);
    expect(r).toMatchObject({ ok: true, fallback: "not_needed" });
    expect(w.fetches).toEqual([Q]);
    expect(w.final()).toHaveLength(1);
    expect(w.rows.some((x) => x.data_type === GOOGLE_ATTEMPT_DATA_TYPE)).toBe(false);
  });
  it("zero-volume first response -> fallback success with provenance and filtered terms", async () => {
    const w = world({ [Q]: [kw(Q, 0)], "meal planning": [kw("meal planning", 40500), kw("meal plans for families", 900), kw("weekly dinner ideas", 5000)] });
    const r = await runGoogleWithFallback(Q, w.deps);
    expect(r).toMatchObject({ ok: true, fallback: "used" });
    expect(w.fetches).toEqual([Q, "meal planning"]);
    const f = w.final(); expect(f).toHaveLength(1);
    expect(f[0]!.seed).toBe("meal planning");
    expect((f[0]!.processed.keywords as KeywordEvidence[]).map((k) => k.keyword)).toEqual(["meal planning", "meal plans for families"]);
    expect(f[0]!.processed.seed_provenance).toMatchObject({ original_query: Q, seed_query: "meal planning", role: "fallback", primary_research_data_id: "rd1", excluded_unrelated_count: 1 });
    expect(w.usage.filter((u) => !u.cache_hit && u.status === "success")).toHaveLength(2);
  });
  it("fallback still empty: stores real empty evidence, no third call", async () => {
    const w = world({ [Q]: [kw(Q, null)], "meal planning": [kw("meal planning", null)] });
    const r = await runGoogleWithFallback(Q, w.deps);
    expect(r).toMatchObject({ ok: true, fallback: "empty" });
    expect(w.fetches).toHaveLength(2);
  });
  it("ceiling blocked: no paid fallback, original evidence kept, refusal logged", async () => {
    const w = world({ [Q]: [kw(Q, null)] }, { spent: 0.1 }); // 0.1 + 0.075 + 0.1 reserve > 0.25
    const r = await runGoogleWithFallback(Q, w.deps);
    expect(r).toMatchObject({ ok: true, fallback: "blocked" });
    expect(w.fetches).toEqual([Q]);
    expect(w.usage.some((u) => u.status === "refused_ceiling")).toBe(true);
    expect(w.final()[0]!.processed.seed_provenance).toMatchObject({ role: "original", fallback_status: "blocked" });
  });
  it("unknown cost blocks the fallback call", async () => {
    const w = world({ [Q]: [kw(Q, null)] });
    w.deps.fetch = async (s) => { w.fetches.push(s); return { ok: true, cost: null, raw: {}, keywords: [kw(Q, null)] }; };
    expect(await runGoogleWithFallback(Q, w.deps)).toMatchObject({ fallback: "blocked" });
    expect(w.fetches).toEqual([Q]);
  });
  it("crash after persisting original attempt: resume never repeats the paid original call", async () => {
    const w = world({ [Q]: [kw(Q, null)], "meal planning": [kw("meal planning", 40500)] }, { crashAfterInsert: 1 });
    await expect(runGoogleWithFallback(Q, w.deps)).rejects.toThrow("crash");
    expect(w.fetches).toEqual([Q]);
    const r = await runGoogleWithFallback(Q, w.deps);
    expect(r).toMatchObject({ ok: true, fallback: "used" });
    expect(w.fetches).toEqual([Q, "meal planning"]); // original fetched exactly once
  });
  it("cached seed results are reused at $0", async () => {
    const w = world({ [Q]: [kw(Q, null)] });
    w.deps.lookupCache = async (n) => n === "meal planning" ? { id: "c1", processed_data: { keywords: [kw("meal planning", 40500)] }, collected_at: "x", expires_at: "y" } : null;
    expect(await runGoogleWithFallback(Q, w.deps)).toMatchObject({ fallback: "used" });
    expect(w.fetches).toEqual([Q]);
  });
  it("no derivable seed: single call only", async () => {
    const w = world({ "indoor herb gardening": [] });
    expect(await runGoogleWithFallback("indoor herb gardening", w.deps)).toMatchObject({ ok: true, fallback: "no_seed" });
    expect(w.fetches).toHaveLength(1);
  });
});
