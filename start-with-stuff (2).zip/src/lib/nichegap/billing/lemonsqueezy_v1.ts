// Pure Lemon Squeezy billing logic (no I/O): signature check, server-side entitlement mapping,
// and webhook → action decisions. Only verified webhooks may produce credit grants.

export type PlanKey = "monthly" | "topup_5" | "topup_15" | "topup_40";
export interface Entitlement { plan: PlanKey; kind: "subscription" | "topup"; credits: number; credit_type: "monthly" | "purchased"; label: string; price_usd: number }

/** The only source of truth for what a variant grants. Prices are for display; Lemon Squeezy charges. */
export const ENTITLEMENTS: Record<PlanKey, Entitlement> = {
  monthly: { plan: "monthly", kind: "subscription", credits: 10, credit_type: "monthly", label: "NicheGap Monthly", price_usd: 9.99 },
  topup_5: { plan: "topup_5", kind: "topup", credits: 5, credit_type: "purchased", label: "5 Research Credits", price_usd: 5.99 },
  topup_15: { plan: "topup_15", kind: "topup", credits: 15, credit_type: "purchased", label: "15 Research Credits", price_usd: 14.99 },
  topup_40: { plan: "topup_40", kind: "topup", credits: 40, credit_type: "purchased", label: "40 Research Credits", price_usd: 34.99 },
};

export type VariantMap = Partial<Record<PlanKey, string>>;

export function planForVariant(map: VariantMap, variantId: unknown): Entitlement | null {
  if (variantId == null) return null;
  const v = String(variantId);
  for (const k of Object.keys(map) as PlanKey[]) if (map[k] && map[k] === v) return ENTITLEMENTS[k];
  return null;
}

const toHex = (b: ArrayBuffer) => [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");

/** HMAC-SHA256(raw body, signing secret) hex vs X-Signature, constant-time compare. */
export async function verifySignature(rawBody: string, signature: string | null, secret: string): Promise<boolean> {
  if (!signature || !secret) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const expected = toHex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody)));
  const got = signature.trim().toLowerCase();
  if (got.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ got.charCodeAt(i);
  return diff === 0;
}

export interface WebhookPayload {
  meta?: { event_name?: string; test_mode?: boolean; custom_data?: Record<string, unknown> | null };
  data?: { id?: string | number; type?: string; attributes?: Record<string, unknown> };
}

export type BillingAction =
  | { type: "ignore"; reason: string }
  | { type: "reject"; reason: string }
  | { type: "upsert_subscription"; subscription_id: string; customer_id: string | null; variant_id: string | null; status: string; cancelled: boolean; renews_at: string | null; ends_at: string | null }
  | { type: "allocate_monthly"; subscription_id: string; invoice_id: string; billing_reason: string }
  | { type: "subscription_payment_failed"; subscription_id: string; invoice_id: string }
  | { type: "grant_topup"; order_id: string; plan: PlanKey; credits: number };

const s = (v: unknown) => (v == null ? null : String(v));

export const HANDLED_EVENTS = [
  "order_created", "subscription_created", "subscription_updated", "subscription_cancelled", "subscription_resumed",
  "subscription_expired", "subscription_paused", "subscription_unpaused",
  "subscription_payment_success", "subscription_payment_failed", "subscription_payment_recovered",
] as const;

/** Decide what a verified webhook means. Never trusts amounts/quantities in the payload. */
export function decideAction(p: WebhookPayload, variants: VariantMap, opts: { allowLive: boolean }): BillingAction {
  const ev = p.meta?.event_name ?? "";
  const a = p.data?.attributes ?? {};
  const id = s(p.data?.id);
  if (!id) return { type: "reject", reason: "missing_id" };
  if (p.meta?.test_mode !== true && !opts.allowLive) return { type: "reject", reason: "live_mode_disabled" };
  // Once live payments are on, test-mode events can never grant production credits.
  if (p.meta?.test_mode === true && opts.allowLive) return { type: "reject", reason: "test_event_in_live_mode" };

  switch (ev) {
    case "order_created": {
      if (a["status"] !== "paid") return { type: "ignore", reason: "order_not_paid" };
      const item = a["first_order_item"] as { variant_id?: unknown } | undefined;
      const ent = planForVariant(variants, item?.variant_id);
      if (!ent) return { type: "reject", reason: "unknown_variant" };
      if (ent.kind === "subscription") return { type: "ignore", reason: "subscription_order_handled_by_invoice" };
      return { type: "grant_topup", order_id: id, plan: ent.plan, credits: ent.credits };
    }
    case "subscription_created": case "subscription_updated": case "subscription_cancelled": case "subscription_resumed":
    case "subscription_expired": case "subscription_paused": case "subscription_unpaused": {
      const ent = planForVariant(variants, a["variant_id"]);
      if (!ent || ent.kind !== "subscription") return { type: "reject", reason: "unknown_variant" };
      return {
        type: "upsert_subscription", subscription_id: id, customer_id: s(a["customer_id"]), variant_id: s(a["variant_id"]),
        status: String(a["status"] ?? "unknown"), cancelled: a["cancelled"] === true,
        renews_at: s(a["renews_at"]), ends_at: s(a["ends_at"]),
      };
    }
    case "subscription_payment_success": case "subscription_payment_recovered": {
      if (a["status"] !== "paid") return { type: "ignore", reason: "invoice_not_paid" };
      const sub = s(a["subscription_id"]);
      if (!sub) return { type: "reject", reason: "missing_subscription" };
      return { type: "allocate_monthly", subscription_id: sub, invoice_id: id, billing_reason: String(a["billing_reason"] ?? "unknown") };
    }
    case "subscription_payment_failed": {
      const sub = s(a["subscription_id"]);
      if (!sub) return { type: "reject", reason: "missing_subscription" };
      return { type: "subscription_payment_failed", subscription_id: sub, invoice_id: id };
    }
    default: return { type: "ignore", reason: "unhandled_event" };
  }
}

/** Account the webhook belongs to: stored subscription owner wins; custom data must agree with it. */
export function resolveAccount(customUserId: unknown, storedOwner: string | null): { user_id: string } | { error: string } {
  const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const c = typeof customUserId === "string" && uuid.test(customUserId) ? customUserId : null;
  if (storedOwner && c && storedOwner !== c) return { error: "account_mismatch" };
  const u = storedOwner ?? c;
  return u ? { user_id: u } : { error: "no_account" };
}

/** Webhook log key: same delivery (event + object + its updated_at) is recorded once. Ledger keys are the real guard. */
export function eventKey(p: WebhookPayload) {
  return `${p.meta?.event_name}:${s(p.data?.id)}:${s(p.data?.attributes?.["updated_at"]) ?? ""}`;
}
