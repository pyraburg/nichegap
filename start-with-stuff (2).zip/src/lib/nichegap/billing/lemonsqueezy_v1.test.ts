import { describe, expect, it } from "vitest";
import { decideAction, eventKey, planForVariant, resolveAccount, verifySignature, type WebhookPayload } from "./lemonsqueezy_v1";

const V = { monthly: "100", topup_5: "105", topup_15: "115", topup_40: "140" };
const U = "11111111-1111-4111-8111-111111111111";
const U2 = "22222222-2222-4222-8222-222222222222";
const opt = { allowLive: false };
const ev = (event_name: string, id: string, attributes: Record<string, unknown>, test_mode = true): WebhookPayload => ({ meta: { event_name, test_mode, custom_data: { user_id: U } }, data: { id, attributes } });

async function sign(body: string, secret: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return [...new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(body)))].map((x) => x.toString(16).padStart(2, "0")).join("");
}

describe("signature", () => {
  it("accepts valid, rejects invalid/missing/tampered", async () => {
    const body = '{"a":1}';
    const sig = await sign(body, "s3cret");
    expect(await verifySignature(body, sig, "s3cret")).toBe(true);
    expect(await verifySignature(body, sig, "other")).toBe(false);
    expect(await verifySignature('{"a":2}', sig, "s3cret")).toBe(false);
    expect(await verifySignature(body, null, "s3cret")).toBe(false);
  });
});

describe("entitlement mapping", () => {
  it("maps only approved variants", () => {
    expect(planForVariant(V, 105)?.credits).toBe(5);
    expect(planForVariant(V, "115")?.credits).toBe(15);
    expect(planForVariant(V, "140")?.credits).toBe(40);
    expect(planForVariant(V, "100")?.credit_type).toBe("monthly");
    expect(planForVariant(V, "999")).toBeNull();
    expect(planForVariant({}, "")).toBeNull();
  });
});

describe("decideAction", () => {
  it("top-ups grant fixed credits, ignoring payload quantities/prices", () => {
    for (const [v, c] of [["105", 5], ["115", 15], ["140", 40]] as const) {
      const a = decideAction(ev("order_created", "o1", { status: "paid", total: 1, first_order_item: { variant_id: v, quantity: 99 } }), V, opt);
      expect(a).toMatchObject({ type: "grant_topup", order_id: "o1", credits: c });
    }
  });
  it("manipulated / unknown variant is rejected", () => {
    expect(decideAction(ev("order_created", "o2", { status: "paid", first_order_item: { variant_id: "666" } }), V, opt).type).toBe("reject");
  });
  it("unpaid order grants nothing; subscription order defers to invoice", () => {
    expect(decideAction(ev("order_created", "o3", { status: "pending", first_order_item: { variant_id: "105" } }), V, opt).type).toBe("ignore");
    expect(decideAction(ev("order_created", "o4", { status: "paid", first_order_item: { variant_id: "100" } }), V, opt).type).toBe("ignore");
  });
  it("subscription_created only stores state (no credits)", () => {
    const a = decideAction(ev("subscription_created", "s1", { variant_id: 100, status: "active", renews_at: "2026-11-07T00:00:00Z" }), V, opt);
    expect(a.type).toBe("upsert_subscription");
  });
  it("paid initial and renewal invoices allocate monthly, keyed by invoice", () => {
    expect(decideAction(ev("subscription_payment_success", "i1", { status: "paid", subscription_id: 7, billing_reason: "initial" }), V, opt)).toMatchObject({ type: "allocate_monthly", invoice_id: "i1", subscription_id: "7" });
    expect(decideAction(ev("subscription_payment_recovered", "i2", { status: "paid", subscription_id: 7, billing_reason: "renewal" }), V, opt).type).toBe("allocate_monthly");
  });
  it("failed renewal never allocates", () => {
    expect(decideAction(ev("subscription_payment_failed", "i3", { status: "failed", subscription_id: 7 }), V, opt).type).toBe("subscription_payment_failed");
    expect(decideAction(ev("subscription_payment_success", "i4", { status: "pending", subscription_id: 7 }), V, opt).type).toBe("ignore");
  });
  it("cancel/expire only update state", () => {
    expect(decideAction(ev("subscription_cancelled", "s1", { variant_id: 100, status: "cancelled", cancelled: true, ends_at: "x" }), V, opt)).toMatchObject({ type: "upsert_subscription", cancelled: true });
    expect(decideAction(ev("subscription_expired", "s1", { variant_id: 100, status: "expired" }), V, opt)).toMatchObject({ status: "expired" });
  });
  it("live-mode events are refused while live payments are off", () => {
    expect(decideAction(ev("order_created", "o5", { status: "paid", first_order_item: { variant_id: "105" } }, false), V, opt)).toEqual({ type: "reject", reason: "live_mode_disabled" });
  });
  it("same delivery → same event key (retry dedupe)", () => {
    const p = ev("order_created", "o1", { updated_at: "t" });
    expect(eventKey(p)).toBe(eventKey(JSON.parse(JSON.stringify(p))));
  });
});

describe("account mapping", () => {
  it("stored owner wins; mismatching custom data is refused; garbage rejected", () => {
    expect(resolveAccount(U, null)).toEqual({ user_id: U });
    expect(resolveAccount(undefined, U)).toEqual({ user_id: U });
    expect(resolveAccount(U2, U)).toEqual({ error: "account_mismatch" });
    expect(resolveAccount("not-a-uuid", null)).toEqual({ error: "no_account" });
  });
});

describe("webhook log wiring (source guard)", async () => {
  const { readFileSync } = await import("node:fs");
  const src = readFileSync("src/lib/nichegap/billing.server.ts", "utf8");
  it("replays are logged separately as duplicate:, ledger keys unchanged", () => {
    expect(src).toContain('`${dupT ? "duplicate:" : ""}topup:');
    expect(src).toContain('`${dupM ? "duplicate:" : ""}monthly_allocated:');
    expect(src).toContain("`ls_order:${action.order_id}`");
    expect(src).toContain("`ls_invoice:${action.invoice_id}`");
  });
  it("15 and 40 packs use the same top-up path as the 5 pack", () => {
    for (const [v, c] of [["115", 15], ["140", 40]] as const)
      expect(decideAction(ev("order_created", "o9", { status: "paid", first_order_item: { variant_id: v } }), V, opt)).toMatchObject({ type: "grant_topup", credits: c, plan: `topup_${c}` });
  });
});

import { decideAction as decide2 } from "./lemonsqueezy_v1";
describe("live/test separation", () => {
  const vm = { monthly: "1", topup_5: "5", topup_15: "15", topup_40: "40" };
  const ev = (test_mode: boolean) => ({ meta: { event_name: "order_created", test_mode, custom_data: { user_id: "u" } }, data: { id: "o1", attributes: { status: "paid", first_order_item: { variant_id: 5 } } } });
  it("live mode rejects test events; test mode rejects live events", () => {
    expect(decide2(ev(true) as never, vm, { allowLive: true })).toEqual({ type: "reject", reason: "test_event_in_live_mode" });
    expect(decide2(ev(false) as never, vm, { allowLive: false })).toEqual({ type: "reject", reason: "live_mode_disabled" });
    expect(decide2(ev(false) as never, vm, { allowLive: true }).type).toBe("grant_topup");
    expect(decide2(ev(true) as never, vm, { allowLive: false }).type).toBe("grant_topup");
  });
});
