import { beforeEach, describe, expect, it, vi } from "vitest";

const U = "11111111-1111-4111-8111-111111111111";
const logs: { event_key: string; outcome: string }[] = [];
let rpcStatus = "granted";
const rpcCalls: unknown[] = [];

vi.mock("@/integrations/supabase/client.server", () => {
  const q = (table: string) => {
    const chain = {
      select: () => chain, eq: () => chain, order: () => chain, limit: () => chain,
      maybeSingle: async () => ({ data: table === "profiles" ? { id: U } : { user_id: U } }),
      upsert: async (row: { event_key: string; outcome: string }) => { if (table === "billing_webhook_events") logs.push(row); return { error: null }; },
      update: () => chain,
    };
    return chain;
  };
  return { supabaseAdmin: { from: q, rpc: async (name: string, args: unknown) => { rpcCalls.push({ name, args }); return { data: { status: rpcStatus }, error: null }; } } };
});

async function sign(body: string, secret: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return [...new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(body)))].map((x) => x.toString(16).padStart(2, "0")).join("");
}

describe("handleWebhook replay labelling", () => {
  beforeEach(() => {
    logs.length = 0; rpcCalls.length = 0;
    process.env["LEMONSQUEEZY_WEBHOOK_SECRET"] = "whsec_test";
    Object.assign(process.env, { LEMONSQUEEZY_VARIANT_MONTHLY: "100", LEMONSQUEEZY_VARIANT_TOPUP_5: "105", LEMONSQUEEZY_VARIANT_TOPUP_15: "115", LEMONSQUEEZY_VARIANT_TOPUP_40: "140" });
    delete process.env["LEMONSQUEEZY_LIVE_ENABLED"];
  });

  for (const [variant, credits] of [["105", 5], ["115", 15], ["140", 40]] as const) {
    it(`${credits}-credit pack: original logged normally, replay logged as duplicate (same ledger key)`, async () => {
      const { handleWebhook } = await import("../billing.server");
      const body = JSON.stringify({ meta: { event_name: "order_created", test_mode: true, custom_data: { user_id: U } }, data: { id: `ord${credits}`, attributes: { status: "paid", updated_at: "t", first_order_item: { variant_id: variant } } } });
      const sig = await sign(body, "whsec_test");
      rpcStatus = "granted";
      expect((await handleWebhook(body, sig)).outcome).toBe("topup_granted");
      rpcStatus = "duplicate";
      expect((await handleWebhook(body, sig)).status).toBe(200);
      expect(logs[0]!.outcome).toBe(`topup:topup_${credits}`);
      expect(logs[1]!.outcome).toBe(`duplicate:topup:topup_${credits}`);
      expect(logs[1]!.event_key).not.toBe(logs[0]!.event_key);
      const args = rpcCalls.map((c) => (c as { args: { _key: string; _amount: number } }).args);
      expect(args.every((a) => a._key === `ls_order:ord${credits}` && a._amount === credits)).toBe(true);
    });
  }

  it("monthly replay logged as duplicate", async () => {
    const { handleWebhook } = await import("../billing.server");
    const body = JSON.stringify({ meta: { event_name: "subscription_payment_success", test_mode: true, custom_data: { user_id: U } }, data: { id: "inv1", attributes: { status: "paid", subscription_id: 9, billing_reason: "initial" } } });
    const sig = await sign(body, "whsec_test");
    rpcStatus = "allocated"; await handleWebhook(body, sig);
    rpcStatus = "duplicate"; await handleWebhook(body, sig);
    expect(logs.map((l) => l.outcome)).toEqual(["monthly_allocated:initial", "duplicate:monthly_allocated:initial"]);
  });

  it("invalid signature never reaches the ledger", async () => {
    const { handleWebhook } = await import("../billing.server");
    expect((await handleWebhook("{}", "00")).status).toBe(401);
    expect(rpcCalls.length).toBe(0);
  });
});
