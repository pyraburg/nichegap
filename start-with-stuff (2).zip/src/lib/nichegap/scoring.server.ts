// Server-only: loads stored evidence, runs score_v1, persists opportunity + immutable audit row.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { scoreV1, type AmazonKeywordEvidence, type GoogleKeyword } from "./scoring/score_v1";
import { scoreV1_1, type AmazonKeywordEvidenceV11 } from "./scoring/score_v1_1";

export const SCORE_VERSIONS = ["score_v1", "score_v1_1"] as const;
export type ScoreVersion = (typeof SCORE_VERSIONS)[number];
export const DEFAULT_SCORE_VERSION: ScoreVersion = "score_v1_1";

async function sha256(text: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export async function scoreResearchJob(jobId: string, niche: string, version: ScoreVersion = DEFAULT_SCORE_VERSION) {
  const SCORE_VERSION = version;
  const { data: rows, error } = await supabaseAdmin
    .from("research_data")
    .select("id, data_type, normalized_query, processed_data, created_at")
    .eq("research_query_id", jobId)
    .in("data_type", ["google_keyword_demand", "amazon_marketplace_supply"])
    .order("created_at", { ascending: false });
  if (error) throw error;

  const google = rows?.find((r) => r.data_type === "google_keyword_demand");
  const seen = new Set<string>();
  const amazonRows = (rows ?? []).filter((r) => {
    if (r.data_type !== "amazon_marketplace_supply") return false;
    const k = r.normalized_query ?? r.id;
    if (seen.has(k)) return false;
    seen.add(k); return true;
  }).sort((a, b) => (a.normalized_query ?? "").localeCompare(b.normalized_query ?? ""));

  const evidenceIds = [google?.id, ...amazonRows.map((r) => r.id)].filter(Boolean) as string[];
  const evidence_hash = await sha256(`${SCORE_VERSION}|${niche.trim().toLowerCase()}|${evidenceIds.join(",")}`);

  // Same version + same evidence => reuse existing score (determinism, no duplicate history).
  const { data: existing } = await supabaseAdmin.from("opportunities")
    .select("id").eq("research_query_id", jobId).eq("evidence_hash", evidence_hash).eq("score_version", SCORE_VERSION).limit(1).maybeSingle();
  if (existing) return { opportunity_id: existing.id, reused: true };

  const g = ((google?.processed_data as { keywords?: GoogleKeyword[] } | null)?.keywords) ?? null;
  const result = version === "score_v1"
    ? scoreV1({ niche, google: g, amazon: amazonRows.length ? amazonRows.map((r) => r.processed_data as unknown as AmazonKeywordEvidence) : null })
    : scoreV1_1({ niche, google: g, amazon: amazonRows.length ? amazonRows.map((r) => r.processed_data as unknown as AmazonKeywordEvidenceV11) : null });
  const c = result.components;
  const now = new Date().toISOString();
  const { data: opp, error: oErr } = await supabaseAdmin.from("opportunities").insert({
    research_query_id: jobId,
    title: niche,
    description: c.demand.explanation.text,
    demand_score: c.demand.score,
    competition_opportunity_score: c.competition.score,
    purchase_intent_score: c.purchase_intent.score,
    trend_score: c.trend.score,
    opportunity_score: result.opportunity_score,
    score_version: SCORE_VERSION,
    score_confidence: result.confidence,
    score_classification: result.classification,
    evidence_completeness_percent: result.evidence_completeness_percent,
    score_breakdown: result as never,
    evidence_hash,
    scored_at: now,
  }).select("id").single();
  if (oErr) throw oErr;
  const { error: aErr } = await supabaseAdmin.from("score_runs").insert({
    research_query_id: jobId, opportunity_id: opp.id, score_version: SCORE_VERSION,
    evidence_hash, evidence_research_data_ids: evidenceIds, result: result as never,
  });
  if (aErr) throw aErr;
  return { opportunity_id: opp.id, reused: false };
}
