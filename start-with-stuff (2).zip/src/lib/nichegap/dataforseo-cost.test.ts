import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { canStartDfsCall, dfsCostConfig } from "./dataforseo-cost";

const cfg = dfsCostConfig({});
const paid = (cost: number | null) => ({ cost, cache_hit: false, status: "success" });

describe("DataForSEO per-job ceiling", () => {
  it("defaults to $0.25", () => { expect(cfg.ceiling_usd).toBe(0.25); expect(dfsCostConfig({ DATAFORSEO_JOB_CEILING_USD: "0.5" }).ceiling_usd).toBe(0.5); });
  it("allows first calls of a fresh job", () => {
    expect(canStartDfsCall([], "google", cfg).allowed).toBe(true);
  });
  it("accumulates Google + Amazon authoritative costs", () => {
    const rows = [paid(0.09), paid(0.0033), paid(0.0033)];
    const g = canStartDfsCall(rows, "amazon", cfg);
    expect(g).toMatchObject({ allowed: true, spent_usd: 0.0966 });
  });
  it("refuses when the next call's reserve would exceed the cap", () => {
    expect(canStartDfsCall([paid(0.2)], "google", cfg)).toMatchObject({ allowed: false, reason: "ceiling" });
    expect(canStartDfsCall([paid(0.245)], "amazon", cfg)).toMatchObject({ allowed: false, reason: "ceiling" });
    expect(canStartDfsCall([paid(0.24)], "amazon", cfg).allowed).toBe(true);
  });
  it("cache hits and logged refusals cost $0", () => {
    const rows = [{ cost: 0.5, cache_hit: true, status: "cache_hit" }, { cost: 0, cache_hit: false, status: "refused_ceiling" }];
    expect(canStartDfsCall(rows, "google", cfg)).toMatchObject({ allowed: true, spent_usd: 0 });
  });
  it("unknown/pending cost is conservative: blocks further paid calls", () => {
    expect(canStartDfsCall([paid(null)], "amazon", cfg)).toMatchObject({ allowed: false, reason: "unknown_cost" });
  });
  it("both call sites are guarded before the provider request and log refusals", () => {
    const src = readFileSync("src/lib/nichegap/research.server.ts", "utf8");
    expect(src).toMatch(/dfsGuard\(admin, job, userId, "google"[\s\S]*fetchKeywordDemand\(/);
    // Amazon: guard moved into amazon_collect_v1 (checked before every paid fetch, with in-flight exposure).
    const ac = readFileSync("src/lib/nichegap/amazon_collect_v1.ts", "utf8");
    expect(ac).toMatch(/canStartDfsCall\([\s\S]*"amazon"[\s\S]*inFlight\)[\s\S]*DFS_REFUSED_STATUS[\s\S]*deps\.fetch\(/);
    expect(src).toContain("fetchAmazonProducts(");
    expect(src).toContain("DFS_REFUSED_STATUS");
    expect(readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8")).toContain('"dataforseo_ceiling"');
  });
});
