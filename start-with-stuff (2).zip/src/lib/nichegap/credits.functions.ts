import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Starts a new credit-billed research job. The client supplies a submission_id generated once per form
 * submission; it becomes the job id, so double clicks / refreshes / duplicate requests map to ONE job
 * and therefore ONE reservation. Balance is always read server-side.
 */
export const createResearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    submission_id: z.string().uuid(),
    query: z.string().trim().min(2).max(200),
    target_country: z.string().min(2).max(8),
    language: z.string().min(2).max(8),
  }).parse(d))
  .handler(async ({ data, context }) => {
    // Insert as the user (RLS: own row, pending, credit billing). A duplicate request hits the same id.
    const { error: insErr } = await context.supabase.from("research_queries").insert({
      id: data.submission_id, user_id: context.userId, query: data.query,
      target_country: data.target_country, language: data.language, status: "pending",
    });
    if (insErr && insErr.code !== "23505") return { status: "error" as const, job_id: null };
    const { data: own } = await context.supabase.from("research_queries").select("id, user_id").eq("id", data.submission_id).maybeSingle();
    if (!own || own.user_id !== context.userId) return { status: "error" as const, job_id: null };

    const { startPipeline, releaseCreditForJob } = await import("./pipeline.server");
    try {
      const r = await startPipeline(data.submission_id, context.userId) as { started?: boolean; reason?: string };
      if (r.reason === "insufficient_credits") {
        // Nothing was reserved or started: remove the empty pending job.
        await context.supabase.from("research_queries").delete().eq("id", data.submission_id).eq("status", "pending");
        return { status: "out_of_credits" as const, job_id: null };
      }
      if (r.started || r.reason === "already_started" || r.reason === "not_pending") return { status: "started" as const, job_id: data.submission_id };
      await releaseCreditForJob(data.submission_id, "start_failed");
      return { status: "error" as const, job_id: null };
    } catch {
      await releaseCreditForJob(data.submission_id, "start_failed").catch(() => undefined);
      return { status: "error" as const, job_id: null };
    }
  });

/** Admin-only test credit grant (Stripe is not connected). Every grant is a ledger entry. */
export const grantTestCredits = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({
    request_id: z.string().uuid(),
    email: z.string().trim().email().max(255).optional(),
    amount: z.number().int().min(1).max(100),
    credit_type: z.enum(["monthly", "purchased"]),
  }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Not authorized.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let target = context.userId;
    if (data.email) {
      const { data: p } = await supabaseAdmin.from("profiles").select("id").ilike("email", data.email).maybeSingle();
      if (!p) throw new Error("No account with that email.");
      target = p.id;
    }
    const { data: res, error } = await supabaseAdmin.rpc("grant_research_credits", {
      _user: target, _amount: data.amount, _type: data.credit_type, _event: "admin_adjustment",
      _key: `admin_grant:${data.request_id}`, _metadata: { reason: "test_grant", granted_by: context.userId },
    });
    if (error) throw new Error("Grant failed.");
    return res as { status: string };
  });
