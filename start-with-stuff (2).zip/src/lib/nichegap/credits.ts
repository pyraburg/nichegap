// Pure Research Credit helpers (no I/O). The authoritative logic runs in database functions;
// this mirrors their selection rule for display and tests.
export type CreditType = "monthly" | "purchased";
export interface CreditBalance { monthly: number; purchased: number }

export const RESEARCH_COST_CREDITS = 1;

/** Monthly credits are always consumed before purchased ones. */
export function creditTypeToConsume(b: CreditBalance): CreditType | null {
  if (b.monthly >= RESEARCH_COST_CREDITS) return "monthly";
  if (b.purchased >= RESEARCH_COST_CREDITS) return "purchased";
  return null;
}

export function consumeOne(b: CreditBalance): CreditBalance | null {
  const t = creditTypeToConsume(b);
  if (!t) return null;
  return { ...b, [t]: b[t] - RESEARCH_COST_CREDITS };
}

export const totalCredits = (b: CreditBalance) => Math.max(0, b.monthly) + Math.max(0, b.purchased);

/** Customer-facing balance text — no ledger/provider details. */
export function balanceLabel(b: CreditBalance) {
  const total = totalCredits(b);
  const split = b.monthly > 0 && b.purchased > 0 ? `${b.monthly} monthly + ${b.purchased} purchased` : null;
  return { headline: `Research Credits: ${total}`, split };
}

export const OUT_OF_CREDITS_MESSAGE = "You're out of Research Credits.";
