// Pure, versioned research-pipeline orchestration (no I/O). Each stage's real work is injected, so the
// same logic runs against mocks in tests and against the existing tested engines on the server.
export const PIPELINE_VERSION = "pipeline_v1";

export const PIPELINE_STAGES = ["search_demand", "marketplace", "community", "score", "ai_analysis", "report"] as const;
export type PipelineStage = (typeof PIPELINE_STAGES)[number];
export type StageStatus = "pending" | "running" | "completed" | "failed" | "skipped";

export interface StageRecord { status: StageStatus; attempts: number; updated_at: string | null; error_code: string | null }
export type PipelineState = Record<PipelineStage, StageRecord>;

/** A stage only runs once every dependency has completed. Community failure still lets scoring run, but blocks AI. */
export const STAGE_DEPENDS: Record<PipelineStage, readonly PipelineStage[]> = {
  search_demand: [],
  marketplace: ["search_demand"],
  community: ["search_demand"],
  score: ["marketplace"],
  ai_analysis: ["community", "score"],
  report: ["ai_analysis"],
};

/** Hard cap on attempts per stage so a controlled retry can never become a loop. */
export const MAX_STAGE_ATTEMPTS = 3;
/** Max stages advanced per worker call (bounded work per request). */
export const MAX_STEPS_PER_CALL: number = PIPELINE_STAGES.length;

export type StageResult = { kind: "completed" } | { kind: "waiting" } | { kind: "failed"; code: string };

export function initialState(): PipelineState {
  return Object.fromEntries(PIPELINE_STAGES.map((s) => [s, { status: "pending", attempts: 0, updated_at: null, error_code: null }])) as PipelineState;
}

/** Defensive parse of persisted JSON; unknown/missing stages become pending. */
export function normalizeState(raw: unknown): PipelineState {
  const base = initialState();
  if (!raw || typeof raw !== "object") return base;
  const r = raw as Record<string, Partial<StageRecord>>;
  for (const s of PIPELINE_STAGES) {
    const v = r[s];
    if (!v) continue;
    const ok = ["pending", "running", "completed", "failed", "skipped"].includes(v.status as string);
    base[s] = { status: ok ? (v.status as StageStatus) : "pending", attempts: Number(v.attempts) || 0, updated_at: v.updated_at ?? null, error_code: v.error_code ?? null };
  }
  return base;
}

const done = (st: PipelineState, s: PipelineStage) => st[s].status === "completed" || st[s].status === "skipped";

/** Next stage to work on, in fixed order: pending/running with all dependencies completed. */
export function nextStage(st: PipelineState): PipelineStage | null {
  for (const s of PIPELINE_STAGES) {
    const rec = st[s];
    if ((rec.status === "pending" || rec.status === "running") && STAGE_DEPENDS[s].every((d) => done(st, d))) return s;
  }
  return null;
}

export type PipelineOutcome = "complete" | "in_progress" | "needs_attention";
export function pipelineOutcome(st: PipelineState): PipelineOutcome {
  if (PIPELINE_STAGES.every((s) => done(st, s))) return "complete";
  if (nextStage(st)) return "in_progress";
  return PIPELINE_STAGES.some((s) => st[s].status === "failed") ? "needs_attention" : "in_progress";
}

/** research_queries.status derived from the pipeline (keeps legacy status semantics consistent). */
export function jobStatusFor(st: PipelineState): "processing" | "completed" | "failed" {
  const o = pipelineOutcome(st);
  return o === "complete" ? "completed" : o === "needs_attention" ? "failed" : "processing";
}

/** Controlled retry: failed stages go back to pending unless their attempt budget is spent. Completed work is untouched. */
export function resetForRetry(st: PipelineState): { state: PipelineState; reset: PipelineStage[]; exhausted: PipelineStage[] } {
  const next = structuredClone(st);
  const reset: PipelineStage[] = []; const exhausted: PipelineStage[] = [];
  for (const s of PIPELINE_STAGES) {
    if (next[s].status !== "failed") continue;
    if (next[s].attempts >= MAX_STAGE_ATTEMPTS) { exhausted.push(s); continue; }
    next[s] = { ...next[s], status: "pending", error_code: null };
    reset.push(s);
  }
  return { state: next, reset, exhausted };
}

export interface PipelineDeps {
  load(): Promise<PipelineState>;
  save(state: PipelineState): Promise<void>;
  run(stage: PipelineStage): Promise<StageResult>;
  now(): string;
}

/** Advances the pipeline by at most maxSteps stages. Caller must hold the job's lease. */
export async function advancePipeline(deps: PipelineDeps, maxSteps = MAX_STEPS_PER_CALL) {
  let state = await deps.load();
  const ran: PipelineStage[] = [];
  for (let i = 0; i < maxSteps; i++) {
    const stage = nextStage(state);
    if (!stage) break;
    const rec = state[stage];
    if (rec.status === "pending") {
      state = { ...state, [stage]: { ...rec, status: "running", attempts: rec.attempts + 1, updated_at: deps.now(), error_code: null } };
      await deps.save(state);
    }
    ran.push(stage);
    let r: StageResult;
    try { r = await deps.run(stage); } catch { r = { kind: "failed", code: "stage_exception" }; }
    if (r.kind === "waiting") { await deps.save(state); return { state, ran, waiting: stage as PipelineStage | null, outcome: pipelineOutcome(state) }; }
    state = { ...state, [stage]: { ...state[stage], status: r.kind === "completed" ? "completed" : "failed", updated_at: deps.now(), error_code: r.kind === "failed" ? r.code : null } };
    await deps.save(state);
  }
  return { state, ran, waiting: null as PipelineStage | null, outcome: pipelineOutcome(state) };
}
