import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { advancePipeline, initialState, resetForRetry, type PipelineStage, type PipelineState, type StageResult } from "./pipeline_v1";
import { planReconciliation } from "../community/apify-cost";

/** Simulated background world: persisted job state + DB-style lease + scripted providers. No browser involved. */
function world(script: Partial<Record<PipelineStage, (n: number) => StageResult>> = {}) {
  let state: PipelineState = initialState();
  let leaseUntil = 0;
  const paid: Record<string, number> = {};
  const acquire = (now: number) => { if (leaseUntil > now) return false; leaseUntil = now + 360_000; return true; };
  const release = () => { leaseUntil = 0; };
  const deps = {
    load: async () => structuredClone(state),
    save: async (s: PipelineState) => { state = structuredClone(s); },
    run: async (stage: PipelineStage) => { paid[stage] = (paid[stage] ?? 0) + 1; return script[stage]?.(paid[stage]!) ?? { kind: "completed" as const }; },
    now: () => "2026-10-07T06:00:00Z",
  };
  /** One scheduler tick: lease → bounded advance (2 steps) → release. Never resets failed stages. */
  const tick = async (now = Date.now()) => {
    if (!acquire(now)) return { busy: true };
    try { return await advancePipeline(deps, 2); } finally { release(); }
  };
  return { tick, deps, paid, acquire, get state() { return state; }, set state(s) { state = s; } };
}

describe("background execution (no progress page open)", () => {
  it("browser closes right after creation; scheduler ticks alone complete the job", async () => {
    const w = world();
    for (let i = 0; i < 5; i++) await w.tick();
    expect(Object.values(w.state).every((s) => s.status === "completed")).toBe(true);
  });

  it("customer returning mid-way sees persisted progress; returning after completion sees complete", async () => {
    const w = world();
    await w.tick();
    expect(w.state.search_demand.status).toBe("completed");
    expect(w.state.report.status).toBe("pending");
    for (let i = 0; i < 5; i++) await w.tick();
    expect(w.state.report.status).toBe("completed");
  });

  it("pending Apify run is re-checked on later ticks without a new paid attempt", async () => {
    const w = world({ community: (n) => (n < 4 ? { kind: "waiting" } : { kind: "completed" }) });
    for (let i = 0; i < 8; i++) await w.tick();
    expect(w.state.community).toMatchObject({ status: "completed", attempts: 1 });
    expect(w.paid["search_demand"]).toBe(1);
  });

  it("worker interruption mid-stage resumes on the next tick after the lease expires", async () => {
    const w = world({ marketplace: (n) => { if (n === 1) throw new Error("worker killed"); return { kind: "completed" }; } });
    await w.tick();
    // A thrown stage is a genuine failure → needs attention, NOT auto-retried by later ticks.
    expect(w.state.marketplace.status).toBe("failed");
    await w.tick(); await w.tick();
    expect(w.paid["marketplace"]).toBe(1);
  });

  it("a stage left 'running' by a crashed worker is resumed, not re-purchased as a new attempt", async () => {
    const w = world();
    const s = initialState();
    s.search_demand.status = "completed"; s.marketplace = { ...s.marketplace, status: "running", attempts: 1 };
    w.state = s;
    await w.tick(Date.now() + 400_000); // old lease long expired
    expect(w.state.marketplace).toMatchObject({ status: "completed", attempts: 1 });
  });

  it("two workers on the same job: the second is refused by the lease", async () => {
    const w = world();
    const now = Date.now();
    expect(w.acquire(now)).toBe(true);
    expect(await w.tick(now + 1000)).toEqual({ busy: true });
    expect(w.paid).toEqual({});
  });

  it("provider failure stays Needs attention until a controlled user retry", async () => {
    const w = world({ community: (n) => (n === 1 ? { kind: "failed", code: "community_refused" } : { kind: "completed" }) });
    for (let i = 0; i < 6; i++) await w.tick();
    expect(w.state.community.status).toBe("failed");
    expect(w.paid["community"]).toBe(1);
    w.state = resetForRetry(w.state).state; // user's "Try again"
    for (let i = 0; i < 6; i++) await w.tick();
    expect(w.state.report.status).toBe("completed");
    expect(w.paid).toMatchObject({ search_demand: 1, marketplace: 1, community: 2, score: 1, ai_analysis: 1, report: 1 });
  });

  it("AI disabled: deterministic work completes, AI needs attention, report never auto-completes", async () => {
    const w = world({ ai_analysis: () => ({ kind: "failed", code: "ai_disabled" }) });
    for (let i = 0; i < 6; i++) await w.tick();
    expect(w.state.score.status).toBe("completed");
    expect(w.state.ai_analysis).toMatchObject({ status: "failed", error_code: "ai_disabled" });
    expect(w.state.report.status).toBe("pending");
    expect(w.paid["ai_analysis"]).toBe(1);
  });

  it("final Apify reconciliation only finalizes from terminal settled run metadata", () => {
    const row = { id: "u", cost: null, cost_status: "pending", intermediate_cost: 0.1, reconcile_attempts: 0, cache_hit: false, provider_run_id: "r" };
    const running = planReconciliation(row as never, { id: "r", status: "RUNNING", usageTotalUsd: 0.1 } as never, new Date());
    expect(running?.cost_status ?? "pending").not.toBe("final");
  });
});

describe("background wiring (source guards)", () => {
  const srv = readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8");
  const route = readFileSync("src/routes/api/public/pipeline-tick.ts", "utf8");
  const page = readFileSync("src/routes/_authenticated/research_.$id.index.tsx", "utf8");
  const tick = srv.slice(srv.indexOf("export async function processPipelineTick"));
  it("worker route verifies a server-only token before any work", () => {
    expect(route.indexOf("verifyWorkerToken")).toBeLessThan(route.indexOf("processPipelineTick()"));
    expect(route).toContain('status: 401');
  });
  it("tick is bounded, never retries failed stages and reconciles pending costs", () => {
    expect(srv).toMatch(/TICK_LIMITS = \{ max_jobs: 3, steps_per_job: 2/);
    expect(tick).not.toContain("resetForRetry");
    expect(tick).toContain("reconcileApifyUsage");
    expect(tick).toContain('.eq("status", "processing")');
  });
  it("start and retry only queue work; the browser no longer drives stages", () => {
    expect(srv).toContain('return { started: true, queued: true }; // the background worker picks it up');
    expect(srv).toContain("return { retried: true, queued: true };");
    expect(page).not.toMatch(/advanceResearchPipeline|setInterval/);
    expect(page).toContain("Your research will continue even if you leave this page.");
  });
  it("a running AI analysis is never re-requested; stale ones need attention", () => {
    expect(srv).toContain('code: "ai_stale"');
  });
});
