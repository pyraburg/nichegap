import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import {
  advancePipeline, initialState, jobStatusFor, MAX_STAGE_ATTEMPTS, nextStage, normalizeState, pipelineOutcome,
  PIPELINE_STAGES, resetForRetry, type PipelineStage, type PipelineState, type StageResult,
} from "./pipeline_v1";
import { summarizeCosts } from "./cost_summary_v1";
import { customerStatus, journeyStages, type JobFacts } from "../journey";

/** In-memory harness: stage behaviour scripted per call; counts "paid" calls per stage. */
function harness(script: Partial<Record<PipelineStage, StageResult[] | ((n: number) => StageResult)>> = {}, start?: PipelineState) {
  let stored = structuredClone(start ?? initialState());
  const calls: PipelineStage[] = [];
  const count: Record<string, number> = {};
  const deps = {
    load: async () => structuredClone(stored),
    save: async (s: PipelineState) => { stored = structuredClone(s); },
    run: async (stage: PipelineStage): Promise<StageResult> => {
      calls.push(stage); const n = (count[stage] = (count[stage] ?? 0) + 1);
      const sc = script[stage];
      if (typeof sc === "function") return sc(n);
      if (Array.isArray(sc)) return sc[Math.min(n - 1, sc.length - 1)]!;
      return { kind: "completed" };
    },
    now: () => "2026-10-07T00:00:00.000Z",
  };
  return { deps, calls, count, get state() { return stored; } };
}
const statuses = (s: PipelineState) => Object.fromEntries(PIPELINE_STAGES.map((k) => [k, s[k].status]));

describe("pipeline_v1 orchestration", () => {
  it("complete successful pipeline runs every stage once in order", async () => {
    const h = harness();
    const r = await advancePipeline(h.deps);
    expect(h.calls).toEqual(["search_demand", "marketplace", "community", "score", "ai_analysis", "report"]);
    expect(r.outcome).toBe("complete");
    expect(jobStatusFor(h.state)).toBe("completed");
  });

  it("stage ordering respects dependencies", () => {
    const s = initialState();
    expect(nextStage(s)).toBe("search_demand");
    s.search_demand.status = "completed";
    expect(nextStage(s)).toBe("marketplace");
    s.marketplace.status = "completed"; s.community.status = "failed";
    expect(nextStage(s)).toBe("score"); // scoring proceeds without community
    s.score.status = "completed";
    expect(nextStage(s)).toBeNull(); // AI blocked by community failure
  });

  it("community async run waits, then resumes without relaunching earlier stages", async () => {
    const h = harness({ community: [{ kind: "waiting" }, { kind: "waiting" }, { kind: "completed" }] });
    let r = await advancePipeline(h.deps);
    expect(r.waiting).toBe("community");
    expect(h.state.community.status).toBe("running");
    r = await advancePipeline(h.deps);
    r = await advancePipeline(h.deps);
    expect(r.outcome).toBe("complete");
    expect(h.count["search_demand"]).toBe(1);
    expect(h.count["marketplace"]).toBe(1);
    expect(h.state.community.attempts).toBe(1); // waiting polls are not new attempts
  });

  it("resume after interruption continues from the next stage (no repeat paid calls)", async () => {
    const s = initialState();
    s.search_demand = { ...s.search_demand, status: "completed", attempts: 1 };
    s.marketplace = { ...s.marketplace, status: "completed", attempts: 1 };
    const h = harness({}, s);
    await advancePipeline(h.deps);
    expect(h.calls[0]).toBe("community");
    expect(h.calls).not.toContain("search_demand");
    expect(h.calls).not.toContain("marketplace");
  });

  it("an interrupted running stage is resumed (not restarted as a new attempt)", async () => {
    const s = initialState();
    s.search_demand.status = "completed"; s.marketplace = { ...s.marketplace, status: "running", attempts: 1 };
    const h = harness({}, s);
    await advancePipeline(h.deps);
    expect(h.calls[0]).toBe("marketplace");
    expect(h.state.marketplace.attempts).toBe(1);
  });

  it("community failure preserves search/marketplace, still scores, blocks AI and report", async () => {
    const h = harness({ community: [{ kind: "failed", code: "community_refused" }] });
    const r = await advancePipeline(h.deps);
    expect(statuses(h.state)).toMatchObject({ search_demand: "completed", marketplace: "completed", community: "failed", score: "completed", ai_analysis: "pending", report: "pending" });
    expect(h.calls).not.toContain("ai_analysis");
    expect(r.outcome).toBe("needs_attention");
    expect(jobStatusFor(h.state)).toBe("failed");
  });

  it("AI failure keeps deterministic research + score and does not mark the report complete", async () => {
    const h = harness({ ai_analysis: [{ kind: "failed", code: "ai_failed" }] });
    await advancePipeline(h.deps);
    expect(statuses(h.state)).toMatchObject({ community: "completed", score: "completed", ai_analysis: "failed", report: "pending" });
    expect(pipelineOutcome(h.state)).toBe("needs_attention");
  });

  it("scoring failure blocks AI/report but keeps evidence", async () => {
    const h = harness({ score: [{ kind: "failed", code: "stage_exception" }] });
    await advancePipeline(h.deps);
    expect(statuses(h.state)).toMatchObject({ search_demand: "completed", marketplace: "completed", community: "completed", score: "failed", ai_analysis: "pending" });
  });

  it("thrown stage errors become failures (report failure)", async () => {
    const h = harness({ report: () => { throw new Error("boom"); } });
    await advancePipeline(h.deps);
    expect(h.state.report).toMatchObject({ status: "failed", error_code: "stage_exception" });
    expect(h.state.ai_analysis.status).toBe("completed");
  });

  it("controlled retry reruns only the failed stage", async () => {
    const h = harness({ ai_analysis: [{ kind: "failed", code: "ai_failed" }, { kind: "completed" }] });
    await advancePipeline(h.deps);
    const { state, reset } = resetForRetry(h.state);
    expect(reset).toEqual(["ai_analysis"]);
    await h.deps.save(state);
    await advancePipeline(h.deps);
    expect(h.count).toMatchObject({ search_demand: 1, marketplace: 1, community: 1, score: 1, ai_analysis: 2, report: 1 });
    expect(pipelineOutcome(h.state)).toBe("complete");
  });

  it("retry is bounded: attempt budget prevents loops", async () => {
    const h = harness({ community: [{ kind: "failed", code: "x" }] });
    for (let i = 0; i < 10; i++) {
      await advancePipeline(h.deps);
      const r = resetForRetry(h.state);
      if (!r.reset.length) { expect(r.exhausted).toEqual(["community"]); break; }
      await h.deps.save(r.state);
    }
    expect(h.count["community"]).toBe(MAX_STAGE_ATTEMPTS);
  });

  it("a failed stage is never re-run automatically", async () => {
    const h = harness({ community: [{ kind: "failed", code: "x" }] });
    await advancePipeline(h.deps); await advancePipeline(h.deps); await advancePipeline(h.deps);
    expect(h.count["community"]).toBe(1);
  });

  it("spending-limit refusal surfaces as needs attention, not a silent pass", async () => {
    const h = harness({ ai_analysis: [{ kind: "failed", code: "ai_refused" }] });
    await advancePipeline(h.deps);
    expect(h.state.ai_analysis.error_code).toBe("ai_refused");
    expect(h.state.report.status).toBe("pending");
  });

  it("completed pipeline does no further work (duplicate execution / existing evidence reuse)", async () => {
    const h = harness();
    await advancePipeline(h.deps);
    const before = h.calls.length;
    await advancePipeline(h.deps);
    expect(h.calls.length).toBe(before);
  });

  it("bounded steps per call", async () => {
    const h = harness();
    await advancePipeline(h.deps, 2);
    expect(h.calls).toEqual(["search_demand", "marketplace"]);
  });

  it("normalizeState tolerates garbage and missing stages", () => {
    expect(normalizeState(null)).toEqual(initialState());
    expect(normalizeState({ score: { status: "nope" } }).score.status).toBe("pending");
    expect(normalizeState({ score: { status: "completed", attempts: 2 } }).score).toMatchObject({ status: "completed", attempts: 2 });
  });
});

describe("cost_summary_v1", () => {
  it("aggregates final costs, counts cache hits at $0 and never guesses unknowns", () => {
    const s = summarizeCosts([
      { provider: "dataforseo", endpoint: "/v3/keywords_data/google_ads/keywords_for_keywords/live", cost: 0.09, cache_hit: false },
      { provider: "dataforseo", endpoint: "/v3/merchant/amazon/products/live/advanced", cost: "0.006", cache_hit: false },
      { provider: "dataforseo", endpoint: "/v3/merchant/amazon/products/live/advanced", cost: 0, cache_hit: true },
      { provider: "apify", endpoint: "actor:x#community_multi_v1", cost: 0.25181, cost_status: "final", cache_hit: false },
      { provider: "apify", endpoint: "actor:x#community_multi_v1", cost: 0.1, cost_status: "pending", cache_hit: false },
    ], [{ cost_usd: 0.03536, cost_status: "estimated", status: "completed" }, { cost_usd: 0, cost_status: "final", status: "cache_hit" }]);
    expect(s.google.known_usd).toBe(0.09);
    expect(s.amazon).toMatchObject({ known_usd: 0.006, cache_hits: 1 });
    expect(s.community).toMatchObject({ known_usd: 0.25181, unknown_or_pending: 1 });
    expect(s.ai).toMatchObject({ known_usd: 0.03536, cache_hits: 1 });
    expect(s.total_known_usd).toBe(0.38317);
    expect(s.complete).toBe(false);
  });
});

describe("journey mapping for automated pipeline", () => {
  const f = (pipeline: NonNullable<JobFacts["pipeline"]> | null, o: Partial<JobFacts> = {}): JobFacts => ({
    status: "processing", stage: null, has_search_demand: false, has_marketplace: false, has_community: false,
    has_score: false, has_ai_analysis: false, has_report: false, pipeline, ...o,
  });
  it("never shows 'not included' for community/AI and maps states", () => {
    const st = journeyStages(f({ search_demand: "completed", marketplace: "completed", community: "running", score: "pending", ai_analysis: "pending", report: "pending" }));
    expect(st.map((s) => s.state)).toEqual(["done", "done", "active", "waiting", "waiting", "waiting"]);
    expect(st.some((s) => s.state === "not_included")).toBe(false);
  });
  it("failure → needs attention; complete only with stored report", () => {
    expect(customerStatus(f({ ai_analysis: "failed" }))).toBe("needs_attention");
    const all = Object.fromEntries(PIPELINE_STAGES.map((k) => [k, "completed"]));
    expect(customerStatus(f(all))).toBe("researching");
    expect(customerStatus(f(all, { has_report: true }))).toBe("complete");
  });
});

describe("security / no duplicate charges (source guards)", () => {
  const fns = readFileSync("src/lib/nichegap/pipeline.functions.ts", "utf8");
  const srv = readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8");
  it("every pipeline server function requires auth and checks ownership", () => {
    expect(fns.match(/requireSupabaseAuth\]/g)?.length).toBe(4) // 3 job functions + admin-only worker health;
    expect(fns.match(/await ownJob\(context/g)?.length).toBe(3);
    expect(fns).toContain('has_role');
  });
  it("worker holds a DB lease and stages reuse stored evidence before paid calls", () => {
    expect(srv).toContain("acquireLease");
    expect(srv).toMatch(/runSearchDemand[\s\S]*has\(job.id, "google_keyword_demand"\)/);
    expect(srv).toMatch(/runCommunity[\s\S]*has\(job.id, COMMUNITY_MULTI_DATA_TYPE\)/);
    expect(srv).toContain("never relaunch blindly");
  });
  it("customer responses never include provider costs", () => {
    expect(fns).toMatch(/const safe = /);
  });
});
