// Pure worker-health classification. The scheduler is idle-guarded (no ticks without work), so a stale
// heartbeat alone is NOT a failure: "stopped" requires outstanding work AND no recent successful tick.
export const HEALTH_STALE_MS = 3 * 60_000; // ticks run every minute while work exists
export const STUCK_JOB_MS = 30 * 60_000;

export interface HealthSnapshot {
  now: string;
  heartbeat: { last_started_at: string | null; last_success_at: string | null; last_error_at: string | null; last_error: string | null; last_jobs: number | null } | null;
  scheduler_active: boolean | null;
  last_scheduler_http: { status: number | null; at: string; error: string | null } | null;
  scheduler_http_failures_1h: number;
  queued_jobs: number; processing_jobs: number; oldest_processing_started_at: string | null;
  stale_locks: number; stale_fetch_locks: number; needs_attention_jobs: number; pending_provider_costs: number;
}
export type WorkerState = "healthy_active" | "healthy_idle" | "stopped" | "erroring" | "scheduler_disabled";

export function classifyWorker(h: HealthSnapshot): { state: WorkerState; reasons: string[] } {
  const now = Date.parse(h.now);
  const work = h.processing_jobs + h.pending_provider_costs > 0;
  const reasons: string[] = [];
  if (!h.scheduler_active) return { state: "scheduler_disabled", reasons: ["Scheduler job is missing or disabled."] };
  const http = h.last_scheduler_http;
  if (work && http && (http.status === null || http.status >= 300) && now - Date.parse(http.at) < HEALTH_STALE_MS)
    reasons.push(`Scheduler call to the worker returned ${http.status ?? "no response"}${http.status === 404 ? " (worker endpoint not deployed on the published site)" : ""}.`);
  const ok = h.heartbeat?.last_success_at ? Date.parse(h.heartbeat.last_success_at) : null;
  const err = h.heartbeat?.last_error_at ? Date.parse(h.heartbeat.last_error_at) : null;
  if (err && (!ok || err > ok)) reasons.push(`Last worker run failed: ${h.heartbeat?.last_error ?? "unknown error"}.`);
  const fresh = ok !== null && now - ok < HEALTH_STALE_MS;
  if (h.oldest_processing_started_at && now - Date.parse(h.oldest_processing_started_at) > STUCK_JOB_MS && !fresh) reasons.push("A processing job has made no progress for over 30 minutes.");
  if (!work) return { state: "healthy_idle", reasons };
  if (fresh && !reasons.length) return { state: "healthy_active", reasons };
  if (err && (!ok || err > ok)) return { state: "erroring", reasons };
  if (!fresh) reasons.unshift(ok ? "No successful worker run in the last 3 minutes while work is waiting." : "The worker has never completed a run while work is waiting.");
  return { state: fresh ? "erroring" : "stopped", reasons };
}
