import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { classifyWorker, type HealthSnapshot } from "./worker_health_v1";

const NOW = "2026-10-09T06:00:00Z";
const ago = (m: number) => new Date(Date.parse(NOW) - m * 60000).toISOString();
const base = (o: Partial<HealthSnapshot> = {}): HealthSnapshot => ({ now: NOW, heartbeat: null, scheduler_active: true, last_scheduler_http: null, scheduler_http_failures_1h: 0, queued_jobs: 0, processing_jobs: 0, oldest_processing_started_at: null, stale_locks: 0, stale_fetch_locks: 0, needs_attention_jobs: 0, pending_provider_costs: 0, ...o });
const hb = (ok: number | null, err: number | null = null) => ({ last_started_at: null, last_success_at: ok === null ? null : ago(ok), last_error_at: err === null ? null : ago(err), last_error: err === null ? null : "boom", last_jobs: 1 });

describe("worker health", () => {
  it("idle with no work is healthy even with an old heartbeat", () => {
    expect(classifyWorker(base({ heartbeat: hb(600) })).state).toBe("healthy_idle");
  });
  it("this incident: processing job, scheduler getting 404, worker never ran => stopped with deploy hint", () => {
    const r = classifyWorker(base({ processing_jobs: 1, oldest_processing_started_at: ago(600), last_scheduler_http: { status: 404, at: ago(0.5), error: null } }));
    expect(r.state).toBe("stopped");
    expect(r.reasons.join(" ")).toMatch(/never completed[\s\S]*404 \(worker endpoint not deployed/);
  });
  it("recent successful tick with work => healthy_active", () => {
    expect(classifyWorker(base({ processing_jobs: 1, oldest_processing_started_at: ago(2), heartbeat: hb(0.5), last_scheduler_http: { status: 200, at: ago(0.5), error: null } })).state).toBe("healthy_active");
  });
  it("worker crash after last success => erroring", () => {
    expect(classifyWorker(base({ processing_jobs: 1, heartbeat: hb(5, 1) })).state).toBe("erroring");
  });
  it("stopped worker after previous success => stopped", () => {
    expect(classifyWorker(base({ processing_jobs: 2, heartbeat: hb(20) })).state).toBe("stopped");
  });
  it("disabled scheduler is reported", () => {
    expect(classifyWorker(base({ scheduler_active: false })).state).toBe("scheduler_disabled");
  });
});

describe("worker wiring", () => {
  const tick = readFileSync("src/routes/api/public/pipeline-tick.ts", "utf8");
  const pipe = readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8");
  const mig = readFileSync("drizzle/migrations/0018_pipeline_worker_health.sql", "utf8");
  it("token verified before any work; crashes are recorded and return 500", () => {
    expect(tick.indexOf("verifyWorkerToken")).toBeLessThan(tick.indexOf("processPipelineTick()"));
    expect(tick).toContain('recordWorkerHeartbeat("error"');
  });
  it("tick records start and outcome heartbeats; selection unchanged (processing + expired/no lease)", () => {
    expect(pipe).toContain('recordWorkerHeartbeat("start")');
    expect(pipe).toMatch(/\.eq\("status", "processing"\)\.not\("pipeline_version", "is", null\)\s*\.or\(`pipeline_lease_until\.is\.null,pipeline_lease_until\.lt\./);
  });
  it("health function is service-role only and admin-gated in the server fn", () => {
    expect(mig).toMatch(/REVOKE ALL ON FUNCTION public\.pipeline_worker_health\(\) FROM PUBLIC, anon, authenticated/);
    const fns = readFileSync("src/lib/nichegap/pipeline.functions.ts", "utf8");
    const h = fns.slice(fns.indexOf("export const getWorkerHealth"));
    expect(h.indexOf("has_role")).toBeLessThan(h.indexOf("workerHealth()"));
  });
});
