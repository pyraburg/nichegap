// Pure internal cost aggregation per research job. Unknown/pending costs are counted, never guessed.
export interface ExternalUsageRow { provider: string; endpoint: string; cost: number | string | null; cost_status?: string | null; cache_hit: boolean | null; status?: string | null }
export interface AiUsageRow { cost_usd: number | string | null; cost_status: string | null; status: string | null }

export interface CostLine { known_usd: number; calls: number; cache_hits: number; unknown_or_pending: number }
export interface CostSummary { google: CostLine; amazon: CostLine; community: CostLine; ai: CostLine; total_known_usd: number; complete: boolean }

const empty = (): CostLine => ({ known_usd: 0, calls: 0, cache_hits: 0, unknown_or_pending: 0 });
const val = (v: unknown) => (v === null || v === undefined || v === "" ? null : Number.isFinite(Number(v)) ? Number(v) : null);
const round = (n: number) => Math.round(n * 1e6) / 1e6;

export function summarizeCosts(ext: ExternalUsageRow[], ai: AiUsageRow[]): CostSummary {
  const s = { google: empty(), amazon: empty(), community: empty(), ai: empty() };
  for (const u of ext) {
    const line = u.provider === "apify" ? s.community : u.endpoint.includes("amazon") ? s.amazon : s.google;
    line.calls++;
    if (u.cache_hit) { line.cache_hits++; continue; }
    const c = val(u.cost);
    // Apify costs are authoritative only once finalized; DataForSEO reports cost on the response.
    const final = u.provider !== "apify" || u.cost_status === "final";
    if (c === null || !final) line.unknown_or_pending++; else line.known_usd += c;
  }
  for (const u of ai) {
    s.ai.calls++;
    if (u.status === "cache_hit") { s.ai.cache_hits++; continue; }
    const c = val(u.cost_usd);
    if (c === null) s.ai.unknown_or_pending++; else s.ai.known_usd += c;
  }
  for (const l of Object.values(s)) l.known_usd = round(l.known_usd);
  const lines = Object.values(s);
  return { ...s, total_known_usd: round(lines.reduce((a, l) => a + l.known_usd, 0)), complete: lines.every((l) => l.unknown_or_pending === 0) };
}
