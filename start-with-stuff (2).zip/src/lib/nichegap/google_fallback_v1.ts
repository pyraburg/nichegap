// google_fallback_v1 — pure, deterministic Google seed fallback (no I/O; all effects injected).
// When the original phrase returns no measured demand, at most ONE broader seed that keeps the user's intent
// is tried. Real DataForSEO data only: nothing is estimated, and every row records which seed produced it.
import type { KeywordEvidence } from "./dataforseo.server";

export const GOOGLE_FALLBACK_VERSION = "google_fallback_v1";
export const GOOGLE_DATA_TYPE = "google_keyword_demand";
/** Unusable original-seed result kept for audit/resume; never read by scoring or reports. */
export const GOOGLE_ATTEMPT_DATA_TYPE = "google_keyword_demand_attempt";

const STOP = new Set(["a", "an", "the", "and", "or", "of", "for", "to", "in", "on", "with", "my", "your", "our", "their", "is", "are", "at", "by", "from", "without", "during", "near"]);
const QUALIFIER_PREPS = ["for", "in", "with", "without", "during", "near", "at", "by", "from"];
const TRAILING_MODIFIERS = new Set(["online", "fast", "quick", "quickly", "easy", "easily", "cheap", "free", "best", "now", "today", "uk", "usa", "us"]);

const norm = (s: string) => s.toLowerCase().replace(/[’']/g, "").replace(/[^a-z0-9]+/g, " ").trim();
const words = (s: string) => norm(s).split(" ").filter(Boolean);
export function stem(t: string) {
  let s = t;
  if (s.length > 5 && s.endsWith("ing")) s = s.slice(0, -3);
  else if (s.length > 4 && s.endsWith("es")) s = s.slice(0, -2);
  else if (s.length > 3 && s.endsWith("s") && !s.endsWith("ss")) s = s.slice(0, -1);
  if (s.length > 3 && s[s.length - 1] === s[s.length - 2]) s = s.slice(0, -1); // planning -> plann -> plan
  return s;
}
export const contentStems = (s: string) => [...new Set(words(s).filter((w) => !STOP.has(w)).map(stem))];

/** Relevant = contains every content word of the seed (filler words ignored, light plural/-ing stemming). */
export function isRelevant(keyword: string, seed: string) {
  const need = contentStems(seed); if (!need.length) return false;
  const have = new Set(words(keyword).map(stem));
  return need.every((t) => have.has(t));
}

/** Usable = at least one relevant keyword with a measured volume above zero. Null/zero = no measured demand. */
export function isUsableGoogleResult(keywords: KeywordEvidence[] | null | undefined, seed: string) {
  return (keywords ?? []).some((k) => typeof k.search_volume === "number" && Number.isFinite(k.search_volume) && k.search_volume > 0 && isRelevant(k.keyword, seed));
}

/**
 * One broader seed preserving intent, or null. Rules (in order):
 * 1. Drop a trailing qualifier clause introduced by a preposition ("meal planning for busy parents" -> "meal planning").
 * 2. Otherwise drop trailing generic modifiers ("make money online" -> "make money").
 * Never broadens to fewer than 2 words, never returns the original phrase.
 */
export function deriveFallbackSeed(query: string): string | null {
  const w = words(query);
  let seed: string[] | null = null;
  const i = w.findIndex((t, idx) => idx >= 2 && QUALIFIER_PREPS.includes(t));
  if (i >= 2) seed = w.slice(0, i);
  else {
    const s = [...w];
    while (s.length > 2 && TRAILING_MODIFIERS.has(s[s.length - 1] ?? "")) s.pop();
    if (s.length < w.length) seed = s;
  }
  if (!seed || seed.filter((t) => !STOP.has(t)).length < 2) return null;
  const out = seed.join(" ");
  return out === w.join(" ") ? null : out;
}

export interface CachedGoogleRow { id: string; processed_data: unknown; collected_at: string; expires_at: string | null }
export type FallbackStatus = "not_needed" | "no_seed" | "used" | "empty" | "blocked";
export interface GoogleFallbackDeps {
  /** This job's own persisted unusable original-seed attempt (crash/resume reuse). */
  findJobAttempt(): Promise<{ id: string; keywords: KeywordEvidence[] } | null>;
  /** Fresh, non-copied cache row for a normalized seed (any job). */
  lookupCache(normalized: string): Promise<CachedGoogleRow | null>;
  /** Per-job DataForSEO ceiling / unknown-cost gate for one Google call. */
  guard(): Promise<boolean>;
  fetch(seed: string): Promise<{ ok: boolean; cost: number | null; raw: unknown; keywords?: KeywordEvidence[] }>;
  logUsage(row: { cost: number | null; cache_hit: boolean; status: string }): Promise<void>;
  /** Persist evidence; returns the research_data id. */
  insert(row: { data_type: string; seed: string; cache_hit: boolean; raw: unknown; processed: Record<string, unknown>; collected_at?: string | null | undefined; expires_at?: string | null | undefined; fresh: boolean }): Promise<string>;
  normalize(q: string): string;
}

const kwOf = (p: unknown) => {
  const d = p as { unfiltered_keywords?: KeywordEvidence[]; keywords?: KeywordEvidence[] } | null;
  return d?.unfiltered_keywords ?? d?.keywords ?? [];
};

type SeedRes = { ok: true; id: string | null; keywords: KeywordEvidence[]; cached: CachedGoogleRow | null; raw: unknown } | { ok: false; error: string };

/** Cache-first, then one guarded paid call. Does not persist evidence (caller decides the row type). */
async function getSeed(deps: GoogleFallbackDeps, seed: string): Promise<SeedRes | { ok: false; error: "DATAFORSEO_CEILING" }> {
  const cached = await deps.lookupCache(deps.normalize(seed));
  if (cached) { await deps.logUsage({ cost: 0, cache_hit: true, status: "cache_hit" }); return { ok: true, id: null, keywords: kwOf(cached.processed_data), cached, raw: { cached_from_research_data_id: cached.id } }; }
  if (!(await deps.guard())) return { ok: false, error: "DATAFORSEO_CEILING" };
  const r = await deps.fetch(seed);
  await deps.logUsage({ cost: r.cost, cache_hit: false, status: r.ok ? "success" : "error" });
  if (!r.ok) return { ok: false, error: "Keyword data provider request failed. Please try again later." };
  return { ok: true, id: null, keywords: r.keywords ?? [], cached: null, raw: r.raw };
}

export async function runGoogleWithFallback(query: string, deps: GoogleFallbackDeps) {
  const prov = (extra: Record<string, unknown>) => ({ version: GOOGLE_FALLBACK_VERSION, original_query: query, ...extra });
  let primary: { id: string; keywords: KeywordEvidence[] };
  const resumed = await deps.findJobAttempt();
  if (resumed) primary = resumed; // already paid/persisted before a crash: never re-fetch
  else {
    const p = await getSeed(deps, query);
    if (!p.ok) return { ok: false as const, error: p.error };
    if (isUsableGoogleResult(p.keywords, query)) {
      await deps.insert({ data_type: GOOGLE_DATA_TYPE, seed: query, cache_hit: !!p.cached, raw: p.raw, fresh: !p.cached,
        collected_at: p.cached?.collected_at, expires_at: p.cached?.expires_at,
        processed: { keywords: p.keywords, seed_provenance: prov({ seed_query: query, role: "original", fallback_status: "not_needed" }) } });
      return { ok: true as const, keywords: p.keywords, fallback: "not_needed" as FallbackStatus };
    }
    // Persist the unusable original immediately (separate type so it is never scored and the stage stays resumable).
    const id = await deps.insert({ data_type: GOOGLE_ATTEMPT_DATA_TYPE, seed: query, cache_hit: !!p.cached, raw: p.raw, fresh: !p.cached,
      collected_at: p.cached?.collected_at, expires_at: p.cached?.expires_at,
      processed: { keywords: p.keywords, seed_provenance: prov({ seed_query: query, role: "original_unusable" }) } });
    primary = { id, keywords: p.keywords };
  }

  const finalizeOriginal = async (status: FallbackStatus, seed: string | null) => {
    // Copy of the original's real evidence (cache_hit=true so it is never served as a cache source).
    await deps.insert({ data_type: GOOGLE_DATA_TYPE, seed: query, cache_hit: true, fresh: false, raw: { cached_from_research_data_id: primary.id },
      processed: { keywords: primary.keywords, seed_provenance: prov({ seed_query: query, role: "original", fallback_status: status, fallback_seed: seed, primary_research_data_id: primary.id }) } });
    return { ok: true as const, keywords: primary.keywords, fallback: status };
  };

  const seed = deriveFallbackSeed(query);
  if (!seed) return finalizeOriginal("no_seed", null);
  const f = await getSeed(deps, seed);
  if (!f.ok) return f.error === "DATAFORSEO_CEILING" ? finalizeOriginal("blocked", seed) : { ok: false as const, error: f.error };
  const relevant = f.keywords.filter((k) => isRelevant(k.keyword, seed));
  const status: FallbackStatus = isUsableGoogleResult(relevant, seed) ? "used" : "empty";
  await deps.insert({ data_type: GOOGLE_DATA_TYPE, seed, cache_hit: !!f.cached, fresh: !f.cached, raw: f.raw,
    collected_at: f.cached?.collected_at, expires_at: f.cached?.expires_at,
    processed: { keywords: relevant, unfiltered_keywords: f.keywords, seed_provenance: prov({ seed_query: seed, role: "fallback", fallback_status: status, primary_research_data_id: primary.id, excluded_unrelated_count: f.keywords.length - relevant.length }) } });
  return { ok: true as const, keywords: relevant, fallback: status };
}
