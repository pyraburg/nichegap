// Pure DataForSEO per-research-job spending ceiling. Uses only provider-reported costs already logged;
// never estimates actual cost. Reserves are configured worst-case allowances per upcoming call.
export const DFS_COST_DEFAULTS = {
  ceiling_usd: 0.25,
  reserve_google_usd: 0.1, // allowance held back before a Google call (observed max 0.09)
  reserve_amazon_usd: 0.01, // allowance per Amazon call (observed 0.0033)
} as const;

export function dfsCostConfig(env: Record<string, string | undefined>) {
  const n = (k: string, d: number) => { const x = Number(env[k]); return env[k] !== undefined && env[k] !== "" && Number.isFinite(x) && x >= 0 ? x : d; };
  return {
    ceiling_usd: n("DATAFORSEO_JOB_CEILING_USD", DFS_COST_DEFAULTS.ceiling_usd),
    reserve_google_usd: DFS_COST_DEFAULTS.reserve_google_usd,
    reserve_amazon_usd: DFS_COST_DEFAULTS.reserve_amazon_usd,
  };
}
export type DfsCostConfig = ReturnType<typeof dfsCostConfig>;

export interface DfsUsageRow { cost: number | string | null; cache_hit: boolean | null; status: string | null }
export const DFS_REFUSED_STATUS = "refused_ceiling";

export function canStartDfsCall(rows: DfsUsageRow[], kind: "google" | "amazon", cfg: DfsCostConfig, inFlight = 0) {
  let spent = 0; let unknown = 0;
  for (const r of rows) {
    if (r.cache_hit || r.status === DFS_REFUSED_STATUS) continue; // cache hits and refusals are $0
    const c = r.cost === null || r.cost === "" ? NaN : Number(r.cost);
    if (Number.isFinite(c)) spent += c; else unknown++;
  }
  spent = Math.round(spent * 1e6) / 1e6;
  // Conservative: a paid call whose cost the provider did not report blocks further paid calls.
  if (unknown > 0) return { allowed: false as const, reason: "unknown_cost", spent_usd: spent };
  const reserve = kind === "google" ? cfg.reserve_google_usd : cfg.reserve_amazon_usd;
  // In-flight paid calls (cost not yet logged) are held at their reserve allowance.
  if (spent + reserve * (inFlight + 1) > cfg.ceiling_usd + 1e-9) return { allowed: false as const, reason: "ceiling", spent_usd: spent };
  return { allowed: true as const, spent_usd: spent };
}
