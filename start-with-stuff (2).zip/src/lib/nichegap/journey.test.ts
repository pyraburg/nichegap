import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { customerStatus, FAILURE_MESSAGE, indication, journeyStages, type JobFacts } from "./journey";

const facts = (o: Partial<JobFacts> = {}): JobFacts => ({
  status: "completed", stage: "complete", has_search_demand: true, has_marketplace: true, has_community: true,
  has_score: true, has_ai_analysis: true, has_report: true, ...o,
});
const states = (f: JobFacts) => Object.fromEntries(journeyStages(f).map((s) => [s.key, s.state]));

describe("customer journey status mapping", () => {
  it("pending job has not started and shows nothing complete", () => {
    const f = facts({ status: "pending", stage: "keyword_demand", has_search_demand: false, has_marketplace: false, has_community: false, has_score: false, has_ai_analysis: false, has_report: false });
    expect(customerStatus(f)).toBe("not_started");
    expect(Object.values(states(f)).every((s) => s === "waiting")).toBe(true);
  });
  it("processing on keyword_demand marks only search demand active", () => {
    const f = facts({ status: "processing", stage: "keyword_demand", has_search_demand: false, has_marketplace: false, has_community: false, has_score: false, has_ai_analysis: false, has_report: false });
    expect(customerStatus(f)).toBe("researching");
    expect(states(f)).toMatchObject({ search_demand: "active", marketplace: "waiting", opportunity: "waiting", report: "waiting" });
  });
  it("processing on amazon_supply completes search demand only after its data is stored", () => {
    const f = facts({ status: "processing", stage: "amazon_supply", has_marketplace: false, has_community: false, has_score: false, has_ai_analysis: false, has_report: false });
    expect(states(f)).toMatchObject({ search_demand: "done", marketplace: "active" });
    expect(states({ ...f, has_search_demand: false })["search_demand"]).toBe("waiting");
  });
  it("marketplace is never complete while research is still running, even if rows exist", () => {
    const f = facts({ status: "processing", stage: "amazon_supply", has_report: false });
    expect(states(f)["marketplace"]).toBe("active");
  });
  it("completed research without a report is ready for report; optional evidence marked not included", () => {
    const f = facts({ has_community: false, has_ai_analysis: false, has_report: false });
    expect(customerStatus(f)).toBe("ready_for_report");
    expect(states(f)).toMatchObject({ search_demand: "done", marketplace: "done", customer_problems: "not_included", opportunity: "done", evidence_analysis: "not_included", report: "waiting" });
    expect(customerStatus({ ...f, generating_report: true })).toBe("generating_report");
    expect(states({ ...f, generating_report: true })["report"]).toBe("active");
  });
  it("completed research with report is complete with all stages done", () => {
    expect(customerStatus(facts())).toBe("complete");
    expect(Object.values(states(facts())).every((s) => s === "done")).toBe(true);
  });
  it("failures map to needs attention at the failing step without completing it", () => {
    const k = facts({ status: "failed", stage: "keyword_demand", has_search_demand: false, has_marketplace: false, has_community: false, has_score: false, has_ai_analysis: false, has_report: false });
    expect(customerStatus(k)).toBe("needs_attention");
    expect(states(k)).toMatchObject({ search_demand: "attention", marketplace: "waiting" });
    const a = { ...k, stage: "amazon_supply", has_search_demand: true };
    expect(states(a)).toMatchObject({ search_demand: "done", marketplace: "attention" });
    expect(FAILURE_MESSAGE).not.toMatch(/api|error|request|dataforseo|apify|openai/i);
  });
  it("unknown backend statuses never look complete", () => {
    expect(customerStatus(facts({ status: "weird" }))).toBe("needs_attention");
  });
  it("indication bands", () => {
    expect([indication(80), indication(50), indication(10), indication(null)]).toEqual(["Strong", "Moderate", "Limited", "Not enough data"]);
  });
});

describe("customer pages hide internals", () => {
  const files = ["src/routes/_authenticated/dashboard.tsx", "src/routes/_authenticated/research.tsx", "src/routes/_authenticated/research_.new.tsx",
    "src/routes/_authenticated/research_.$id.index.tsx", "src/components/journey/Journey.tsx"];
  it.each(files)("%s has no provider names, costs, hashes or raw errors", (f) => {
    const src = readFileSync(f, "utf8");
    expect(src).not.toMatch(/DataForSEO|Apify|OpenAI|request_id|cost_usd|evidence_hash|packet_hash|error_message|JSON\.stringify|cache_hit/);
  });
  it("journey data reads use the signed-in browser client (RLS), never the admin client", () => {
    const src = readFileSync("src/lib/nichegap/journey-data.ts", "utf8");
    expect(src).toContain('from "@/integrations/supabase/client"');
    expect(src).not.toMatch(/client\.server|supabaseAdmin|service_role/);
  });
  it("report page links back into the journey and supports print", () => {
    const src = readFileSync("src/routes/_authenticated/research_.$id.report.tsx", "utf8");
    expect(src).toContain('to="/research/$id"');
    expect(src).toContain("window.print()");
    expect(src).not.toMatch(/provided by \{x\.provider\}|Score model/);
  });
});
