// Admin-only validation data (caller must verify the admin role first). Reads with service role; never writes scores.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { summarizeCosts } from "./pipeline/cost_summary_v1";
import { normalizeState, PIPELINE_STAGES } from "./pipeline/pipeline_v1";
import { aggregate, maxExposure, type ValidationRow } from "./validation/validation_v1";
import { aiConfig } from "./ai/ai_config_v1";
import { dfsCostConfig } from "./dataforseo-cost";
import { communityCostConfig } from "./community/apify-cost";

const BENCHMARKS = ["indoor herb gardening", "home sourdough baking"];
const n = (v: unknown) => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v)) ? null : Number(v));

export async function validationDashboard() {
  const { data: jobs } = await supabaseAdmin.from("research_queries")
    .select("id, query, target_country, language, billing, status, pipeline_state, created_at")
    .or(`billing.eq.validation,query.in.(${BENCHMARKS.map((b) => `"${b}"`).join(",")})`).order("created_at", { ascending: false });
  const list = jobs ?? [];
  const picked = list;
  const ids = picked.map((j) => j.id);
  const [opps, ext, ai, reps, comm, revs] = await Promise.all([
    supabaseAdmin.from("opportunities").select("research_query_id, opportunity_score, score_classification, demand_score, competition_opportunity_score, purchase_intent_score, trend_score, score_confidence, evidence_completeness_percent, score_breakdown, created_at").in("research_query_id", ids).eq("score_version", "score_v1_1").order("created_at", { ascending: false }),
    supabaseAdmin.from("external_api_usage").select("research_query_id, provider, endpoint, cost, cost_status, cache_hit, status").in("research_query_id", ids),
    supabaseAdmin.from("ai_usage").select("research_query_id, cost_usd, cost_status, status").in("research_query_id", ids),
    supabaseAdmin.from("reports").select("research_query_id, status").in("research_query_id", ids).eq("status", "final"),
    supabaseAdmin.from("research_data").select("research_query_id, processed_data").in("research_query_id", ids).eq("data_type", "community_discussions"),
    supabaseAdmin.from("validation_reviews").select("research_query_id, rating, notes").in("research_query_id", ids),
  ]);
  const allRows: ValidationRow[] = picked.map((j) => {
    const o = (opps.data ?? []).find((x) => x.research_query_id === j.id);
    const bd = (o?.score_breakdown ?? {}) as { evidence_quality_score?: unknown };
    const c = (comm.data ?? []).find((x) => x.research_query_id === j.id)?.processed_data as { analysis?: { metrics?: { relevant_discussions?: unknown }; evidence_quality?: { score?: unknown; confidence?: string } } } | undefined;
    const st = normalizeState(j.pipeline_state);
    const e = (ext.data ?? []).filter((x) => x.research_query_id === j.id);
    const a = (ai.data ?? []).filter((x) => x.research_query_id === j.id);
    const r = (revs.data ?? []).find((x) => x.research_query_id === j.id);
    return {
      id: j.id, query: j.query, target_country: j.target_country, language: j.language, billing: j.billing, status: j.status,
      benchmark: j.billing !== "validation",
      score: n(o?.opportunity_score), classification: o?.score_classification ?? null,
      demand: n(o?.demand_score), competition: n(o?.competition_opportunity_score), purchase_intent: n(o?.purchase_intent_score), trend: n(o?.trend_score),
      confidence: o?.score_confidence ?? null, completeness: n(o?.evidence_completeness_percent), evidence_quality: n(bd.evidence_quality_score),
      community_relevant: n(c?.analysis?.metrics?.relevant_discussions), community_quality: n(c?.analysis?.evidence_quality?.score), community_confidence: c?.analysis?.evidence_quality?.confidence ?? null,
      costs: e.length || a.length ? summarizeCosts(e as never, a as never) : null,
      report_final: (reps.data ?? []).some((x) => x.research_query_id === j.id),
      failed_stages: PIPELINE_STAGES.filter((s) => st[s].status === "failed").length,
      retries: PIPELINE_STAGES.reduce((t, s) => t + Math.max(0, st[s].attempts - 1), 0),
      review: r ? { rating: r.rating, notes: r.notes } : null,
    };
  });
  const env = process.env as Record<string, string | undefined>;
  // Benchmarks: one row per niche — the job that produced a final report (else the newest).
  const bench = new Map<string, ValidationRow>();
  for (const r of allRows.filter((x) => x.benchmark)) { const cur = bench.get(r.query); if (!cur || (!cur.report_final && r.report_final)) bench.set(r.query, r); }
  const rows = [...allRows.filter((x) => !x.benchmark), ...bench.values()];
  const ai_cfg = aiConfig(env); const dfs = dfsCostConfig(env); const com = communityCostConfig(env);
  const ceilings = { dataforseo_per_job: dfs.ceiling_usd, community_per_job: com.ceiling_usd, ai_per_analysis: ai_cfg.per_analysis_ceiling_usd, ai_daily: ai_cfg.daily_ceiling_usd };
  const validationRows = rows.filter((r) => !r.benchmark);
  return { rows, aggregate: aggregate(validationRows), benchmark_aggregate: aggregate(rows.filter((r) => r.benchmark)), ceilings, exposure: maxExposure(ceilings, 8) };
}

export async function saveReview(jobId: string, reviewer: string, rating: "good" | "questionable" | "poor", notes: string | null) {
  const { error } = await supabaseAdmin.from("validation_reviews").upsert({ research_query_id: jobId, rating, notes, reviewer_id: reviewer }, { onConflict: "research_query_id" });
  if (error) throw new Error("Review save failed.");
  return { saved: true };
}

/** Admin-created validation job: never charged (billing=validation), uses the normal pipeline and all provider ceilings. */
export async function createValidationJob(adminId: string, query: string, target_country: string, language: string) {
  const id = crypto.randomUUID();
  const { error } = await supabaseAdmin.from("research_queries").insert({ id, user_id: adminId, query, target_country, language, status: "pending", billing: "validation" });
  if (error) throw new Error("Could not create validation job.");
  const { startPipeline } = await import("./pipeline.server");
  await startPipeline(id, adminId);
  return { job_id: id };
}
