import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const input = (d: unknown) => z.object({ research_query_id: z.string().uuid() }).parse(d);

// Ownership is checked as the user (RLS) before any privileged work.
async function ownJob(ctx: { supabase: { from: (t: "research_queries") => any }; userId: string }, id: string) {
  const { data } = await ctx.supabase.from("research_queries").select("id, user_id").eq("id", id).maybeSingle();
  if (!data || data.user_id !== ctx.userId) throw new Error("Research job not found.");
}

/** Customer-safe result: no provider names, costs or raw errors. */
const safe = (r: { outcome?: string; busy?: boolean; retried?: boolean } & Record<string, unknown>) =>
  ({ outcome: r.outcome ?? null, busy: !!r.busy, retried: r.retried ?? null, reason: typeof r["reason"] === "string" ? r["reason"] : null });

export const startResearchPipeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth]).inputValidator(input)
  .handler(async ({ data, context }) => {
    await ownJob(context as never, data.research_query_id);
    const { startPipeline } = await import("./pipeline.server");
    return safe(await startPipeline(data.research_query_id, context.userId) as never);
  });

export const retryResearchPipeline = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth]).inputValidator(input)
  .handler(async ({ data, context }) => {
    await ownJob(context as never, data.research_query_id);
    const { retryPipeline } = await import("./pipeline.server");
    return safe(await retryPipeline(data.research_query_id, context.userId) as never);
  });

/** Internal cost audit: admin role required (checked server-side via has_role). */
export const getResearchCostSummary = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth]).inputValidator(input)
  .handler(async ({ data, context }) => {
    await ownJob(context as never, data.research_query_id);
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Not authorized.");
    const { costSummaryForJob } = await import("./pipeline.server");
    return costSummaryForJob(data.research_query_id);
  });

/** Internal background-worker health: admin role required (checked server-side via has_role). */
export const getWorkerHealth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (!isAdmin) throw new Error("Not authorized.");
    const { workerHealth } = await import("./pipeline.server");
    return workerHealth();
  });
