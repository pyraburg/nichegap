// amazon_collect_v1: Amazon-stage execution plan (pure orchestration over injected deps; no I/O of its own).
// - batched cache lookup, batched cache-hit inserts (one usage row per cache event)
// - controlled concurrency (default 2), deterministic per-keyword result order, allSettled semantics
// - per-job DataForSEO ceiling counts in-flight paid requests as reserved exposure
// - cross-job single-flight via DB lease per cache key; waiters poll the cache for a bounded time
import { canStartDfsCall, DFS_REFUSED_STATUS, type DfsCostConfig, type DfsUsageRow } from "./dataforseo-cost";

export const AMAZON_COLLECT_VERSION = "amazon_collect_v1";
export const AMAZON_CONCURRENCY = 2;
export const AMAZON_FETCH_TIMEOUT_MS = 45_000;
export const SINGLE_FLIGHT_LEASE_SECONDS = 120; // > fetch timeout, so a live holder never loses its lease
export const SINGLE_FLIGHT_WAIT_MS = 30_000;
export const SINGLE_FLIGHT_POLL_MS = 2_000;

/** Cache identity: every parameter that changes the provider response. */
export function amazonCacheKey(p: { endpoint: string; dataType: string; country: string; locale: string; normalized: string }) {
  return ["dataforseo", p.dataType, p.endpoint, p.country, p.locale, p.normalized].join("|");
}

/** Runs tasks with at most `limit` in flight; results keep input order; one failure never discards others. */
export async function mapLimitSettled<T, R>(items: T[], limit: number, fn: (item: T, i: number) => Promise<R>): Promise<PromiseSettledResult<R>[]> {
  const out: PromiseSettledResult<R>[] = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      try { out[i] = { status: "fulfilled", value: await fn(items[i]!, i) }; }
      catch (reason) { out[i] = { status: "rejected", reason }; }
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, worker));
  return out;
}

export interface CacheRow { id: string; normalized_query: string | null; processed_data: unknown; collected_at: string; expires_at: string | null }
/** Latest authoritative (non-copy) row per normalized query; rows are expected newest-first but we don't rely on it. */
export function latestPerKey(rows: CacheRow[]): Map<string, CacheRow> {
  const m = new Map<string, CacheRow>();
  for (const r of rows) {
    if (!r.normalized_query) continue;
    const cur = m.get(r.normalized_query);
    if (!cur || r.collected_at > cur.collected_at) m.set(r.normalized_query, r);
  }
  return m;
}

export interface Selected { keyword: string; normalized: string; selection: unknown }
export type FetchResult = { ok: true; cost: number | null; raw: unknown; result: unknown } | { ok: false; cost: number | null; raw: unknown };
export interface UsageInsert { cost: number | null; cache_hit: boolean; status: string; cost_source?: string }
export interface EvidenceInsert { sel: Selected; cache_hit: boolean; cached?: CacheRow; fetched?: { raw: unknown; result: unknown; collectedAt: string } }

export interface AmazonDeps {
  lookupCache(normalized: string[]): Promise<CacheRow[]>; // one query: normalized_query IN (...)
  usageRows(): Promise<DfsUsageRow[]>; // this job's DataForSEO usage so far
  insertEvidence(rows: EvidenceInsert[]): Promise<void>;
  insertUsage(rows: UsageInsert[]): Promise<void>;
  claim(key: string): Promise<string | null>;
  release(key: string, token: string): Promise<void>;
  fetch(keyword: string): Promise<FetchResult>; // throws on timeout/network
  sleep(ms: number): Promise<void>;
  cacheKey(normalized: string): string;
  costConfig: DfsCostConfig;
  concurrency?: number;
  waitMs?: number;
  pollMs?: number;
}

export type KeywordOutcome =
  | { keyword: string; kind: "cache_hit" | "shared_hit" | "fetched" }
  | { keyword: string; kind: "refused" | "provider_error" | "timeout" | "busy" };

export async function collectAmazon(todo: Selected[], deps: AmazonDeps): Promise<{ ok: boolean; ceiling: boolean; outcomes: KeywordOutcome[] }> {
  if (!todo.length) return { ok: true, ceiling: false, outcomes: [] };
  // 1) One batched cache lookup; cache hits are inserted in one batch each ($0, one usage row per cache event).
  const cache = latestPerKey(await deps.lookupCache(todo.map((s) => s.normalized)));
  const hits = todo.filter((s) => cache.has(s.normalized));
  const misses = todo.filter((s) => !cache.has(s.normalized));
  if (hits.length) {
    await deps.insertEvidence(hits.map((sel) => ({ sel, cache_hit: true, cached: cache.get(sel.normalized)! })));
    await deps.insertUsage(hits.map(() => ({ cost: 0, cache_hit: true, status: "cache_hit" })));
  }

  // 2) Paid misses with capped concurrency. Budget = logged spend + local spend + reserve per in-flight call.
  if (!misses.length) return { ok: true, ceiling: false, outcomes: todo.map((s) => ({ keyword: s.keyword, kind: "cache_hit" as const })) };
  const base = await deps.usageRows();
  const local: DfsUsageRow[] = [];
  let inFlight = 0;
  let ceiling = false;

  const one = async (sel: Selected): Promise<KeywordOutcome> => {
    const key = deps.cacheKey(sel.normalized);
    let token = await deps.claim(key);
    if (!token) {
      // Another job holds the paid request: wait (bounded) for its result instead of paying again.
      const deadline = (deps.waitMs ?? SINGLE_FLIGHT_WAIT_MS);
      for (let waited = 0; waited < deadline; waited += deps.pollMs ?? SINGLE_FLIGHT_POLL_MS) {
        await deps.sleep(deps.pollMs ?? SINGLE_FLIGHT_POLL_MS);
        const row = latestPerKey(await deps.lookupCache([sel.normalized])).get(sel.normalized);
        if (row) {
          await deps.insertEvidence([{ sel, cache_hit: true, cached: row }]);
          await deps.insertUsage([{ cost: 0, cache_hit: true, status: "cache_hit" }]);
          return { keyword: sel.keyword, kind: "shared_hit" };
        }
        token = await deps.claim(key); // holder crashed / failed: lease expired or released
        if (token) break;
      }
      if (!token) return { keyword: sel.keyword, kind: "busy" };
    }
    try {
      // Holder may have finished between our cache miss and our claim.
      const row = latestPerKey(await deps.lookupCache([sel.normalized])).get(sel.normalized);
      if (row) {
        await deps.insertEvidence([{ sel, cache_hit: true, cached: row }]);
        await deps.insertUsage([{ cost: 0, cache_hit: true, status: "cache_hit" }]);
        return { keyword: sel.keyword, kind: "shared_hit" };
      }
      // Synchronous check-and-reserve (no await between check and inFlight++), so parallel workers can't overshoot.
      const gate = canStartDfsCall([...base, ...local], "amazon", deps.costConfig, inFlight);
      if (!gate.allowed) {
        ceiling = true;
        await deps.insertUsage([{ cost: 0, cache_hit: false, status: DFS_REFUSED_STATUS, cost_source: `refused:${gate.reason}` }]);
        return { keyword: sel.keyword, kind: "refused" };
      }
      inFlight++;
      let res: FetchResult | null = null;
      try { res = await deps.fetch(sel.keyword); }
      catch { res = null; }
      finally { inFlight--; }
      // One usage row per actual provider request, written immediately (timeout => cost unknown => blocks further paid calls).
      const usage: UsageInsert = res ? { cost: res.cost, cache_hit: false, status: res.ok ? "success" : "error" } : { cost: null, cache_hit: false, status: "timeout" };
      local.push({ cost: usage.cost, cache_hit: false, status: usage.status });
      await deps.insertUsage([usage]);
      if (!res) return { keyword: sel.keyword, kind: "timeout" };
      if (!res.ok) return { keyword: sel.keyword, kind: "provider_error" }; // failures never become cache rows
      await deps.insertEvidence([{ sel, cache_hit: false, fetched: { raw: res.raw, result: res.result, collectedAt: new Date().toISOString() } }]);
      return { keyword: sel.keyword, kind: "fetched" };
    } finally {
      await deps.release(key, token!);
    }
  };

  const settled = await mapLimitSettled(misses, deps.concurrency ?? AMAZON_CONCURRENCY, one);
  const missOutcomes = settled.map((s, i): KeywordOutcome => s.status === "fulfilled" ? s.value : { keyword: misses[i]!.keyword, kind: "provider_error" });
  const byKw = new Map<string, KeywordOutcome>([...hits.map((h) => [h.keyword, { keyword: h.keyword, kind: "cache_hit" as const }] as const), ...missOutcomes.map((o) => [o.keyword, o] as const)]);
  const outcomes = todo.map((s) => byKw.get(s.keyword)!); // deterministic: selection order
  return { ok: outcomes.every((o) => o.kind === "cache_hit" || o.kind === "shared_hit" || o.kind === "fetched"), ceiling, outcomes };
}
