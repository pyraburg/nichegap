// Server-only: builds an immutable report snapshot from a stored score run + its exact evidence.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { type ReportScoreRun } from "./report/report_v1";
import { type CommunityEvidenceRow } from "./report/report_v2";
import { buildReportV3, REPORT_VERSION_V3 as REPORT_VERSION, type AiAnalysisRow } from "./report/report_v3";
import { COMMUNITY_MULTI_DATA_TYPE } from "./community/multi_query_v1";
import { DEFAULT_SCORE_VERSION, scoreResearchJob } from "./scoring.server";

export async function generateReportForJob(jobId: string, userId: string, opts: { pipelineReady?: boolean } = {}) {
  const { data: job, error: jErr } = await supabaseAdmin.from("research_queries")
    .select("id, user_id, query, target_country, language, status, completed_at, created_at").eq("id", jobId).single();
  if (jErr || !job || job.user_id !== userId) throw new Error("Research job not found.");
  // pipelineReady: the orchestrator has verified research, score and AI stages are complete.
  if (job.status !== "completed" && !opts.pipelineReady) throw new Error("Report is only available for completed research.");

  const latestRun = () => supabaseAdmin.from("score_runs")
    .select("id, opportunity_id, score_version, created_at, evidence_hash, evidence_research_data_ids, result")
    .eq("research_query_id", jobId).eq("score_version", DEFAULT_SCORE_VERSION)
    .order("created_at", { ascending: false }).limit(1).maybeSingle();
  let { data: run } = await latestRun();
  if (!run) { await scoreResearchJob(jobId, job.query, DEFAULT_SCORE_VERSION); ({ data: run } = await latestRun()); }
  if (!run) throw new Error("No score is available for this research.");

  // Latest finalized community evidence (descriptive only; not part of the score).
  const { data: community } = await supabaseAdmin.from("research_data").select("id, collected_at, processed_data")
    .eq("research_query_id", jobId).eq("data_type", COMMUNITY_MULTI_DATA_TYPE)
    .order("collected_at", { ascending: false }).limit(1).maybeSingle();

  // Latest successful, server-validated AI analysis (never generated here).
  const { data: ai } = await supabaseAdmin.from("ai_analyses")
    .select("status, model, analysis_version, evidence_packet_hash, completed_at, validated_output, evidence_packet")
    .eq("research_query_id", jobId).eq("status", "completed").not("validated_output", "is", null)
    .order("completed_at", { ascending: false }).limit(1).maybeSingle();

  const { data: existingRows } = await supabaseAdmin.from("reports").select("id, report_data")
    .eq("research_query_id", jobId).eq("score_run_id", run.id).eq("report_version", REPORT_VERSION);
  const existing = (existingRows ?? []).find((r) => {
    const d = r.report_data as { community?: { research_data_id?: string | null }; ai?: { evidence_packet_hash?: string | null } | null } | null;
    return (d?.community?.research_data_id ?? null) === (community?.id ?? null) && (d?.ai?.evidence_packet_hash ?? null) === (ai?.evidence_packet_hash ?? null);
  });
  if (existing) return { report_id: existing.id, reused: true };

  const { data: rows, error: eErr } = await supabaseAdmin.from("research_data")
    .select("id, data_type, processed_data, collected_at").in("id", run.evidence_research_data_ids);
  if (eErr) throw eErr;
  const g = rows?.find((r) => r.data_type === "google_keyword_demand");
  const amazon = (rows ?? []).filter((r) => r.data_type === "amazon_marketplace_supply")
    .map((r) => ({ ...(r.processed_data as object), collected_at: r.collected_at }) as never);

  const now = new Date().toISOString();
  const snapshot = buildReportV3(job, run as unknown as ReportScoreRun, {
    google: g ? { keywords: ((g.processed_data as { keywords?: never[] } | null)?.keywords) ?? [], collected_at: g.collected_at } : null,
    amazon,
  }, (community as unknown as CommunityEvidenceRow) ?? null, (ai as unknown as AiAnalysisRow) ?? null, now);

  const { data: rep, error: rErr } = await supabaseAdmin.from("reports").insert({
    user_id: userId, research_query_id: jobId, opportunity_id: run.opportunity_id ?? null, score_run_id: run.id,
    status: "final", report_version: REPORT_VERSION, report_data: snapshot as never, generated_at: now, finalized_at: now,
  }).select("id").single();
  if (rErr) throw rErr;
  return { report_id: rep.id, reused: false };
}
