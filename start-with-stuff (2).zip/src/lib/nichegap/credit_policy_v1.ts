// Pure Research Credit commercial policy (Phase 6.3). The score never affects charging.
import { MAX_STAGE_ATTEMPTS, PIPELINE_STAGES, type PipelineState } from "./pipeline/pipeline_v1";

export type CreditDecision = "finalize" | "keep_reserved" | "release";

/**
 * complete → finalize (exactly once; DB function is idempotent).
 * a failed stage that can still be retried → keep the reservation ("Needs attention", Try again is free).
 * a failed stage whose controlled attempts are exhausted → release (credit returned, same type).
 * All current failure causes are technical/provider/internal — none are customer-caused.
 */
export function creditDecision(outcome: "complete" | "needs_attention" | "in_progress", state: PipelineState): CreditDecision {
  if (outcome === "complete") return "finalize";
  if (outcome !== "needs_attention") return "keep_reserved";
  return PIPELINE_STAGES.some((s) => state[s].status === "failed" && state[s].attempts >= MAX_STAGE_ATTEMPTS) ? "release" : "keep_reserved";
}

export const CREDIT_POLICY_TEXT =
  "Each complete Opportunity Report uses 1 Research Credit. If NicheGap can't complete your report because of a technical problem, your credit won't be lost.";

export const REFUND_MESSAGE = "We couldn't complete your report, so your Research Credit has been returned.";
/** Shown only when the job's reservation is actually in the released state. */
export const showRefundNotice = (reservationStatus: string | null | undefined) => reservationStatus === "released";
