import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Customer picks a plan key only; variant, price, credits and account are decided server-side. */
export const startCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ plan: z.enum(["monthly", "topup_5", "topup_15", "topup_40"]) }).parse(d))
  .handler(async ({ data, context }) => {
    const { createCheckoutUrl } = await import("./billing.server");
    const origin = new URL(getRequest().url).origin;
    const email = (context.claims as { email?: string }).email ?? null;
    try { return { url: await createCheckoutUrl(context.userId, email, data.plan, origin) }; }
    catch { return { url: null }; }
  });

export const openCustomerPortal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { customerPortalUrl } = await import("./billing.server");
    try { return { url: await customerPortalUrl(context.userId) }; } catch { return { url: null }; }
  });
