// Server-only grounded AI analysis engine. The OpenAI call is gated by AI_ANALYSIS_ENABLED, configured
// prices (cost ceilings) and OPENAI_API_KEY; the key never leaves the server.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { buildEvidencePacket, packetHash, packetStats, EVIDENCE_PACKET_VERSION, type PacketInput } from "./evidence_packet_v1";
import { ANALYSIS_VERSION } from "./analysis_schema_v1";
import { aiConfig, buildResponsesRequest, canStartAnalysis, costFromUsage } from "./ai_config_v1";
import { validateAnalysis } from "./grounding_v1";
import { COMMUNITY_MULTI_DATA_TYPE } from "../community/multi_query_v1";
import type { GoogleKeyword } from "../scoring/score_v1";

export async function loadEvidencePacket(jobId: string, userId: string) {
  const { data: job } = await supabaseAdmin.from("research_queries").select("id, user_id, query, target_country, language, status").eq("id", jobId).maybeSingle();
  if (!job || job.user_id !== userId) throw new Error("Research job not found.");
  const { data: run } = await supabaseAdmin.from("score_runs").select("id, score_version, evidence_research_data_ids, result")
    .eq("research_query_id", jobId).eq("score_version", "score_v1_1").order("created_at", { ascending: false }).limit(1).maybeSingle();
  const ids = (run?.evidence_research_data_ids as string[] | undefined) ?? [];
  const { data: rows } = ids.length ? await supabaseAdmin.from("research_data").select("id, data_type, processed_data").in("id", ids) : { data: [] };
  const { data: community } = await supabaseAdmin.from("research_data").select("processed_data")
    .eq("research_query_id", jobId).eq("data_type", COMMUNITY_MULTI_DATA_TYPE).order("collected_at", { ascending: false }).limit(1).maybeSingle();
  const r = run?.result as { opportunity_score?: number; classification?: string; confidence?: string; components?: { trend?: { inputs?: Record<string, unknown> } } } | undefined;
  const ti = r?.components?.trend?.inputs ?? {};
  const cp = community?.processed_data as { discussions?: never[]; comments?: never[]; analysis?: { post_analysis?: never[] } } | null;
  const input: PacketInput = {
    job,
    score: r ? { opportunity_score: r.opportunity_score ?? null, classification: r.classification ?? null, score_version: run!.score_version, confidence: r.confidence ?? null } : null,
    trend: { classification: (ti["classification"] as string) ?? null, growth_rate: (ti["growth_rate"] as number) ?? null, seasonality_ratio: (ti["seasonality_ratio"] as number) ?? null },
    google: ((rows ?? []).find((x) => x.data_type === "google_keyword_demand")?.processed_data as { keywords?: GoogleKeyword[] } | null)?.keywords ?? null,
    amazon: (rows ?? []).filter((x) => x.data_type === "amazon_marketplace_supply").map((x) => x.processed_data as never),
    community: cp ? { discussions: cp.discussions ?? [], comments: cp.comments ?? [], post_analysis: cp.analysis?.post_analysis ?? [] } : null,
  };
  const packet = buildEvidencePacket(input);
  return { job, packet, hash: await packetHash(packet), stats: packetStats(packet) };
}

/** Cache lookup + idempotent claim. Never calls the model. */
export async function prepareAnalysis(jobId: string, userId: string) {
  const cfg = aiConfig(process.env);
  const { job, packet, hash, stats } = await loadEvidencePacket(jobId, userId);
  const key = { research_query_id: job.id, evidence_packet_hash: hash, analysis_version: ANALYSIS_VERSION, model: cfg.model };
  const { data: existing } = await supabaseAdmin.from("ai_analyses").select("id, status").match(key).maybeSingle();
  if (existing && existing.status !== "failed") return { cached: true, analysis_id: existing.id, status: existing.status, hash, stats, packet };
  return { cached: false, analysis_id: existing?.id ?? null, status: null, hash, stats, packet, key };
}

export async function runAnalysis(jobId: string, userId: string) {
  const cfg = aiConfig(process.env);
  const prep = await prepareAnalysis(jobId, userId);
  if (prep.cached) {
    await supabaseAdmin.from("ai_usage").insert({ ai_analysis_id: prep.analysis_id, research_query_id: jobId, user_id: userId, provider: cfg.provider, model: cfg.model,
      analysis_version: ANALYSIS_VERSION, evidence_packet_hash: prep.hash, status: "cache_hit", cost_usd: 0, cost_status: "final", completed_at: new Date().toISOString() });
    return { analysis_id: prep.analysis_id, cached: true };
  }
  const since = new Date(Date.now() - 86400000).toISOString();
  const { data: today } = await supabaseAdmin.from("ai_usage").select("cost_usd, status").gte("created_at", since);
  const gate = canStartAnalysis({
    estimated_input_tokens: prep.stats.estimated_tokens,
    spent_today_usd: (today ?? []).reduce((a, u) => a + (Number(u.cost_usd) || 0), 0),
    open_today: (today ?? []).filter((u) => u.status === "started").length,
  }, cfg);
  if (!gate.allowed) return { analysis_id: null, cached: false, refused: gate.reason };
  const apiKey = process.env["OPENAI_API_KEY"];
  if (!apiKey) return { analysis_id: null, cached: false, refused: "OPENAI_API_KEY is not configured" };

  // Idempotent claim (unique cache key) prevents duplicate clicks/concurrent runs.
  // A previously failed attempt is re-claimed atomically (failed -> running) instead of inserting a duplicate.
  const { data: claim, error } = prep.analysis_id
    ? await supabaseAdmin.from("ai_analyses").update({ status: "running", error_message: null, evidence_packet: prep.packet as never })
        .eq("id", prep.analysis_id).eq("status", "failed").select("id").single()
    : await supabaseAdmin.from("ai_analyses").insert({ ...prep.key!, user_id: userId, packet_version: EVIDENCE_PACKET_VERSION,
        provider: cfg.provider, status: "running", evidence_packet: prep.packet as never }).select("id").single();
  if (error || !claim) return { analysis_id: null, cached: false, refused: "analysis already in progress" };
  const { data: usage } = await supabaseAdmin.from("ai_usage").insert({ ai_analysis_id: claim.id, research_query_id: jobId, user_id: userId, provider: cfg.provider,
    model: cfg.model, analysis_version: ANALYSIS_VERSION, evidence_packet_hash: prep.hash, status: "started" }).select("id").single();

  try {
    const res = await fetch("https://api.openai.com/v1/responses", {
      method: "POST", headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify(buildResponsesRequest(prep.packet, cfg)), signal: AbortSignal.timeout(cfg.timeout_ms),
    });
    const requestId = res.headers.get("x-request-id");
    const body = (await res.json().catch(() => null)) as { error?: { code?: string; type?: string }; usage?: { input_tokens?: number; output_tokens?: number; input_tokens_details?: { cached_tokens?: number } }; output?: Array<{ content?: Array<{ type: string; text?: string }> }> } | null;
    const u = { input_tokens: body?.usage?.input_tokens ?? null, cached_input_tokens: body?.usage?.input_tokens_details?.cached_tokens ?? null, output_tokens: body?.usage?.output_tokens ?? null };
    const cost = costFromUsage(u, cfg);
    await supabaseAdmin.from("ai_usage").update({ ...u, request_id: requestId, status: res.ok ? "completed" : "failed", cost_usd: cost, cost_status: cost === null ? "unknown" : "estimated", completed_at: new Date().toISOString() }).eq("id", usage!.id);
    const providerErr = `Provider error ${res.status}${body?.error?.code || body?.error?.type ? ` (${body?.error?.code ?? body?.error?.type})` : ""}`;
    if (!res.ok) { await supabaseAdmin.from("ai_analyses").update({ status: "failed", error_message: providerErr }).eq("id", claim.id); return { analysis_id: claim.id, cached: false, error: providerErr }; }
    const text = body?.output?.flatMap((o) => o.content ?? []).find((c) => c.type === "output_text")?.text ?? "";
    let raw: unknown = null; try { raw = JSON.parse(text); } catch { /* invalid json */ }
    const { output, report } = validateAnalysis(raw, prep.packet);
    await supabaseAdmin.from("ai_analyses").update({ status: output ? "completed" : "rejected", raw_output: raw as never, validated_output: output as never, validation_report: report as never, completed_at: new Date().toISOString() }).eq("id", claim.id);
    return { analysis_id: claim.id, cached: false };
  } catch (e) {
    const timeout = e instanceof Error && e.name === "TimeoutError";
    await supabaseAdmin.from("ai_usage").update({ status: timeout ? "timeout" : "failed", completed_at: new Date().toISOString() }).eq("id", usage!.id);
    await supabaseAdmin.from("ai_analyses").update({ status: "failed", error_message: timeout ? "timeout" : "request failed" }).eq("id", claim.id);
    return { analysis_id: claim.id, cached: false, error: timeout ? "timeout" : "request failed" };
  }
}
