import { describe, expect, it } from "vitest";
import { buildEvidencePacket, packetHash, packetStats, allEvidenceIds, type PacketInput } from "./evidence_packet_v1";
import { validateAnalysis } from "./grounding_v1";
import { ANALYSIS_V1_JSON_SCHEMA, ANALYSIS_VERSION } from "./analysis_schema_v1";
import { aiConfig, buildResponsesRequest, canStartAnalysis, costFromUsage } from "./ai_config_v1";
import { scoreV1_1 } from "../scoring/score_v1_1";

const kw = (keyword: string, v: number, cpc: number | null = 1) => ({ keyword, search_volume: v, cpc, competition: "HIGH", competition_index: 50, monthly_searches: [{ year: 2026, month: 1, search_volume: v }] });
const prod = (title: string, o: Record<string, unknown> = {}) => ({ title, result_type: "amazon_serp", bought_past_month: null, rating: 4.2, review_count: 100, is_amazon_choice: false, is_best_seller: false, price: 25, ...o });
const base = (): PacketInput => ({
  job: { query: "indoor herb garden", target_country: "US", language: "en" },
  score: { opportunity_score: 66.3, classification: "Promising Opportunity", score_version: "score_v1_1", confidence: "medium" },
  trend: { classification: "stable", growth_rate: 0.02, seasonality_ratio: 1.3 },
  google: [kw("indoor herb garden", 5000), kw("indoor herb garden kit", 2000, null), kw("herb grow light", 900)] as never,
  amazon: [{ keyword: "indoor herb garden kit", results_count: 2000, categories: null, products: [prod("Indoor Herb Garden Kit A"), prod("Indoor Herb Garden Kit B", { rating: null })] }] as never,
  community: {
    discussions: [
      { discussion_id: "p1", source_platform: "reddit", title: "My indoor basil keeps dying", body: "It is so hard to keep basil alive indoors", created_at: "2026-09-01T00:00:00Z", score: 5, comment_count: null, discussion_url: "https://www.reddit.com/r/x/p1", author: "secret_user", author_fullname: "t2_x" },
      { discussion_id: "p2", source_platform: "reddit", title: "Gaming laptop", body: "gpu", created_at: "2026-09-01T00:00:00Z", score: 1, comment_count: 1, discussion_url: null },
    ],
    comments: [{ comment_id: "c1", discussion_id: "p1", text: "Get a grow light, basil needs sun", created_at: "2026-09-02T00:00:00Z", score: null, author: "other_user" }, { comment_id: "c2", discussion_id: "p2", text: "irrelevant", created_at: null, score: 1 }],
    post_analysis: [
      { discussion_id: "p1", relevance: { score: 93, band: "high" }, recency: "d31_90", authoritative: true, signals: { flags: { difficulty: true, help_seeking: false } } },
      { discussion_id: "p2", relevance: { score: 10, band: "excluded" }, recency: "d31_90", authoritative: false, signals: { flags: {} } },
    ],
  },
});

describe("ai_evidence_packet_v1", () => {
  it("excludes weak (<60) posts and their comments from the AI packet", () => {
    const i = base();
    i.community!.post_analysis[1] = { discussion_id: "p2", relevance: { score: 55, band: "weak" }, recency: "d31_90", authoritative: true, signals: { flags: {} } };
    const p = buildEvidencePacket(i);
    expect(p.evidence.community_posts.map((x) => x.title)).toEqual(["My indoor basil keeps dying"]);
    expect(JSON.stringify(p.evidence.community_comments)).not.toMatch(/irrelevant/);
    i.community!.post_analysis[1]!.relevance = { score: 60, band: "usable" };
    expect(buildEvidencePacket(i).evidence.community_posts).toHaveLength(2);
  });
  it("is deterministic with stable IDs and stable hash", async () => {
    const a = buildEvidencePacket(base()), b = buildEvidencePacket(base());
    expect(a).toEqual(b);
    expect(await packetHash(a)).toBe(await packetHash(b));
    expect([...allEvidenceIds(a)]).toContain("google_kw_001");
    expect(a.evidence.amazon_products[0]!.id).toBe("amazon_product_001");
    expect(a.evidence.community_posts[0]!.id).toBe("community_post_001");
    expect(a.evidence.community_comments[0]!.id).toBe("community_comment_001");
  });
  it("redacts identity fields", () => {
    expect(JSON.stringify(buildEvidencePacket(base()))).not.toMatch(/secret_user|other_user|t2_x|author/);
  });
  it("excludes irrelevant community evidence and its comments", () => {
    const p = buildEvidencePacket(base());
    expect(p.evidence.community_posts).toHaveLength(1);
    expect(p.evidence.community_comments).toHaveLength(1);
    expect(JSON.stringify(p)).not.toMatch(/Gaming laptop|irrelevant/);
  });
  it("keeps missing values unknown (null)", () => {
    const p = buildEvidencePacket(base());
    expect([null, undefined]).toContain(p.evidence.google_keyword_groups.find((g) => g.keyword === "indoor herb garden kit")?.cpc_usd);
    expect(p.evidence.community_posts[0]!.comment_count).toBeNull();
    expect(p.evidence.community_comments[0]!["upvotes"]).toBeNull();
    expect(p.evidence.amazon_products.find((x) => x["title"] === "Indoor Herb Garden Kit B")!["rating"]).toBeNull();
  });
  it("changed evidence creates a new hash", async () => {
    const changed = base(); changed.google![0]!.search_volume = 5001;
    expect(await packetHash(buildEvidencePacket(changed))).not.toBe(await packetHash(buildEvidencePacket(base())));
  });
  it("reports size stats", () => {
    const s = packetStats(buildEvidencePacket(base()));
    expect(s.total).toBe(s.google + s.amazon_searches + s.amazon_products + s.community_posts + s.community_comments);
    expect(s.estimated_tokens).toBeGreaterThan(0);
  });
});

const packet = buildEvidencePacket(base());
const good = {
  analysis_version: ANALYSIS_VERSION,
  executive_summary: { text: "s", evidence_ids: ["google_kw_001", "fake_999"] },
  pain_point_clusters: [{ title: "Keeping basil alive", description: "d", evidence_ids: ["community_post_001", "community_comment_001", "made_up"], evidence_count: 9, confidence: "high" }],
  unmet_needs: [{ need: "n", explanation: "e", evidence_ids: ["invented_1"], confidence: "high" }],
  existing_solution_complaints: [],
  customer_language: [
    { phrase: "so hard to keep basil alive", kind: "verbatim", evidence_ids: ["community_post_001"] },
    { phrase: "basil is impossible indoors", kind: "verbatim", evidence_ids: ["community_post_001"] },
    { phrase: "x", kind: "paraphrase", evidence_ids: ["nope"] },
  ],
  opportunity_hypotheses: [], risks_and_uncertainties: [], validation_recommendations: [],
};

describe("grounding validation", () => {
  const { output, report } = validateAnalysis(good, packet);
  it("rejects invented citations", () => {
    expect(output!.executive_summary.evidence_ids).toEqual(["google_kw_001"]);
    expect(report.removed_ids.map((r) => r.id)).toEqual(expect.arrayContaining(["fake_999", "made_up", "invented_1", "nope"]));
    expect(output!.pain_point_clusters[0]!.evidence_count).toBe(2);
  });
  it("downgrades unsupported conclusions", () => {
    expect(output!.pain_point_clusters[0]!.confidence).toBe("medium");
    expect(output!.unmet_needs[0]!.confidence).toBe("insufficient");
  });
  it("only allows verbatim quotes that exist in evidence", () => {
    expect(output!.customer_language[0]!.kind).toBe("verbatim");
    expect(output!.customer_language[1]!.kind).toBe("paraphrase");
    expect(output!.customer_language).toHaveLength(2);
    expect(report.quotes_demoted).toBe(1);
  });
  it("rejects wrong version / non-objects", () => {
    expect(validateAnalysis({ ...good, analysis_version: "v9" }, packet).output).toBeNull();
    expect(validateAnalysis("nonsense", packet).output).toBeNull();
  });
});

describe("schema, config and cost guards", () => {
  it("strict schema: every object closed with all properties required, no score fields", () => {
    const walk = (s: Record<string, unknown>) => {
      if (s["type"] === "object") {
        expect(s["additionalProperties"]).toBe(false);
        expect(new Set(s["required"] as string[])).toEqual(new Set(Object.keys(s["properties"] as object)));
        Object.values(s["properties"] as Record<string, Record<string, unknown>>).forEach(walk);
      }
      if (s["type"] === "array") walk(s["items"] as Record<string, unknown>);
    };
    walk(ANALYSIS_V1_JSON_SCHEMA as never);
    expect(JSON.stringify(ANALYSIS_V1_JSON_SCHEMA)).not.toMatch(/opportunity_score|"score"/);
  });
  it("request uses Responses strict json_schema with output cap", () => {
    const r = buildResponsesRequest(packet, aiConfig({}));
    expect(r.model).toBe("gpt-5.4-mini");
    expect(r.text.format).toMatchObject({ type: "json_schema", strict: true });
    expect(r.max_output_tokens).toBe(6000);
  });
  it("disabled by default; refuses without prices; enforces ceilings", () => {
    expect(canStartAnalysis({ estimated_input_tokens: 1000, spent_today_usd: 0, open_today: 0 }, aiConfig({})).allowed).toBe(false);
    const on = { AI_ANALYSIS_ENABLED: "true" };
    expect(canStartAnalysis({ estimated_input_tokens: 1000, spent_today_usd: 0, open_today: 0 }, aiConfig(on)).reason).toMatch(/prices not configured/);
    const priced = aiConfig({ ...on, AI_PRICE_INPUT_PER_MTOK: "1", AI_PRICE_OUTPUT_PER_MTOK: "4" });
    expect(canStartAnalysis({ estimated_input_tokens: 20000, spent_today_usd: 0, open_today: 0 }, priced).allowed).toBe(true);
    expect(canStartAnalysis({ estimated_input_tokens: 20000, spent_today_usd: 0, open_today: 0 }, aiConfig({ ...on, AI_PRICE_INPUT_PER_MTOK: "10", AI_PRICE_OUTPUT_PER_MTOK: "40" })).allowed).toBe(false);
    expect(canStartAnalysis({ estimated_input_tokens: 20000, spent_today_usd: 4.99, open_today: 0 }, priced).allowed).toBe(false);
  });
  it("cost unknown when usage or prices unknown", () => {
    expect(costFromUsage({ input_tokens: 100, cached_input_tokens: null, output_tokens: 10 }, aiConfig({}))).toBeNull();
    expect(costFromUsage({ input_tokens: null, cached_input_tokens: null, output_tokens: 10 }, aiConfig({ AI_PRICE_INPUT_PER_MTOK: "1", AI_PRICE_OUTPUT_PER_MTOK: "1" }))).toBeNull();
  });
  it("Opportunity Score regression", () => {
    const r = scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null });
    validateAnalysis(good, packet);
    expect(scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null })).toEqual(r);
  });
});
