// ai_analysis_v1 — strict Structured Outputs schema (OpenAI Responses `text.format` json_schema, strict: true).
// No field exists for scores: the model cannot produce or modify the NicheGap Opportunity Score.
export const ANALYSIS_VERSION = "ai_analysis_v1";

const ids = { type: "array", items: { type: "string" }, description: "Evidence IDs from the packet that directly support this item." } as const;
const conf = { type: "string", enum: ["high", "medium", "low", "insufficient"] } as const;
const obj = (properties: Record<string, unknown>) => ({ type: "object", additionalProperties: false, properties, required: Object.keys(properties) });

export const ANALYSIS_V1_JSON_SCHEMA = obj({
  analysis_version: { type: "string", enum: [ANALYSIS_VERSION] },
  executive_summary: obj({ text: { type: "string" }, evidence_ids: ids }),
  pain_point_clusters: { type: "array", items: obj({ title: { type: "string" }, description: { type: "string" }, evidence_ids: ids, evidence_count: { type: "integer" }, confidence: conf }) },
  unmet_needs: { type: "array", items: obj({ need: { type: "string" }, explanation: { type: "string" }, evidence_ids: ids, confidence: conf }) },
  existing_solution_complaints: { type: "array", items: obj({ complaint: { type: "string" }, solution_type: { type: "string" }, evidence_ids: ids, confidence: conf }) },
  customer_language: { type: "array", items: obj({
    phrase: { type: "string" },
    kind: { type: "string", enum: ["verbatim", "paraphrase"], description: "verbatim only if the phrase appears exactly in the cited evidence text" },
    evidence_ids: ids,
  }) },
  opportunity_hypotheses: { type: "array", items: obj({ hypothesis: { type: "string" }, rationale: { type: "string" }, evidence_ids: ids, confidence: conf }) },
  risks_and_uncertainties: { type: "array", items: obj({ risk: { type: "string" }, evidence_ids: ids }) },
  validation_recommendations: { type: "array", items: obj({ recommendation: { type: "string" }, addresses: { type: "string" }, evidence_ids: ids }) },
});

export type Confidence = "high" | "medium" | "low" | "insufficient";
export interface AnalysisV1 {
  analysis_version: typeof ANALYSIS_VERSION;
  executive_summary: { text: string; evidence_ids: string[] };
  pain_point_clusters: Array<{ title: string; description: string; evidence_ids: string[]; evidence_count: number; confidence: Confidence }>;
  unmet_needs: Array<{ need: string; explanation: string; evidence_ids: string[]; confidence: Confidence }>;
  existing_solution_complaints: Array<{ complaint: string; solution_type: string; evidence_ids: string[]; confidence: Confidence }>;
  customer_language: Array<{ phrase: string; kind: "verbatim" | "paraphrase"; evidence_ids: string[] }>;
  opportunity_hypotheses: Array<{ hypothesis: string; rationale: string; evidence_ids: string[]; confidence: Confidence }>;
  risks_and_uncertainties: Array<{ risk: string; evidence_ids: string[] }>;
  validation_recommendations: Array<{ recommendation: string; addresses: string; evidence_ids: string[] }>;
}

export const SYSTEM_PROMPT_V1 = [
  "You are an analyst for NicheGap. Analyse ONLY the evidence packet provided.",
  "Never invent search volumes, CPC, trends, products, prices, ratings, review counts, discussions, comments, engagement, market size, quotes or statistics.",
  "Every item must cite evidence IDs that exist in the packet and directly support it. If support is weak, set confidence to low or insufficient.",
  "Mark customer_language as verbatim only when the exact phrase appears in the cited evidence text; otherwise mark it paraphrase.",
  "Do not produce, restate as your own, or modify any score. The Opportunity Score is read-only context.",
].join(" ");
