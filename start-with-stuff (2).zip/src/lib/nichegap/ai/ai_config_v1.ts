// AI provider/cost configuration + pure guards. Prices are NOT hard-coded: cost is only computed when
// per-token prices are configured; otherwise cost stays unknown (never fabricated).
import { ANALYSIS_V1_JSON_SCHEMA, ANALYSIS_VERSION, SYSTEM_PROMPT_V1 } from "./analysis_schema_v1";
import { canonicalJson, type EvidencePacket } from "./evidence_packet_v1";

export const AI_DEFAULTS = {
  provider: "openai",
  model: "gpt-5.4-mini",
  endpoint: "https://api.openai.com/v1/responses",
  max_output_tokens: 6000,
  max_input_tokens: 60000,
  per_analysis_ceiling_usd: 0.25,
  daily_ceiling_usd: 5,
  timeout_ms: 180_000,
} as const;

export function aiConfig(env: Record<string, string | undefined>) {
  const n = (k: string, d: number | null) => { const v = env[k]; const x = v === undefined || v === "" ? NaN : Number(v); return Number.isFinite(x) && x >= 0 ? x : d; };
  return {
    enabled: env["AI_ANALYSIS_ENABLED"] === "true", // hard switch: no AI call unless explicitly enabled
    provider: AI_DEFAULTS.provider,
    model: env["AI_ANALYSIS_MODEL"] || AI_DEFAULTS.model,
    max_output_tokens: n("AI_MAX_OUTPUT_TOKENS", AI_DEFAULTS.max_output_tokens)!,
    max_input_tokens: n("AI_MAX_INPUT_TOKENS", AI_DEFAULTS.max_input_tokens)!,
    per_analysis_ceiling_usd: n("AI_PER_ANALYSIS_CEILING_USD", AI_DEFAULTS.per_analysis_ceiling_usd)!,
    daily_ceiling_usd: n("AI_DAILY_CEILING_USD", AI_DEFAULTS.daily_ceiling_usd)!,
    price_input_per_mtok: n("AI_PRICE_INPUT_PER_MTOK", null),
    price_cached_input_per_mtok: n("AI_PRICE_CACHED_INPUT_PER_MTOK", null),
    price_output_per_mtok: n("AI_PRICE_OUTPUT_PER_MTOK", null),
    timeout_ms: AI_DEFAULTS.timeout_ms,
  };
}
export type AiConfig = ReturnType<typeof aiConfig>;

/** Cost from reported token usage and configured prices; null when prices or usage are unknown. */
export function costFromUsage(u: { input_tokens: number | null; cached_input_tokens: number | null; output_tokens: number | null }, cfg: AiConfig) {
  if (u.input_tokens === null || u.output_tokens === null || cfg.price_input_per_mtok === null || cfg.price_output_per_mtok === null) return null;
  const cached = u.cached_input_tokens ?? 0;
  const cachedPrice = cfg.price_cached_input_per_mtok ?? cfg.price_input_per_mtok;
  return Math.round((((u.input_tokens - cached) * cfg.price_input_per_mtok + cached * cachedPrice + u.output_tokens * cfg.price_output_per_mtok) / 1e6) * 1e6) / 1e6;
}

/** Pre-call guard. Worst case uses max_output_tokens; refuses when prices are unknown and a ceiling is set. */
export function canStartAnalysis(args: { estimated_input_tokens: number; spent_today_usd: number; open_today: number }, cfg: AiConfig) {
  if (!cfg.enabled) return { allowed: false, reason: "AI analysis is disabled (AI_ANALYSIS_ENABLED is not true)" };
  if (args.estimated_input_tokens > cfg.max_input_tokens) return { allowed: false, reason: `evidence packet exceeds ${cfg.max_input_tokens} input tokens` };
  const worst = costFromUsage({ input_tokens: args.estimated_input_tokens, cached_input_tokens: 0, output_tokens: cfg.max_output_tokens }, cfg);
  if (worst === null) return { allowed: false, reason: "model prices not configured; cannot verify the cost ceiling" };
  if (worst > cfg.per_analysis_ceiling_usd) return { allowed: false, reason: `worst-case cost $${worst} exceeds per-analysis ceiling $${cfg.per_analysis_ceiling_usd}`, worst_case_usd: worst };
  if (args.spent_today_usd + args.open_today * cfg.per_analysis_ceiling_usd + worst > cfg.daily_ceiling_usd) return { allowed: false, reason: `daily AI ceiling $${cfg.daily_ceiling_usd} would be exceeded`, worst_case_usd: worst };
  return { allowed: true, reason: "within ceilings", worst_case_usd: worst };
}

/** OpenAI Responses request body (strict Structured Outputs). Built here; sent only by the server module. */
export function buildResponsesRequest(packet: EvidencePacket, cfg: AiConfig) {
  return {
    model: cfg.model,
    instructions: SYSTEM_PROMPT_V1,
    input: [{ role: "user", content: [{ type: "input_text", text: `EVIDENCE PACKET (${packet.packet_version}):\n${canonicalJson(packet)}` }] }],
    max_output_tokens: cfg.max_output_tokens,
    store: false,
    text: { format: { type: "json_schema", name: ANALYSIS_VERSION, strict: true, schema: ANALYSIS_V1_JSON_SCHEMA } },
  };
}
