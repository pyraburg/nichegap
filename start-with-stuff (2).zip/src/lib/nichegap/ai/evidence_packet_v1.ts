// ai_evidence_packet_v1 — deterministic, versioned evidence packet for grounded AI analysis.
// Built ONLY from finalized stored NicheGap evidence. No AI selects evidence. Identity fields never copied.
import { clusterKeywords, productRelevance, type AmazonKeywordEvidenceV11 } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";

export const EVIDENCE_PACKET_VERSION = "ai_evidence_packet_v1";
export const EVIDENCE_PACKET_V1_CONFIG = {
  max_google_groups: 15,
  max_trend_months: 24,
  max_products_per_search: 8,
  max_products_total: 40,
  max_posts: 40,
  min_community_relevance_score: 60, // usable (60–79) + high (80–100) only; weak/excluded stay in DB/report, never sent to AI
  max_comments_per_post: 5,
  max_post_chars: 1200,
  max_comment_chars: 600,
  chars_per_token_estimate: 4,
} as const;
const C = EVIDENCE_PACKET_V1_CONFIG;

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const pad = (n: number) => String(n).padStart(3, "0");
const clip = (t: string | null | undefined, max: number) => {
  if (!t) return { text: null as string | null, truncated: false };
  const s = t.replace(/\s+/g, " ").trim();
  return s.length <= max ? { text: s, truncated: false } : { text: s.slice(0, max), truncated: true };
};

export interface PacketInput {
  job: { query: string; target_country: string; language: string };
  score: { opportunity_score: number | null; classification: string | null; score_version: string; confidence: string | null } | null;
  trend: { classification?: string | null; growth_rate?: number | null; seasonality_ratio?: number | null } | null;
  google: GoogleKeyword[] | null;
  amazon: Array<AmazonKeywordEvidenceV11 & { currency?: string | null }> | null;
  community: {
    discussions: Array<Record<string, unknown>>;
    comments: Array<Record<string, unknown>>;
    post_analysis: Array<{ discussion_id: string; relevance: { score: number; band: string }; recency: string; authoritative?: boolean; signals: { flags: Record<string, boolean> } }>;
  } | null;
}

export function buildEvidencePacket(input: PacketInput) {
  const niche = input.job.query;

  // ---- Google: strongest independent keyword groups (deterministic clustering order) ----
  const google = (input.google ? clusterKeywords(input.google) : []).slice(0, C.max_google_groups).map((c, i) => {
    const k = input.google!.find((g) => g.keyword === c.representative_keyword);
    const hist = (k?.monthly_searches ?? []).slice()
      .sort((a, b) => a.year - b.year || a.month - b.month).slice(-C.max_trend_months)
      .map((m) => ({ month: `${m.year}-${String(m.month).padStart(2, "0")}`, search_volume: num(m.search_volume) }));
    return {
      id: `google_kw_${pad(i + 1)}`, type: "google_keyword_group" as const,
      keyword: c.representative_keyword, monthly_search_volume: num(c.representative_volume), grouped_variants: c.members.length,
      example_variants: c.members.slice(1, 4).map((m) => m.keyword),
      cpc_usd: num(k?.cpc), google_ads_competition: k?.competition ?? null, monthly_history: hist,
    };
  });

  // ---- Amazon: searches + relevant products only ----
  const searches = (input.amazon ?? []).slice().sort((a, b) => a.keyword.localeCompare(b.keyword));
  const amazon_searches = searches.map((a, i) => ({ id: `amazon_search_${pad(i + 1)}`, type: "amazon_search" as const, keyword: a.keyword, results_count: num(a.results_count), categories: a.categories ?? null }));
  const seen = new Set<string>();
  const amazon_products: Array<Record<string, unknown> & { id: string }> = [];
  searches.forEach((a, si) => {
    const rel = a.products.filter((p) => productRelevance(p, niche, a.keyword, a.categories).relevant_for_scoring)
      .slice().sort((x, y) => (num(y.review_count) ?? -1) - (num(x.review_count) ?? -1) || (x.title ?? "").localeCompare(y.title ?? ""));
    let taken = 0;
    for (const p of rel) {
      if (taken >= C.max_products_per_search || amazon_products.length >= C.max_products_total) break;
      const key = ((p as { asin?: string }).asin ?? p.title ?? "").toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key); taken++;
      amazon_products.push({
        id: `amazon_product_${pad(amazon_products.length + 1)}`, type: "amazon_product", found_in_search: amazon_searches[si]!.id,
        title: p.title, price: num((p as { price?: unknown }).price), currency: (p as { currency?: string }).currency ?? a.currency ?? null,
        rating: num(p.rating), review_count: num(p.review_count), bought_past_month: num(p.bought_past_month),
        sponsored: p.result_type === "amazon_paid", is_best_seller: p.is_best_seller ?? null, is_amazon_choice: p.is_amazon_choice ?? null,
      });
    }
  });

  // ---- Community: authoritative (relevant) posts only + their comments ----
  const pa = new Map((input.community?.post_analysis ?? []).map((p) => [p.discussion_id, p]));
  const relevantPosts = (input.community?.discussions ?? [])
    .filter((d) => { const a = pa.get(String(d["discussion_id"])); return a && a.relevance.band !== "excluded" && a.authoritative !== false && a.relevance.score >= C.min_community_relevance_score; })
    .sort((x, y) => pa.get(String(y["discussion_id"]))!.relevance.score - pa.get(String(x["discussion_id"]))!.relevance.score
      || String(y["created_at"] ?? "").localeCompare(String(x["created_at"] ?? "")) || String(x["discussion_id"]).localeCompare(String(y["discussion_id"])))
    .slice(0, C.max_posts);
  const posts = relevantPosts.map((d, i) => {
    const a = pa.get(String(d["discussion_id"]))!;
    const body = clip(d["body"] as string | null, C.max_post_chars);
    return {
      id: `community_post_${pad(i + 1)}`, type: "community_post" as const, platform: String(d["source_platform"] ?? "unknown"),
      community: (d["community"] as string | null) ?? null, title: (d["title"] as string | null) ?? null, text: body.text, text_truncated: body.truncated,
      created_at: (d["created_at"] as string | null) ?? null, recency: a.recency, relevance_score: a.relevance.score, relevance_band: a.relevance.band,
      signals: Object.keys(a.signals.flags).filter((k) => a.signals.flags[k]).sort(),
      upvotes: num(d["score"]), comment_count: num(d["comment_count"]), url: (d["discussion_url"] as string | null) ?? null,
      _source_id: String(d["discussion_id"]),
    };
  });
  const postIdBySource = new Map(posts.map((p) => [p._source_id, p.id]));
  const comments: Array<Record<string, unknown> & { id: string }> = [];
  for (const p of posts) {
    const mine = (input.community?.comments ?? []).filter((c) => String(c["discussion_id"]) === p._source_id)
      .sort((x, y) => String(x["created_at"] ?? "").localeCompare(String(y["created_at"] ?? "")) || String(x["comment_id"]).localeCompare(String(y["comment_id"])))
      .slice(0, C.max_comments_per_post);
    for (const c of mine) {
      const t = clip(c["text"] as string | null, C.max_comment_chars);
      if (!t.text) continue;
      comments.push({ id: `community_comment_${pad(comments.length + 1)}`, type: "community_comment", post_id: postIdBySource.get(p._source_id)!,
        text: t.text, text_truncated: t.truncated, created_at: (c["created_at"] as string | null) ?? null, upvotes: num(c["score"]) });
    }
  }

  const packet = {
    packet_version: EVIDENCE_PACKET_VERSION,
    context: {
      niche, market: input.job.target_country, language: input.job.language,
      opportunity_score: input.score?.opportunity_score ?? null, classification: input.score?.classification ?? null,
      score_version: input.score?.score_version ?? null, score_confidence: input.score?.confidence ?? null,
      trend_summary: input.trend ? { classification: input.trend.classification ?? null, growth_rate: num(input.trend.growth_rate), seasonality_ratio: num(input.trend.seasonality_ratio) } : null,
      note: "Opportunity Score is computed by NicheGap and is read-only context. Missing values are null (unknown), never zero.",
    },
    evidence: {
      google_keyword_groups: google,
      amazon_searches, amazon_products,
      community_posts: posts.map(({ _source_id: _s, ...p }) => p),
      community_comments: comments,
    },
  };
  return packet;
}
export type EvidencePacket = ReturnType<typeof buildEvidencePacket>;

/** Canonical JSON (sorted keys) so hashing is stable regardless of key insertion order. */
export function canonicalJson(v: unknown): string {
  if (v === null || typeof v !== "object") return JSON.stringify(v ?? null);
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(",")}]`;
  return `{${Object.keys(v as object).sort().filter((k) => (v as Record<string, unknown>)[k] !== undefined).map((k) => `${JSON.stringify(k)}:${canonicalJson((v as Record<string, unknown>)[k])}`).join(",")}}`;
}
export async function packetHash(p: EvidencePacket) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(canonicalJson(p)));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
export function allEvidenceIds(p: EvidencePacket): Set<string> {
  const e = p.evidence;
  return new Set([...e.google_keyword_groups, ...e.amazon_searches, ...e.amazon_products, ...e.community_posts, ...e.community_comments].map((x) => x.id));
}
export function packetStats(p: EvidencePacket) {
  const e = p.evidence; const chars = canonicalJson(p).length;
  return {
    google: e.google_keyword_groups.length, amazon_searches: e.amazon_searches.length, amazon_products: e.amazon_products.length,
    community_posts: e.community_posts.length, community_comments: e.community_comments.length,
    total: allEvidenceIds(p).size, chars, estimated_tokens: Math.ceil(chars / C.chars_per_token_estimate),
  };
}
