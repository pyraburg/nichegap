// Server-side grounding validation for ai_analysis_v1 output. Pure and deterministic.
import { allEvidenceIds, type EvidencePacket } from "./evidence_packet_v1";
import { ANALYSIS_VERSION, type AnalysisV1, type Confidence } from "./analysis_schema_v1";

export const GROUNDING_V1_RULES = {
  min_ids_for_supported: 2, // fewer valid citations => capped at "low"
  min_ids_for_high: 4,
} as const;
const G = GROUNDING_V1_RULES;
const RANK: Confidence[] = ["insufficient", "low", "medium", "high"];
const cap = (c: Confidence, max: Confidence): Confidence => (RANK.indexOf(c) > RANK.indexOf(max) ? max : c);
const norm = (s: string) => s.toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').replace(/\s+/g, " ").trim();

export interface GroundingReport { removed_ids: Array<{ section: string; id: string }>; downgraded: Array<{ section: string; index: number; from: Confidence; to: Confidence }>; dropped_items: Array<{ section: string; index: number; reason: string }>; quotes_demoted: number; valid: boolean }

function evidenceText(p: EvidencePacket, id: string): string {
  const e = p.evidence;
  const item = [...e.community_posts, ...e.community_comments, ...e.amazon_products].find((x) => x.id === id) as Record<string, unknown> | undefined;
  return item ? norm([item["title"], item["text"]].filter((x) => typeof x === "string").join(" ")) : "";
}

export function validateAnalysis(raw: unknown, packet: EvidencePacket): { output: AnalysisV1 | null; report: GroundingReport } {
  const report: GroundingReport = { removed_ids: [], downgraded: [], dropped_items: [], quotes_demoted: 0, valid: false };
  const o = raw as AnalysisV1 | null;
  if (!o || typeof o !== "object" || o.analysis_version !== ANALYSIS_VERSION) return { output: null, report };
  const known = allEvidenceIds(packet);
  const clean = (section: string, list: unknown): string[] => {
    const xs = Array.isArray(list) ? list.filter((x): x is string => typeof x === "string") : [];
    const out = [...new Set(xs)].filter((id) => { const ok = known.has(id); if (!ok) report.removed_ids.push({ section, id }); return ok; });
    return out;
  };
  const grade = (section: string, i: number, n: number, c: Confidence): Confidence => {
    const max: Confidence = n === 0 ? "insufficient" : n < G.min_ids_for_supported ? "low" : n < G.min_ids_for_high ? "medium" : "high";
    const to = cap(c, max);
    if (to !== c) report.downgraded.push({ section, index: i, from: c, to });
    return to;
  };
  const graded = <T extends { evidence_ids: string[]; confidence: Confidence }>(section: string, xs: T[] | undefined) =>
    (xs ?? []).map((x, i) => { const ev = clean(section, x.evidence_ids); return { ...x, evidence_ids: ev, confidence: grade(section, i, ev.length, x.confidence) }; });
  const cited = <T extends { evidence_ids: string[] }>(section: string, xs: T[] | undefined) =>
    (xs ?? []).flatMap((x, i) => { const ev = clean(section, x.evidence_ids); if (!ev.length) { report.dropped_items.push({ section, index: i, reason: "no valid evidence" }); return []; } return [{ ...x, evidence_ids: ev }]; });

  const clusters = graded("pain_point_clusters", o.pain_point_clusters).map((c) => ({ ...c, evidence_count: c.evidence_ids.length }));
  const language = cited("customer_language", o.customer_language).map((l) => {
    if (l.kind !== "verbatim") return l;
    const ok = l.evidence_ids.some((id) => evidenceText(packet, id).includes(norm(l.phrase)));
    if (!ok) report.quotes_demoted++;
    return ok ? l : { ...l, kind: "paraphrase" as const };
  });
  const output: AnalysisV1 = {
    analysis_version: ANALYSIS_VERSION,
    executive_summary: { text: String(o.executive_summary?.text ?? ""), evidence_ids: clean("executive_summary", o.executive_summary?.evidence_ids) },
    pain_point_clusters: clusters,
    unmet_needs: graded("unmet_needs", o.unmet_needs),
    existing_solution_complaints: graded("existing_solution_complaints", o.existing_solution_complaints),
    customer_language: language,
    opportunity_hypotheses: graded("opportunity_hypotheses", o.opportunity_hypotheses),
    risks_and_uncertainties: cited("risks_and_uncertainties", o.risks_and_uncertainties),
    validation_recommendations: (o.validation_recommendations ?? []).map((v) => ({ ...v, evidence_ids: clean("validation_recommendations", v.evidence_ids) })),
  };
  report.valid = true;
  return { output, report };
}
