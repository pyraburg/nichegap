// Browser-side reads for the customer journey. Every query runs as the signed-in user, so
// row-level security limits results to the user's own research. Only customer-safe columns are selected.
import { supabase } from "@/integrations/supabase/client";
import type { JobFacts } from "./journey";

const COMMUNITY = "community_discussions";
const DEFAULT_SCORE_VERSION = "score_v1_1";

export interface JourneyJob {
  id: string;
  query: string;
  target_country: string;
  language: string;
  created_at: string;
  facts: JobFacts;
  score: { display: number | null; classification: string | null; demand: number | null; competition: number | null; confidence: string | null } | null;
  community: { relevant_discussions: number | null; confidence: string | null } | null;
  report_id: string | null;
}

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const str = (v: unknown) => (typeof v === "string" ? v : null);

export async function fetchJourneyJobs(opts: { id?: string; limit?: number } = {}): Promise<JourneyJob[]> {
  let q = supabase.from("research_queries").select("id, query, target_country, language, status, stage, created_at, pipeline_version, pipeline_state").order("created_at", { ascending: false });
  if (opts.id) q = q.eq("id", opts.id);
  if (opts.limit) q = q.limit(opts.limit);
  const { data: jobs, error } = await q;
  if (error) throw error;
  if (!jobs?.length) return [];
  const ids = jobs.map((j) => j.id);

  const [data, scores, ai, reports] = await Promise.all([
    supabase.from("research_data")
      .select("research_query_id, data_type, collected_at, relevant:processed_data->analysis->metrics->relevant_discussions, confidence:processed_data->analysis->evidence_quality->>confidence")
      .in("research_query_id", ids),
    supabase.from("score_runs")
      .select("research_query_id, created_at, display:result->opportunity_score_display, classification:result->>classification, confidence:result->>confidence, demand:result->components->demand->score, competition:result->components->competition->score")
      .in("research_query_id", ids).eq("score_version", DEFAULT_SCORE_VERSION).order("created_at", { ascending: false }),
    supabase.from("ai_analyses").select("research_query_id, status").in("research_query_id", ids).eq("status", "completed"),
    supabase.from("reports").select("id, research_query_id, generated_at").in("research_query_id", ids).eq("status", "final").order("generated_at", { ascending: false, nullsFirst: false }),
  ]);
  for (const r of [data, scores, ai, reports]) if (r.error) throw r.error;
  type Row = Record<string, unknown>;
  const rows = (x: { data: unknown }) => (x.data ?? []) as Row[];

  return jobs.map((j) => {
    const mine = rows(data).filter((r) => r["research_query_id"] === j.id);
    const comm = mine.filter((r) => r["data_type"] === COMMUNITY).sort((a, b) => String(b["collected_at"]).localeCompare(String(a["collected_at"])))[0];
    const sc = rows(scores).find((r) => r["research_query_id"] === j.id);
    const rep = rows(reports).find((r) => r["research_query_id"] === j.id);
    return {
      id: j.id, query: j.query, target_country: j.target_country, language: j.language, created_at: j.created_at,
      facts: {
        status: j.status, stage: j.stage,
        has_search_demand: mine.some((r) => r["data_type"] === "google_keyword_demand"),
        has_marketplace: mine.some((r) => r["data_type"] === "amazon_marketplace_supply"),
        has_community: !!comm,
        has_score: !!sc,
        has_ai_analysis: rows(ai).some((r) => r["research_query_id"] === j.id),
        has_report: !!rep,
        pipeline: j.pipeline_version ? Object.fromEntries(Object.entries((j.pipeline_state ?? {}) as Record<string, { status?: string }>).map(([k, v]) => [k, v?.status ?? "pending"])) : null,
      },
      score: sc ? { display: num(sc["display"]), classification: str(sc["classification"]), demand: num(sc["demand"]), competition: num(sc["competition"]), confidence: str(sc["confidence"]) } : null,
      community: comm ? { relevant_discussions: num(comm["relevant"]), confidence: str(comm["confidence"]) } : null,
      report_id: rep ? String(rep["id"]) : null,
    };
  });
}
