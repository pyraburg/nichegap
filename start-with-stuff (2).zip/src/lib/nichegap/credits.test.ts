import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { balanceLabel, consumeOne, creditTypeToConsume, OUT_OF_CREDITS_MESSAGE, totalCredits } from "./credits";

const read = (p: string) => readFileSync(p, "utf8");

describe("credit consumption rules", () => {
  it("monthly first, then purchased (2m+3p scenario)", () => {
    let b = { monthly: 2, purchased: 3 };
    b = consumeOne(b)!; expect(b).toEqual({ monthly: 1, purchased: 3 });
    b = consumeOne(b)!; expect(b).toEqual({ monthly: 0, purchased: 3 });
    expect(creditTypeToConsume(b)).toBe("purchased");
    b = consumeOne(b)!; expect(b).toEqual({ monthly: 0, purchased: 2 });
  });
  it("zero balance cannot consume", () => {
    expect(consumeOne({ monthly: 0, purchased: 0 })).toBeNull();
    expect(OUT_OF_CREDITS_MESSAGE).toBe("You're out of Research Credits.");
  });
  it("customer label shows only credit counts", () => {
    expect(balanceLabel({ monthly: 10, purchased: 5 })).toEqual({ headline: "Research Credits: 15", split: "10 monthly + 5 purchased" });
    expect(balanceLabel({ monthly: 10, purchased: 0 })).toEqual({ headline: "Research Credits: 10", split: null });
    expect(totalCredits({ monthly: -1, purchased: 2 })).toBe(2);
  });
});

describe("credit enforcement wiring (source guards)", () => {
  const pipe = read("src/lib/nichegap/pipeline.server.ts");
  const fns = read("src/lib/nichegap/credits.functions.ts");
  const mig = read("drizzle/migrations/0010_phase6_1_research_credits.sql");
  const tick = pipe.slice(pipe.indexOf("export async function processPipelineTick"));
  const advance = pipe.slice(pipe.indexOf("export async function advanceJob"), pipe.indexOf("export async function retryPipeline"));
  const retry = pipe.slice(pipe.indexOf("export async function retryPipeline"), pipe.indexOf("export async function costSummaryForJob"));

  it("reservation happens once, in startPipeline, before the job is queued", () => {
    const start = pipe.slice(pipe.indexOf("export async function startPipeline"), pipe.indexOf("export async function advanceJob"));
    expect(start.indexOf("reserve_research_credit")).toBeGreaterThan(-1);
    expect(start.indexOf("reserve_research_credit")).toBeLessThan(start.indexOf('status: "processing"'));
    expect(start).toContain("`research:${jobId}`");
    expect(start).toContain('"release_research_credit"');
  });
  it("background worker and retries never reserve/deduct again", () => {
    expect(tick).not.toContain("reserve_research_credit");
    expect(advance).not.toContain("reserve_research_credit");
    expect(retry).not.toContain("reserve_research_credit");
  });
  it("finalization only at full pipeline completion, credit-billed jobs only", () => {
    expect(advance).toMatch(/res\.outcome === "complete" && job\.billing === "credit"[\s\S]*finalize_research_credit/);
  });
  it("client request id is the job id (double click / duplicate request = one job)", () => {
    expect(fns).toContain("id: data.submission_id");
    expect(fns).toContain('insErr.code !== "23505"');
  });
  it("test-credit grants are admin-only and go through the ledger function", () => {
    const grant = fns.slice(fns.indexOf("export const grantTestCredits"));
    expect(grant.indexOf("has_role")).toBeLessThan(grant.indexOf("grant_research_credits"));
    expect(grant).toContain("admin_grant:${data.request_id}");
  });
  it("database: append-only ledger, serialized reservations, legacy backfill, locked-down functions", () => {
    expect(mig).toContain("BEFORE UPDATE OR DELETE ON public.credit_ledger");
    expect(mig).toContain("pg_advisory_xact_lock");
    expect(mig).toContain("research_query_id uuid NOT NULL UNIQUE");
    expect(mig).toMatch(/ADD COLUMN IF NOT EXISTS billing text NOT NULL DEFAULT 'legacy'[\s\S]*SET DEFAULT 'credit'/);
    expect(mig).toMatch(/REVOKE ALL ON FUNCTION public\.reserve_research_credit\(uuid, uuid, text\) FROM PUBLIC, anon, authenticated/);
    expect(mig).toContain("billing = 'credit' AND pipeline_version IS NULL");
  });
  it("paths that could trigger paid calls outside the reserved pipeline are admin-gated", () => {
    expect(read("src/lib/nichegap/community.functions.ts").match(/await requireAdmin\(context/g)?.length).toBe(2);
    expect(read("src/lib/nichegap/research.functions.ts")).toMatch(/billing === "credit"[\s\S]*has_role/);
  });
  it("customer pages never show ledger internals or provider costs", () => {
    const ui = read("src/components/journey/CreditBalance.tsx") + read("src/routes/_authenticated/research_.new.tsx");
    expect(ui).not.toMatch(/ledger_id|idempotency|cost_usd|token/i);
    expect(ui).toContain("Get More Credits");
    expect(ui).toContain("Manage Plan");
  });
});
