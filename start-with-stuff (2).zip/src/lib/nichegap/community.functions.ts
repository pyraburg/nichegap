import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Internal lab tooling that can trigger paid provider calls outside the credit-reserved pipeline: admins only. */
async function requireAdmin(ctx: { supabase: { rpc: (...a: never[]) => unknown }; userId: string }) {
  const { data } = await (ctx.supabase.rpc as unknown as (f: string, a: object) => Promise<{ data: unknown }>)("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (!data) throw new Error("Not authorized.");
}

export const COMMUNITY_TEST_DATA_TYPE = "community_discussions_test";
const TEST_CACHE_DAYS = 7;

// Fixed controlled-test input (Phase 4A step 1). Not the production multi-query pipeline.
const TEST_INPUT = {
  query: "indoor herb gardening",
  sort: "relevance",
  timeframe: "year",
  scrapeComments: true,
  maxPosts: 10,
  maxComments: 20,
} as const;

export const runCommunityTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ research_query_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await requireAdmin(context as never);
    const { data: job } = await context.supabase.from("research_queries")
      .select("id, user_id, target_country, language").eq("id", data.research_query_id).maybeSingle();
    if (!job || job.user_id !== context.userId) throw new Error("Research job not found.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { apifyRedditProvider, APIFY_REDDIT_ACTOR } = await import("./community/reddit-apify.server");
    const normalized = TEST_INPUT.query.trim().toLowerCase();
    const now = new Date();

    // Cache: a fresh controlled-test result for the same query is reused at $0 (no paid call).
    const { data: cached } = await supabaseAdmin.from("research_data")
      .select("id, processed_data, collected_at, expires_at")
      .eq("provider", "apify").eq("data_type", COMMUNITY_TEST_DATA_TYPE).eq("normalized_query", normalized)
      .eq("cache_hit", false).gt("expires_at", now.toISOString())
      .order("collected_at", { ascending: false }).limit(1).maybeSingle();
    if (cached) {
      await supabaseAdmin.from("external_api_usage").insert({
        user_id: context.userId, research_query_id: job.id, provider: "apify",
        endpoint: `actor:${APIFY_REDDIT_ACTOR}`, cost: 0, cache_hit: true, status: "cache_hit",
        cost_status: "final", cost_source: "cache_hit",
      });
      const p = cached.processed_data as { summary?: unknown } | null;
      return { cache_hit: true, research_data_id: cached.id, summary: p?.summary ?? null };
    }

    const result = await apifyRedditProvider.searchDiscussions({ ...TEST_INPUT });
    await supabaseAdmin.from("external_api_usage").insert({
      user_id: context.userId, research_query_id: job.id, provider: "apify",
      endpoint: `actor:${APIFY_REDDIT_ACTOR}`, cache_hit: false,
      status: result.ok ? "success" : result.partial ? "partial" : "error",
      // Cost is never finalized here: it stays pending until reconciliation reads settled run metadata.
      cost: null, intermediate_cost: result.cost_usd, provider_run_id: result.run_id,
      cost_status: result.run_id ? "pending" : "unknown",
    });
    if (result.run_id) {
      const { reconcileApifyUsage } = await import("./community/apify-cost.server");
      await reconcileApifyUsage({ userId: context.userId }).catch((e) => console.error("apify reconcile failed", e));
    }

    const summary = {
      provider: "apify", platform: "reddit", actor: APIFY_REDDIT_ACTOR, input: TEST_INPUT,
      run_status: result.run_status, ok: result.ok, partial: result.partial, error: result.error,
      cost_usd: result.cost_usd, cost_note: "Intermediate usage at collection time; final cost is recorded on the usage record after reconciliation.",
      raw_item_count: result.raw_item_count, posts: result.discussions.length, comments: result.comments.length, skipped_items: result.skipped_items,
    };
    // Keep partial evidence when the run failed after producing items.
    if (!result.ok && !result.partial) return { cache_hit: false, research_data_id: null, summary };

    const expires = new Date(now.getTime() + TEST_CACHE_DAYS * 86400000);
    const { data: row, error } = await supabaseAdmin.from("research_data").insert({
      research_query_id: job.id, provider: "apify", data_type: COMMUNITY_TEST_DATA_TYPE,
      source_query: TEST_INPUT.query, normalized_query: normalized,
      target_country: job.target_country, language: job.language,
      raw_data: { run_id: result.run_id, run_status: result.run_status, actor: APIFY_REDDIT_ACTOR, input: TEST_INPUT } as never,
      processed_data: { summary, discussions: result.discussions, comments: result.comments } as never,
      collected_at: now.toISOString(), expires_at: result.ok ? expires.toISOString() : now.toISOString(),
    }).select("id").single();
    if (error) throw error;
    return { cache_hit: false, research_data_id: row.id, summary };
  });

// Server-side reconciliation path: finalizes the caller's pending Apify costs from completed run metadata.
// Reads run metadata only; never starts an Actor run. Idempotent.
export const reconcileCommunityCosts = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { reconcileApifyUsage } = await import("./community/apify-cost.server");
    return { results: await reconcileApifyUsage({ userId: context.userId }) };
  });

// Controlled multi-query community research (Phase 4A.5): one Actor run, generated queries, guarded.
const jobInput = (d: unknown) => z.object({ research_query_id: z.string().uuid() }).parse(d);
export const startCommunityResearchFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth]).inputValidator(jobInput)
  .handler(async ({ data, context }) => {
    await requireAdmin(context as never);
    const { startCommunityResearch } = await import("./community/multi-query.server");
    return startCommunityResearch(data.research_query_id, context.userId);
  });
export const collectCommunityResearchFn = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth]).inputValidator(jobInput)
  .handler(async ({ data, context }) => {
    const { collectCommunityResearch } = await import("./community/multi-query.server");
    return collectCommunityResearch(data.research_query_id, context.userId, 30);
  });
