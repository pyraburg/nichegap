// Server-only Apify implementation of CommunityProvider (Reddit, actor fatihtahta/reddit-scraper-search-fast).
// Calls go through the Lovable connector gateway; credentials never leave the server.
import type { CommunityProvider, CommunitySearchOptions, CommunitySearchResult } from "./provider";
import { normalizeRedditComment, normalizeRedditItems, normalizeRedditPost } from "./reddit-apify.normalize";

export const APIFY_REDDIT_ACTOR = "fatihtahta~reddit-scraper-search-fast";
const GATEWAY_URL = "https://connector-gateway.lovable.dev/apify";
const MAX_WAIT_MS = 170_000; // hard ceiling for one controlled run
const POLL_WAIT_SECS = 30; // Apify long-poll per request (max 60)
const HARD_MAX_POSTS = 25;
const HARD_MAX_COMMENTS = 50;

function headers() {
  const lovable = process.env["LOVABLE_API_KEY"];
  const apify = process.env["APIFY_API_KEY"];
  if (!lovable || !apify) throw new Error("COMMUNITY_PROVIDER_NOT_CONFIGURED");
  return { Authorization: `Bearer ${lovable}`, "X-Connection-Api-Key": apify, "Content-Type": "application/json" };
}

async function call(path: string, init?: RequestInit) {
  const res = await fetch(`${GATEWAY_URL}${path}`, { ...init, headers: { ...headers(), ...(init?.headers ?? {}) } });
  const text = await res.text();
  let body: unknown = null;
  try { body = JSON.parse(text); } catch { body = text; }
  if (!res.ok) console.error(`Apify request failed [${res.status}] ${path}: ${text.slice(0, 500)}`);
  return { ok: res.ok, status: res.status, body };
}

type Run = { id?: string; status?: string; defaultDatasetId?: string; usageTotalUsd?: number };
const runOf = (b: unknown): Run => ((b as { data?: Run })?.data ?? {}) as Run;
const TERMINAL = new Set(["SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT"]);

// ---- low-level helpers for the multi-query pipeline (no behaviour change to searchDiscussions) ----
export type ApifyRun = Run & { finishedAt?: string | null; chargedEventCounts?: Record<string, number> | null; accountedChargedEventCounts?: Record<string, number> | null };
/** Starts ONE Actor run (no waiting). maxTotalChargeUsd is a hard provider-side spend cap for the run. */
export async function startRedditRun(input: Record<string, unknown>, maxTotalChargeUsd: number) {
  const r = await call(`/acts/${APIFY_REDDIT_ACTOR}/runs?maxTotalChargeUsd=${maxTotalChargeUsd.toFixed(4)}`, { method: "POST", body: JSON.stringify(input) });
  if (!r.ok) return { ok: false as const, status: r.status, run: null };
  return { ok: true as const, status: r.status, run: runOf(r.body) as ApifyRun };
}
export async function readRedditRun(runId: string, waitSecs = 0) {
  const r = await call(`/actor-runs/${runId}${waitSecs ? `?waitForFinish=${Math.min(waitSecs, 60)}` : ""}`);
  return r.ok ? (runOf(r.body) as ApifyRun) : null;
}
export async function readRedditDataset(datasetId: string) {
  const r = await call(`/datasets/${datasetId}/items?clean=true&format=json&limit=5000`);
  return r.ok && Array.isArray(r.body) ? (r.body as unknown[]) : null;
}

export const apifyRedditProvider: CommunityProvider = {
  id: "apify",
  platform: "reddit",
  normalizeDiscussion: normalizeRedditPost,
  normalizeComment: normalizeRedditComment,

  async searchDiscussions(opts: CommunitySearchOptions): Promise<CommunitySearchResult> {
    const base: CommunitySearchResult = {
      ok: false, partial: false, error: null, provider: "apify", operation: APIFY_REDDIT_ACTOR,
      run_id: null, run_status: null, cost_usd: null, discussions: [], comments: [], skipped_items: 0, raw_item_count: 0,
    };
    const input = {
      queries: [opts.query],
      sort: opts.sort,
      timeframe: opts.timeframe,
      scrapeComments: opts.scrapeComments,
      maxPosts: Math.min(opts.maxPosts, HARD_MAX_POSTS),
      maxComments: Math.min(opts.maxComments, HARD_MAX_COMMENTS),
      includeNsfw: false,
      strictSearch: false,
      strictTokenFilter: false,
      maximize_coverage: false,
      sentiment_analysis: false,
      content_analysis: false,
      forceSortNewForTimeFilteredRuns: true,
    };

    const start = await call(`/acts/${APIFY_REDDIT_ACTOR}/runs?waitForFinish=${POLL_WAIT_SECS}`, { method: "POST", body: JSON.stringify(input) });
    if (!start.ok) return { ...base, error: `Provider start failed (${start.status})` };
    let run = runOf(start.body);
    base.run_id = run.id ?? null;

    const started = Date.now();
    while (run.id && !TERMINAL.has(run.status ?? "") && Date.now() - started < MAX_WAIT_MS) {
      const poll = await call(`/actor-runs/${run.id}?waitForFinish=${POLL_WAIT_SECS}`);
      if (!poll.ok) { if (poll.status >= 400 && poll.status < 500) break; continue; }
      run = runOf(poll.body);
    }
    // Abort a run we gave up on so it stops consuming credit; keep whatever it already produced.
    if (run.id && !TERMINAL.has(run.status ?? "")) {
      const ab = await call(`/actor-runs/${run.id}/abort`, { method: "POST" });
      if (ab.ok) run = { ...run, ...runOf(ab.body) };
    }
    base.run_status = run.status ?? null;
    base.cost_usd = typeof run.usageTotalUsd === "number" ? run.usageTotalUsd : null;

    let items: unknown[] = [];
    if (run.defaultDatasetId) {
      const ds = await call(`/datasets/${run.defaultDatasetId}/items?clean=true&format=json&limit=2000`);
      if (ds.ok && Array.isArray(ds.body)) items = ds.body;
    }
    // Re-read final usage after the dataset fetch (Apify settles usage at the end of a run).
    if (run.id) {
      const fin = await call(`/actor-runs/${run.id}`);
      const f = runOf(fin.body);
      if (typeof f.usageTotalUsd === "number") base.cost_usd = f.usageTotalUsd;
    }

    const n = normalizeRedditItems(items);
    const succeeded = run.status === "SUCCEEDED";
    return {
      ...base,
      ok: succeeded,
      partial: !succeeded && items.length > 0,
      error: succeeded ? null : `Provider run ended with status ${run.status ?? "unknown"}`,
      discussions: n.discussions, comments: n.comments, skipped_items: n.skipped, raw_item_count: items.length,
    };
  },
};
