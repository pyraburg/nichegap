import { describe, expect, it } from "vitest";
import { processMultiQueryDataset, buildActorInput, multiCacheKey } from "./multi_query_v1";

const post = (id: string, query: string, title = "Indoor herb garden help", body = "my indoor herbs") => ({ kind: "post", id, query, title, body, score: 0, upvote_ratio: 0, num_comments: 0, created_utc: "2026-09-20T00:00:00Z", subreddit: "x" });
const comment = (id: string, postId: string, query: string) => ({ kind: "comment", id, postId, query, body: "I can't keep basil alive", score: 0, controversiality: null, score_hidden: null });

describe("community_multi_v1", () => {
  const items = [post("a", "q1"), post("a", "q2"), post("b", "q2", "Best gaming laptop", "need a gpu"), comment("c1", "a", "q1"), comment("c1", "a", "q2")];
  const r = processMultiQueryDataset({ niche: "indoor herb gardening", google: null, queries: ["q1", "q2", "q3"], items, as_of: "2026-10-01T00:00:00Z" });
  it("dedupes across queries but keeps every discovering query", () => {
    expect(r.discussions).toHaveLength(2);
    expect(r.discussions.find((d) => d.discussion_id === "a")!.search_queries).toEqual(["q1", "q2"]);
    expect(r.raw.duplicate_posts_removed).toBe(1);
    expect(r.raw.duplicate_comments_removed).toBe(1);
  });
  it("reports per-query stats including empty queries (partial success)", () => {
    const q3 = r.per_query.find((p) => p.query === "q3")!;
    expect(q3.unique_posts).toBe(0);
    expect(r.per_query.find((p) => p.query === "q2")!.relevant_posts).toBe(1);
  });
  it("keeps placeholder engagement unknown, not zero", () => {
    expect(r.discussions.every((d) => d.score === null && d.comment_count === null)).toBe(true);
    expect(r.comments[0]!.score).toBeNull();
  });
  it("uses one input with all queries and conservative limits; stable cache key", () => {
    const i = buildActorInput(["b", "a"]);
    expect(i.queries).toEqual(["b", "a"]);
    expect(i.maxPosts).toBeLessThanOrEqual(5);
    expect(multiCacheKey(["B ", "a"])).toBe(multiCacheKey(["a", "b"]));
  });
});
