// Pure normalizers for the Apify actor fatihtahta/reddit-scraper-search-fast.
// Deliberately drops identity fields (author, author_fullname, flair, premium, avatars, profile URLs).
import { bool, cleanText, isoDate, num, str, type NormalizedComment, type NormalizedDiscussion } from "./provider";

const redditUrl = (v: unknown): string | null => {
  const s = str(v);
  if (!s) return null;
  if (s.startsWith("/")) return `https://www.reddit.com${s}`;
  return s;
};

// Engagement integrity. This actor sometimes builds records from Reddit's RSS/Atom feed, which carries no
// score/comment data; it then emits placeholder 0s. Those are unknown, not real zeros. Evidence rules:
//  - post body_html in feed format ("submitted by ... [comments]") => engagement not provided by source
//  - upvote_ratio exactly 0 is impossible on Reddit (minimum is ~0.0x with the author's own upvote) => placeholder
//  - comment score 0 with controversiality AND score_hidden both absent => feed-derived record, score unknown
// A genuine 0 (e.g. score 0 with a real upvote_ratio, or a comment with controversiality present) stays 0.
const FEED_SIGNATURE = /submitted by[\s\S]*\[comments\]/i;
export function postEngagementIsPlaceholder(raw: Record<string, unknown>): boolean {
  const html = typeof raw["body_html"] === "string" ? (raw["body_html"] as string).replace(/&#32;/g, " ") : "";
  if (FEED_SIGNATURE.test(html)) return true;
  return raw["upvote_ratio"] === 0;
}
export function commentScoreIsPlaceholder(raw: Record<string, unknown>): boolean {
  return raw["score"] === 0 && (raw["controversiality"] === null || raw["controversiality"] === undefined)
    && (raw["score_hidden"] === null || raw["score_hidden"] === undefined);
}

export function normalizeRedditPost(raw: Record<string, unknown>): NormalizedDiscussion | null {
  if (raw["kind"] !== "post") return null;
  const id = str(raw["id"]);
  if (!id) return null;
  return {
    source_platform: "reddit",
    source_type: "post",
    discussion_id: id,
    discussion_url: redditUrl(raw["canonical_url"]) ?? redditUrl(raw["url"]) ?? redditUrl(raw["permalink"]),
    community: str(raw["subreddit"]),
    title: cleanText(raw["title"]),
    body: cleanText(raw["body"]),
    created_at: isoDate(raw["created_utc"]),
    score: postEngagementIsPlaceholder(raw) ? null : num(raw["score"]),
    upvote_ratio: postEngagementIsPlaceholder(raw) ? null : num(raw["upvote_ratio"]),
    comment_count: postEngagementIsPlaceholder(raw) ? null : num(raw["num_comments"]),
    is_deleted_or_removed: bool(raw["is_deleted_or_removed"]),
    search_query: str(raw["query"]),
  };
}

export function normalizeRedditComment(raw: Record<string, unknown>): NormalizedComment | null {
  if (raw["kind"] !== "comment") return null;
  const id = str(raw["id"]);
  if (!id) return null;
  return {
    source_platform: "reddit",
    source_type: "comment",
    comment_id: id,
    discussion_id: str(raw["postId"]),
    parent_id: str(raw["parentId"]),
    comment_url: redditUrl(raw["canonical_url"]) ?? redditUrl(raw["url"]) ?? redditUrl(raw["permalink"]),
    community: str(raw["subreddit"]),
    text: cleanText(raw["body"]),
    created_at: isoDate(raw["created_utc"]),
    score: commentScoreIsPlaceholder(raw) ? null : num(raw["score"]),
    depth: num(raw["depth"]),
    is_deleted_or_removed: bool(raw["is_deleted_or_removed"]),
    search_query: str(raw["query"]),
  };
}

/** Splits a dataset into posts/comments, deduplicating on kind:id. */
export function normalizeRedditItems(items: unknown[]) {
  const discussions: NormalizedDiscussion[] = [];
  const comments: NormalizedComment[] = [];
  const seen = new Set<string>();
  let skipped = 0;
  for (const it of items) {
    if (!it || typeof it !== "object") { skipped++; continue; }
    const raw = it as Record<string, unknown>;
    const key = `${String(raw["kind"])}:${String(raw["id"])}`;
    if (seen.has(key)) { skipped++; continue; }
    const p = normalizeRedditPost(raw);
    const c = p ? null : normalizeRedditComment(raw);
    if (!p && !c) { skipped++; continue; }
    seen.add(key);
    if (p) discussions.push(p); else comments.push(c!);
  }
  // A post reporting 0 comments while the same dataset contains its comments is contradictory => unknown.
  const withComments = new Set(comments.map((c) => c.discussion_id));
  for (const d of discussions) if (d.comment_count === 0 && withComments.has(d.discussion_id)) d.comment_count = null;
  return { discussions, comments, skipped };
}

/** Strips identity fields from a raw record before it is stored for audit. */
const IDENTITY_FIELDS = ["author", "author_fullname", "author_flair_text", "author_flair_richtext", "author_premium", "author_patreon_flair", "author_is_blocked", "author_icon_img", "author_profile_url", "flair"];
export function redactRaw(raw: Record<string, unknown>) {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(raw)) if (!IDENTITY_FIELDS.includes(k) && !k.startsWith("author_")) out[k] = v;
  return out;
}
