import { describe, expect, it } from "vitest";
import { evaluateRunCost, planReconciliation, canStartProviderCall, communityCostConfig, type ApifyRunMeta, type UsageRow } from "./apify-cost";
import { scoreV1_1 } from "../scoring/score_v1_1";

const FIN = "2026-10-06T11:01:17.344Z";
const later = new Date("2026-10-06T11:10:00Z");
const justAfter = new Date("2026-10-06T11:01:18Z");
const finalRun: ApifyRunMeta = { id: "r1", status: "SUCCEEDED", finishedAt: FIN, usageTotalUsd: 0.19817, chargedEventCounts: { item: 133 }, accountedChargedEventCounts: { item: 133 } };
const row = (o: Partial<UsageRow> = {}): UsageRow => ({ id: "u1", cost: null, cost_status: "pending", intermediate_cost: 0.04768, reconcile_attempts: 0, cache_hit: false, ...o });

describe("apify cost integrity", () => {
  it("intermediate cost (events not yet accounted) stays pending", () => {
    const e = evaluateRunCost({ ...finalRun, usageTotalUsd: 0.04768, accountedChargedEventCounts: { item: 32 } }, later);
    expect(e.cost_status).toBe("pending");
    expect(e.cost).toBeNull();
    expect(e.intermediate_cost).toBe(0.04768);
  });
  it("final cost uses usageTotalUsd once terminal, accounted and settled", () => {
    expect(evaluateRunCost(finalRun, later)).toMatchObject({ cost_status: "final", cost: 0.19817, cost_source: "apify.actor-run.usageTotalUsd" });
  });
  it("just-finished run waits for the settle window", () => {
    expect(evaluateRunCost(finalRun, justAfter).cost_status).toBe("pending");
  });
  it("delayed completion: running run stays pending, later reconciles to final", () => {
    const running = { ...finalRun, status: "RUNNING", finishedAt: null, usageTotalUsd: 0.01 };
    expect(evaluateRunCost(running, later).cost_status).toBe("pending");
    expect(planReconciliation(row(), finalRun, later)).toMatchObject({ cost_status: "final", cost: 0.19817, reconcile_attempts: 1 });
  });
  it("duplicate reconciliation is a no-op once final", () => {
    expect(planReconciliation(row({ cost_status: "final", cost: 0.19817 }), { ...finalRun, usageTotalUsd: 999 }, later)).toBeNull();
  });
  it("unknown final cost is never fabricated", () => {
    const noUsage = { ...finalRun, usageTotalUsd: null };
    expect(evaluateRunCost(noUsage, later)).toMatchObject({ cost_status: "pending", cost: null });
    expect(evaluateRunCost(noUsage, later, 20)).toMatchObject({ cost_status: "unknown", cost: null });
  });
  it("cache hits are never reconciled or charged", () => {
    expect(planReconciliation(row({ cache_hit: true, cost: 0, cost_status: "final" }), finalRun, later)).toBeNull();
    expect(canStartProviderCall([{ cost: 0, cost_status: "final", intermediate_cost: null, cache_hit: true }], communityCostConfig({})).committed_usd).toBe(0);
  });
  it("failed and aborted runs finalize with their actual usage", () => {
    expect(evaluateRunCost({ ...finalRun, status: "FAILED", usageTotalUsd: 0.003 }, later)).toMatchObject({ cost_status: "final", cost: 0.003 });
    expect(evaluateRunCost({ ...finalRun, status: "ABORTED", usageTotalUsd: 0.05 }, later)).toMatchObject({ cost_status: "final", cost: 0.05 });
  });
  it("cost ceiling refuses further calls; pending runs count as risk", () => {
    const cfg = communityCostConfig({ COMMUNITY_COST_CEILING_USD: "0.5" });
    expect(cfg.ceiling_usd).toBe(0.5);
    expect(canStartProviderCall([{ cost: 0.1, cost_status: "final", intermediate_cost: null, cache_hit: false }], cfg).allowed).toBe(true);
    expect(canStartProviderCall([{ cost: 0.3, cost_status: "final", intermediate_cost: null, cache_hit: false }], cfg).allowed).toBe(false);
    expect(canStartProviderCall([{ cost: null, cost_status: "pending", intermediate_cost: 0.01, cache_hit: false }, { cost: null, cost_status: "pending", intermediate_cost: 0.01, cache_hit: false }], communityCostConfig({})).allowed).toBe(false);
    expect(communityCostConfig({ COMMUNITY_COST_CEILING_USD: "abc" }).ceiling_usd).toBe(1);
  });
  it("Opportunity Score unaffected by cost logic", () => {
    const r = scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null });
    expect(scoreV1_1({ niche: "indoor herb garden", google: null, amazon: null })).toEqual(r);
  });
});
