// community_query_gen_v1 — deterministic community search query generator. Pure: no network, no AI.
// Seeds = original niche + highest-volume independent Google keyword groups; each seed is paired with a
// small, planned set of intent templates (not keyword × modifier), deduplicated by token set, max 8.
import { clusterKeywords, tokens } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";

export const COMMUNITY_QUERY_GEN_VERSION = "community_query_gen_v1";

export type QueryIntent = "difficulty_problem" | "frustration" | "help_seeking" | "alternatives_recommendation" | "purchase_validation";
type SeedKind = "activity" | "product";

export const COMMUNITY_QUERY_GEN_V1_CONFIG = {
  max_queries: 8,
  max_seeds: 4,
  seed_min_niche_token_overlap: 1, // a keyword group must share at least one niche token
  seed_independence_max_jaccard: 0.6, // groups more similar than this to a chosen seed are not independent
  product_tokens: ["light", "kit", "system", "planter", "pot", "tower", "machine", "tool", "set", "device", "box", "stand", "shelf"],
  // Ordered slot plan: guarantees intent diversity. `fits` = which seed kinds the template reads naturally with.
  slots: [
    { intent: "difficulty_problem", modifier: "problems", template: "{s} problems", fits: ["activity", "product"] },
    { intent: "help_seeking", modifier: "help", template: "{s} help", fits: ["activity"] },
    { intent: "alternatives_recommendation", modifier: "recommend", template: "{s} recommendations", fits: ["product", "activity"] },
    { intent: "purchase_validation", modifier: "worth it", template: "is {s} worth it", fits: ["product"] },
    { intent: "frustration", modifier: "doesn't work", template: "{s} doesn't work", fits: ["product"] },
    { intent: "help_seeking", modifier: "beginner", template: "{s} for beginners", fits: ["activity"] },
    { intent: "difficulty_problem", modifier: "struggling", template: "struggling with {s}", fits: ["activity"] },
    { intent: "alternatives_recommendation", modifier: "alternative", template: "{s} alternative", fits: ["product"] },
    // reserve slots, used only when earlier slots collapse as duplicates
    { intent: "frustration", modifier: "frustrated", template: "frustrated with {s}", fits: ["activity", "product"] },
    { intent: "help_seeking", modifier: "how to", template: "how to {s}", fits: ["activity"] },
    { intent: "difficulty_problem", modifier: "issue", template: "{s} issues", fits: ["product", "activity"] },
    { intent: "difficulty_problem", modifier: "difficult", template: "{s} difficult", fits: ["activity"] },
  ] as Array<{ intent: QueryIntent; modifier: string; template: string; fits: SeedKind[] }>,
} as const;

const C = COMMUNITY_QUERY_GEN_V1_CONFIG;

export interface QuerySeed { text: string; source: "niche" | "google_keyword_group"; volume: number | null; group_size: number | null; kind: SeedKind; tokens: string[] }
export interface GeneratedQuery { query: string; intent: QueryIntent; modifier: string; source_keyword: string; source_type: QuerySeed["source"]; source_group_volume: number | null; reason: string }

const jaccard = (a: string[], b: string[]) => {
  const A = new Set(a), B = new Set(b); const inter = [...A].filter((x) => B.has(x)).length;
  const uni = new Set([...a, ...b]).size; return uni ? inter / uni : 0;
};
const kindOf = (t: string[]): SeedKind => (t.some((x) => (C.product_tokens as readonly string[]).includes(x)) ? "product" : "activity");
/** Token-equivalence key used for deduplication (stemmed, synonym-folded, stopwords dropped, order-free). */
export const queryKey = (q: string) => tokens(q.replace(/['\u2019]/g, "")).join(" ");

export function selectSeeds(niche: string, google: GoogleKeyword[] | null): QuerySeed[] {
  const nt = tokens(niche);
  const seeds: QuerySeed[] = [{ text: niche.trim().toLowerCase(), source: "niche", volume: null, group_size: null, kind: "activity", tokens: nt }];
  for (const c of google ? clusterKeywords(google) : []) {
    if (seeds.length >= C.max_seeds) break;
    if (c.tokens.filter((t) => nt.includes(t)).length < C.seed_min_niche_token_overlap) continue;
    if (seeds.some((s) => jaccard(s.tokens, c.tokens) >= C.seed_independence_max_jaccard)) continue;
    seeds.push({ text: c.representative_keyword.toLowerCase(), source: "google_keyword_group", volume: c.representative_volume, group_size: c.members.length, kind: kindOf(c.tokens), tokens: c.tokens });
  }
  return seeds;
}

export function generateCommunityQueries(input: { niche: string; google: GoogleKeyword[] | null }) {
  const seeds = selectSeeds(input.niche, input.google);
  const used = new Map<string, number>(seeds.map((s) => [s.text, 0]));
  const keys = new Set<string>();
  const queries: GeneratedQuery[] = [];
  const rejected: Array<{ query: string; reason: string }> = [];
  for (const slot of C.slots) {
    if (queries.length >= C.max_queries) break;
    // niche fits every template; otherwise the seed kind must fit. Least-used seed first, then seed order.
    const eligible = seeds.filter((s) => s.source === "niche" || slot.fits.includes(s.kind))
      .map((s, i) => ({ s, i })).sort((a, b) => used.get(a.s.text)! - used.get(b.s.text)! || a.i - b.i);
    for (const { s } of eligible) {
      const q = slot.template.replace("{s}", s.text);
      const k = queryKey(q);
      if (keys.has(k)) { rejected.push({ query: q, reason: "token-equivalent duplicate" }); continue; }
      keys.add(k); used.set(s.text, used.get(s.text)! + 1);
      queries.push({
        query: q, intent: slot.intent, modifier: slot.modifier, source_keyword: s.text, source_type: s.source, source_group_volume: s.volume,
        reason: s.source === "niche"
          ? `Original niche with "${slot.modifier}" (${slot.intent}).`
          : `Independent Google keyword group (${s.volume}/mo, ${s.group_size} keywords, ${s.kind}) with "${slot.modifier}" (${slot.intent}); least-used eligible seed.`,
      });
      break;
    }
  }
  return { version: COMMUNITY_QUERY_GEN_VERSION, seeds: seeds.map(({ tokens: _t, ...s }) => s), queries, rejected };
}
