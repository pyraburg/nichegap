// Server-only: reads completed Apify run metadata (no Actor runs started) and reconciles usage rows.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { planReconciliation, type ApifyRunMeta, type UsageRow } from "./apify-cost";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/apify";

export async function fetchApifyRun(runId: string): Promise<ApifyRunMeta | null> {
  const lovable = process.env["LOVABLE_API_KEY"], apify = process.env["APIFY_API_KEY"];
  if (!lovable || !apify) throw new Error("COMMUNITY_PROVIDER_NOT_CONFIGURED");
  const res = await fetch(`${GATEWAY_URL}/actor-runs/${encodeURIComponent(runId)}`, {
    headers: { Authorization: `Bearer ${lovable}`, "X-Connection-Api-Key": apify },
  });
  if (!res.ok) { console.error(`Apify run read failed [${res.status}]: ${(await res.text()).slice(0, 300)}`); return null; }
  return ((await res.json()) as { data?: ApifyRunMeta }).data ?? null;
}

/** Reconciles non-final Apify usage rows (optionally only one user's). Idempotent; never inserts rows. */
export async function reconcileApifyUsage(opts: { userId?: string; now?: Date } = {}) {
  let q = supabaseAdmin.from("external_api_usage")
    .select("id, cost, cost_status, intermediate_cost, reconcile_attempts, cache_hit, provider_run_id")
    .eq("provider", "apify").eq("cache_hit", false).neq("cost_status", "final").not("provider_run_id", "is", null);
  if (opts.userId) q = q.eq("user_id", opts.userId);
  const { data: rows, error } = await q;
  if (error) throw error;
  const results: Array<{ id: string; run_id: string; status: string; cost: number | null; reason: string }> = [];
  for (const r of rows ?? []) {
    const run = await fetchApifyRun(r.provider_run_id!);
    if (!run) { results.push({ id: r.id, run_id: r.provider_run_id!, status: r.cost_status, cost: null, reason: "run metadata unavailable" }); continue; }
    const plan = planReconciliation(r as UsageRow, run, opts.now ?? new Date());
    if (!plan) continue;
    const { reason, ...update } = plan;
    // Guard on cost_status so a concurrent reconcile can never overwrite a final value.
    await supabaseAdmin.from("external_api_usage").update(update).eq("id", r.id).neq("cost_status", "final");
    results.push({ id: r.id, run_id: r.provider_run_id!, status: update.cost_status, cost: update.cost, reason });
  }
  return results;
}
