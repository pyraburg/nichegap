// community_multi_v1 — pure helpers for one multi-query Actor run: limits, discovery attribution, per-query stats.
import { normalizeRedditItems } from "./reddit-apify.normalize";
import { analyzeCommunity } from "./signals_v1";
import type { GoogleKeyword } from "../scoring/score_v1";

export const COMMUNITY_MULTI_VERSION = "community_multi_v1";
export const COMMUNITY_MULTI_DATA_TYPE = "community_discussions";
export const COMMUNITY_MULTI_CONFIG = {
  cache_days: 7,
  // Conservative first experiment: per query 5 posts x 5 comments => worst case 8*(5+25)=240 items.
  max_posts_per_query: 5,
  max_comments_per_post: 5,
  sort: "relevance",
  timeframe: "year",
  max_run_charge_usd: 0.6, // provider-side hard cap for the run (also bounded by remaining ceiling)
} as const;

export const multiCacheKey = (queries: string[]) => [...queries].map((q) => q.trim().toLowerCase()).sort().join(" | ");

export function buildActorInput(queries: string[]) {
  const C = COMMUNITY_MULTI_CONFIG;
  return {
    queries, sort: C.sort, timeframe: C.timeframe, scrapeComments: true,
    maxPosts: C.max_posts_per_query, maxComments: C.max_comments_per_post,
    includeNsfw: false, strictSearch: false, strictTokenFilter: false, maximize_coverage: false,
    sentiment_analysis: false, content_analysis: false, forceSortNewForTimeFilteredRuns: true,
  };
}

/** Normalizes the combined dataset; each unique post/comment keeps every query that discovered it. */
export function processMultiQueryDataset(input: { niche: string; google: GoogleKeyword[] | null; queries: string[]; items: unknown[]; as_of: string }) {
  const discovered = new Map<string, Set<string>>();
  let rawPosts = 0, rawComments = 0;
  const rawPerQuery = new Map<string, { posts: number; comments: number }>(input.queries.map((q) => [q, { posts: 0, comments: 0 }]));
  for (const it of input.items) {
    if (!it || typeof it !== "object") continue;
    const r = it as Record<string, unknown>;
    const key = `${String(r["kind"])}:${String(r["id"])}`;
    const q = typeof r["query"] === "string" ? (r["query"] as string) : "(unknown)";
    if (!discovered.has(key)) discovered.set(key, new Set());
    discovered.get(key)!.add(q);
    const pq = rawPerQuery.get(q) ?? { posts: 0, comments: 0 }; rawPerQuery.set(q, pq);
    if (r["kind"] === "post") { rawPosts++; pq.posts++; } else if (r["kind"] === "comment") { rawComments++; pq.comments++; }
  }
  const n = normalizeRedditItems(input.items);
  const qs = (k: string) => [...(discovered.get(k) ?? [])].sort();
  const discussions = n.discussions.map((d) => ({ ...d, search_queries: qs(`post:${d.discussion_id}`) }));
  const comments = n.comments.map((c) => ({ ...c, search_queries: qs(`comment:${c.comment_id}`) }));
  const analysis = analyzeCommunity({ niche: input.niche, google: input.google, discussions, comments, as_of: input.as_of });
  const relevantIds = new Set(analysis.posts.filter((p) => p.authoritative).map((p) => p.discussion_id));
  const per_query = [...rawPerQuery.entries()].map(([query, raw]) => {
    const mine = discussions.filter((d) => d.search_queries.includes(query));
    const relevant = mine.filter((d) => relevantIds.has(d.discussion_id)).length;
    const shared = mine.filter((d) => d.search_queries.length > 1).length;
    return { query, raw_posts: raw.posts, raw_comments: raw.comments, unique_posts: mine.length, relevant_posts: relevant,
      relevant_share: mine.length ? Math.round((relevant / mine.length) * 100) / 100 : null,
      also_found_by_other_queries: shared, only_this_query: mine.length - shared };
  });
  return {
    version: COMMUNITY_MULTI_VERSION,
    raw: { items: input.items.length, posts: rawPosts, comments: rawComments,
      duplicate_posts_removed: rawPosts - discussions.length, duplicate_comments_removed: rawComments - comments.length, skipped: n.skipped },
    per_query, discussions, comments, analysis,
  };
}
