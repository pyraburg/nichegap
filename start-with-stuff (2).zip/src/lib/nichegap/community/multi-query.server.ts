// Server-only orchestration for the controlled multi-query community run (one Actor run, many queries).
// Two steps so a long run never blocks a request: start (guards + claim + launch) and collect (idempotent).
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { APIFY_REDDIT_ACTOR, readRedditDataset, readRedditRun, startRedditRun } from "./reddit-apify.server";
import { canStartProviderCall, communityCostConfig, TERMINAL_RUN_STATUSES } from "./apify-cost";
import { reconcileApifyUsage } from "./apify-cost.server";
import { generateCommunityQueries } from "./query_gen_v1";
import { buildActorInput, COMMUNITY_MULTI_CONFIG, COMMUNITY_MULTI_DATA_TYPE, COMMUNITY_MULTI_VERSION, multiCacheKey, processMultiQueryDataset } from "./multi_query_v1";
import type { GoogleKeyword } from "../scoring/score_v1";

export const MULTI_ENDPOINT = `actor:${APIFY_REDDIT_ACTOR}#community_multi_v1`;

async function loadJob(jobId: string, userId: string) {
  const { data: job } = await supabaseAdmin.from("research_queries").select("id, user_id, query, target_country, language").eq("id", jobId).maybeSingle();
  if (!job || job.user_id !== userId) throw new Error("Research job not found.");
  const { data: g } = await supabaseAdmin.from("research_data").select("processed_data").eq("research_query_id", jobId)
    .eq("data_type", "google_keyword_demand").order("created_at", { ascending: false }).limit(1).maybeSingle();
  const google = ((g?.processed_data as { keywords?: GoogleKeyword[] } | null)?.keywords) ?? null;
  const queries = generateCommunityQueries({ niche: job.query, google }).queries.map((q) => q.query);
  return { job, google, queries };
}

export async function startCommunityResearch(jobId: string, userId: string) {
  const { job, queries } = await loadJob(jobId, userId);
  if (!queries.length) return { started: false, reason: "no queries generated" };
  const key = multiCacheKey(queries);
  const now = new Date();

  // 1. 7-day cache: identical query set already collected => reuse at $0.
  const { data: cached } = await supabaseAdmin.from("research_data").select("id")
    .eq("provider", "apify").eq("data_type", COMMUNITY_MULTI_DATA_TYPE).eq("normalized_query", key)
    .eq("cache_hit", false).gt("expires_at", now.toISOString()).limit(1).maybeSingle();
  if (cached) {
    await supabaseAdmin.from("external_api_usage").insert({ user_id: userId, research_query_id: job.id, provider: "apify",
      endpoint: `actor:${APIFY_REDDIT_ACTOR}#cache`, cost: 0, cache_hit: true, status: "cache_hit", cost_status: "final", cost_source: "cache_hit" });
    return { started: false, cache_hit: true, research_data_id: cached.id };
  }

  // 2. Cost ceiling (this job's Apify spend + risk of open runs) and global pending-run limit.
  const cfg = communityCostConfig(process.env);
  const { data: jobUsage } = await supabaseAdmin.from("external_api_usage").select("cost, cost_status, intermediate_cost, cache_hit")
    .eq("provider", "apify").eq("research_query_id", job.id);
  const { count: pendingGlobal } = await supabaseAdmin.from("external_api_usage").select("id", { count: "exact", head: true })
    .eq("provider", "apify").eq("cache_hit", false).eq("cost_status", "pending");
  const gate = canStartProviderCall((jobUsage ?? []) as never, cfg);
  if (!gate.allowed) return { started: false, reason: gate.reason, committed_usd: gate.committed_usd };
  if ((pendingGlobal ?? 0) >= cfg.max_pending_runs) return { started: false, reason: "too many pending Apify runs" };

  // 3. Duplicate lock: claim row first (unique index => one paid multi run per job).
  const { data: claim, error: claimErr } = await supabaseAdmin.from("external_api_usage").insert({
    user_id: userId, research_query_id: job.id, provider: "apify", endpoint: MULTI_ENDPOINT,
    cache_hit: false, status: "starting", cost: null, cost_status: "pending",
  }).select("id").single();
  if (claimErr) return { started: false, reason: "a multi-query run already exists for this job" };

  const maxCharge = Math.max(0, Math.min(COMMUNITY_MULTI_CONFIG.max_run_charge_usd, cfg.ceiling_usd - gate.committed_usd));
  const res = await startRedditRun(buildActorInput(queries), maxCharge);
  if (!res.ok || !res.run?.id) {
    await supabaseAdmin.from("external_api_usage").update({ status: "error", cost_status: "unknown" }).eq("id", claim.id);
    return { started: false, reason: `provider start failed (${res.status})` };
  }
  await supabaseAdmin.from("external_api_usage").update({ status: "running", provider_run_id: res.run.id, intermediate_cost: res.run.usageTotalUsd ?? null }).eq("id", claim.id);
  return { started: true, run_id: res.run.id, queries, max_charge_usd: maxCharge, usage_id: claim.id };
}

/** Collects a finished run's dataset into research_data once (idempotent), then reconciles cost. */
export async function collectCommunityResearch(jobId: string, userId: string, waitSecs = 0) {
  const { job, google, queries } = await loadJob(jobId, userId);
  const { data: usage } = await supabaseAdmin.from("external_api_usage").select("id, provider_run_id, status")
    .eq("research_query_id", job.id).eq("endpoint", MULTI_ENDPOINT).eq("cache_hit", false).maybeSingle();
  if (!usage?.provider_run_id) return { collected: false, reason: "no run started" };
  const runId = usage.provider_run_id;

  const { data: existing } = await supabaseAdmin.from("research_data").select("id").eq("research_query_id", job.id)
    .eq("data_type", COMMUNITY_MULTI_DATA_TYPE).eq("source_query", runId).maybeSingle();
  if (existing) { await reconcileApifyUsage({ userId }); return { collected: true, research_data_id: existing.id, already: true }; }

  const run = await readRedditRun(runId, waitSecs);
  if (!run || !(TERMINAL_RUN_STATUSES as readonly string[]).includes(run.status ?? "")) return { collected: false, reason: `run ${run?.status ?? "unreadable"}` };
  const items = run.defaultDatasetId ? await readRedditDataset(run.defaultDatasetId) : null;
  if (!items) return { collected: false, reason: "dataset unavailable" };

  const now = new Date();
  const out = processMultiQueryDataset({ niche: job.query, google, queries, items, as_of: now.toISOString() });
  const succeeded = run.status === "SUCCEEDED";
  const expires = new Date(now.getTime() + COMMUNITY_MULTI_CONFIG.cache_days * 86400000);
  const { data: row, error } = await supabaseAdmin.from("research_data").insert({
    research_query_id: job.id, provider: "apify", data_type: COMMUNITY_MULTI_DATA_TYPE,
    source_query: runId, normalized_query: multiCacheKey(queries), target_country: job.target_country, language: job.language,
    raw_data: { run_id: runId, run_status: run.status, actor: APIFY_REDDIT_ACTOR, version: COMMUNITY_MULTI_VERSION, input: buildActorInput(queries), raw: out.raw } as never,
    processed_data: { per_query: out.per_query, discussions: out.discussions, comments: out.comments, analysis: { ...out.analysis, posts: undefined, comments: undefined, post_analysis: out.analysis.posts } } as never,
    collected_at: now.toISOString(), expires_at: succeeded && items.length ? expires.toISOString() : now.toISOString(),
  }).select("id").single();
  if (error) throw error;
  await supabaseAdmin.from("external_api_usage").update({ status: succeeded ? "success" : items.length ? "partial" : "error" }).eq("id", usage.id);
  await reconcileApifyUsage({ userId });
  return { collected: true, research_data_id: row.id, run_status: run.status };
}
