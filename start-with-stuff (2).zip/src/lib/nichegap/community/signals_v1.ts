// community_signals_v1 — deterministic community relevance, problem-language signals, recency and
// evidence quality. Pure and config-driven: no network, no AI/embeddings. Indicators only — signals
// do not represent understood or ranked pain points. Does not feed score_v1_1.
import { clusterKeywords, tokens } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";
import type { NormalizedComment, NormalizedDiscussion } from "./provider";

export const COMMUNITY_SIGNALS_VERSION = "community_signals_v1";

export const COMMUNITY_SIGNALS_V1_CONFIG = {
  relevance: {
    // weights sum to 100
    weights: { niche_overlap: 35, keyword_group_overlap: 25, title_match: 20, body_match: 10, search_query_relation: 10 },
    top_keyword_groups: 10,
    bands: { high: 80, usable: 60, weak: 40 }, // < weak => excluded
  },
  // Patterns are matched on normalized text (lowercase, apostrophes removed, punctuation -> space).
  signals: {
    difficulty: ["hard", "difficult", "struggle", "struggles", "struggled", "struggling", "cant", "cannot", "problem", "problems", "issue", "issues"],
    frustration: ["frustrated", "frustrating", "annoying", "hate", "disappointed", "doesnt work", "dont work", "didnt work", "waste"],
    help_seeking: ["help", "how do i", "how can i", "recommend", "advice", "suggestions", "suggestion"],
    replacement: ["alternative", "alternatives", "instead of", "replacement", "better than"],
    purchase: ["worth it", "buy", "buying", "bought", "recommend", "price", "expensive", "cheap"],
  },
  recency_buckets: [
    { id: "d0_30", max_days: 30 },
    { id: "d31_90", max_days: 90 },
    { id: "d91_365", max_days: 365 },
    { id: "d365_plus", max_days: Infinity },
  ],
  quality: {
    weights: { volume: 30, relevance_rate: 15, recency: 15, diversity: 10, uniqueness: 10, text: 10, engagement: 10 },
    full_volume_at: 30,
    diversity_full_at_platforms: 3, // 1 platform => 0 credit
    tiers: { insufficient_below: 5, low_below: 15, medium_below: 30, high_min_score: 70, medium_min_score: 45 },
    usable_text_min_chars: 20,
  },
} as const;

const C = COMMUNITY_SIGNALS_V1_CONFIG;
export type SignalKey = keyof typeof C.signals;
export const SIGNAL_KEYS = Object.keys(C.signals) as SignalKey[];
export type RelevanceBand = "high" | "usable" | "weak" | "excluded";
export type RecencyBucket = (typeof C.recency_buckets)[number]["id"] | "unknown";

const r2 = (n: number) => Math.round(n * 100) / 100;
const share = (needles: string[], hay: Set<string>) => (needles.length ? needles.filter((n) => hay.has(n)).length / needles.length : 0);

/** Lowercase, unify/strip apostrophes (can't/cant, doesn’t/doesnt), punctuation -> spaces. */
export function normalizeSignalText(text: string | null | undefined): string {
  if (!text) return "";
  return ` ${text.toLowerCase().replace(/[\u2018\u2019\u02bc`']/g, "").replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim()} `;
}

export function detectSignals(text: string | null | undefined) {
  const t = normalizeSignalText(text);
  const counts = {} as Record<SignalKey, number>;
  const matched = {} as Record<SignalKey, string[]>;
  for (const k of SIGNAL_KEYS) {
    counts[k] = 0; matched[k] = [];
    for (const p of C.signals[k]) {
      const n = t.split(` ${p} `).length - 1;
      if (n > 0) { counts[k] += n; matched[k].push(p); }
    }
  }
  const flags = Object.fromEntries(SIGNAL_KEYS.map((k) => [k, counts[k] > 0])) as Record<SignalKey, boolean>;
  return { flags, counts, matched, any: SIGNAL_KEYS.some((k) => flags[k]) };
}

export function relevanceBand(score: number): RelevanceBand {
  const b = C.relevance.bands;
  return score >= b.high ? "high" : score >= b.usable ? "usable" : score >= b.weak ? "weak" : "excluded";
}

export function recencyBucket(createdAt: string | null, asOf: Date): RecencyBucket {
  if (!createdAt) return "unknown";
  const t = new Date(createdAt).getTime();
  if (Number.isNaN(t)) return "unknown";
  const days = Math.max(0, (asOf.getTime() - t) / 86400000);
  return C.recency_buckets.find((b) => days <= b.max_days)!.id;
}

export interface RelevanceContext { nicheTokens: string[]; groupTokens: string[][] }
export function buildRelevanceContext(niche: string, google: GoogleKeyword[] | null): RelevanceContext {
  const groups = google ? clusterKeywords(google).slice(0, C.relevance.top_keyword_groups).map((c) => c.tokens) : [];
  return { nicheTokens: tokens(niche), groupTokens: groups };
}

export function postRelevance(p: Pick<NormalizedDiscussion, "title" | "body" | "search_query">, ctx: RelevanceContext) {
  const W = C.relevance.weights;
  const title = new Set(tokens(p.title ?? ""));
  const body = new Set(tokens(p.body ?? ""));
  const all = new Set([...title, ...body]);
  const query = tokens(p.search_query ?? "");
  const groupBest = ctx.groupTokens.length ? Math.max(...ctx.groupTokens.map((g) => share(g, all))) : null;
  // When no keyword groups exist, the weight is redistributed to niche overlap (no free credit).
  const parts = {
    niche_overlap: share(ctx.nicheTokens, all) * (W.niche_overlap + (groupBest === null ? W.keyword_group_overlap : 0)),
    keyword_group_overlap: groupBest === null ? 0 : groupBest * W.keyword_group_overlap,
    title_match: share(ctx.nicheTokens, title) * W.title_match,
    body_match: share(ctx.nicheTokens, body) * W.body_match,
    search_query_relation: share(query, all) * W.search_query_relation,
  };
  const score = r2(Object.values(parts).reduce((a, b) => a + b, 0));
  return { score, band: relevanceBand(score), components: Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, r2(v)])), keyword_groups_available: groupBest !== null };
}

const median = (xs: number[]) => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b); const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : r2((s[m - 1]! + s[m]!) / 2);
};

export interface CommunityAnalysisInput {
  niche: string;
  google: GoogleKeyword[] | null;
  discussions: NormalizedDiscussion[];
  comments: NormalizedComment[];
  as_of: string; // reference date for recency (deterministic)
}

export function analyzeCommunity(input: CommunityAnalysisInput) {
  const ctx = buildRelevanceContext(input.niche, input.google);
  const asOf = new Date(input.as_of);
  const Q = C.quality;

  // Duplicates: same platform+id, or identical normalized title+body text.
  const seenId = new Set<string>(), seenText = new Set<string>();
  const unique: NormalizedDiscussion[] = [];
  for (const d of input.discussions) {
    const idKey = `${d.source_platform}:${d.discussion_id}`;
    const textKey = `${d.source_platform}|${normalizeSignalText(d.title)}|${normalizeSignalText(d.body)}`;
    if (seenId.has(idKey) || (normalizeSignalText(d.title).trim() && seenText.has(textKey))) continue;
    seenId.add(idKey); seenText.add(textKey); unique.push(d);
  }

  const posts = unique.map((d) => {
    const rel = postRelevance(d, ctx);
    const sig = detectSignals(`${d.title ?? ""}\n${d.body ?? ""}`);
    return { discussion_id: d.discussion_id, platform: d.source_platform, community: d.community, url: d.discussion_url, title: d.title,
      relevance: rel, signals: sig, recency: recencyBucket(d.created_at, asOf), score: d.score, comment_count: d.comment_count,
      has_usable_text: `${d.title ?? ""} ${d.body ?? ""}`.trim().length >= Q.usable_text_min_chars,
      authoritative: rel.band !== "excluded" };
  });
  const byId = new Map(posts.map((p) => [`${p.platform}:${p.discussion_id}`, p]));

  const seenC = new Set<string>();
  const comments = input.comments.filter((c) => { const k = `${c.source_platform}:${c.comment_id}`; if (seenC.has(k)) return false; seenC.add(k); return true; })
    .map((c) => {
      const parent = c.discussion_id ? byId.get(`${c.source_platform}:${c.discussion_id}`) : undefined;
      return { comment_id: c.comment_id, discussion_id: c.discussion_id, platform: c.source_platform,
        parent_relevance_score: parent ? parent.relevance.score : null,
        relevant: parent ? parent.authoritative : null, // null = not determinable (parent unknown)
        signals: detectSignals(c.text) };
    });

  const rel = posts.filter((p) => p.authoritative);
  const relComments = comments.filter((c) => c.relevant === true);
  const signalItems = [...rel.map((p) => p.signals), ...relComments.map((c) => c.signals)];
  const signal_counts = Object.fromEntries(SIGNAL_KEYS.map((k) => [k, signalItems.filter((s) => s.flags[k]).length])) as Record<SignalKey, number>;
  // A discussion shows problem language if its post or any relevant comment matches difficulty/frustration/help/replacement.
  const problemKeys: SignalKey[] = ["difficulty", "frustration", "help_seeking", "replacement"];
  const problemDiscussions = rel.filter((p) => problemKeys.some((k) => p.signals.flags[k]) ||
    relComments.some((c) => c.discussion_id === p.discussion_id && problemKeys.some((k) => c.signals.flags[k]))).length;

  const recency = Object.fromEntries([...C.recency_buckets.map((b) => b.id), "unknown"].map((id) => [id, rel.filter((p) => p.recency === id).length])) as Record<RecencyBucket, number>;

  // Engagement medians are kept per platform; never combined across platforms.
  const platforms = [...new Set(posts.map((p) => p.platform))].sort();
  const engagement_by_platform = Object.fromEntries(platforms.map((pl) => {
    const ps = rel.filter((p) => p.platform === pl);
    const sc = ps.map((p) => p.score).filter((v): v is number => typeof v === "number");
    const cc = ps.map((p) => p.comment_count).filter((v): v is number => typeof v === "number");
    return [pl, { median_post_score: median(sc), posts_with_score: sc.length, median_comment_count: median(cc), posts_with_comment_count: cc.length }];
  }));

  const total = input.discussions.length;
  const relevance_rate = unique.length ? r2(rel.length / unique.length) : null;
  const duplicate_rate = total ? r2((total - unique.length) / total) : 0;
  const knownRecent = rel.filter((p) => p.recency !== "unknown" && p.recency !== "d365_plus").length;
  const recency_coverage = rel.length ? knownRecent / rel.length : 0;
  const text_rate = rel.length ? rel.filter((p) => p.has_usable_text).length / rel.length : 0;
  const engagement_rate = rel.length ? rel.filter((p) => typeof p.score === "number" || typeof p.comment_count === "number").length / rel.length : 0;
  const relPlatforms = new Set(rel.map((p) => p.platform)).size;
  const diversity = relPlatforms <= 1 ? 0 : Math.min(1, (relPlatforms - 1) / (Q.diversity_full_at_platforms - 1));

  const parts = {
    volume: Math.min(1, rel.length / Q.full_volume_at) * Q.weights.volume,
    relevance_rate: (relevance_rate ?? 0) * Q.weights.relevance_rate,
    recency: recency_coverage * Q.weights.recency,
    diversity: diversity * Q.weights.diversity,
    uniqueness: (1 - duplicate_rate) * Q.weights.uniqueness,
    text: text_rate * Q.weights.text,
    engagement: engagement_rate * Q.weights.engagement,
  };
  const quality_score = rel.length ? r2(Object.values(parts).reduce((a, b) => a + b, 0)) : 0;
  const T = Q.tiers;
  let confidence: "high" | "medium" | "low" | "insufficient";
  if (rel.length < T.insufficient_below) confidence = "insufficient";
  else if (rel.length < T.low_below) confidence = "low";
  else if (rel.length < T.medium_below) confidence = quality_score >= T.medium_min_score ? "medium" : "low";
  else confidence = quality_score >= T.high_min_score ? "high" : quality_score >= T.medium_min_score ? "medium" : "low";

  return {
    version: COMMUNITY_SIGNALS_VERSION,
    as_of: input.as_of,
    keyword_groups_used: ctx.groupTokens.length,
    metrics: {
      total_discussions: total,
      unique_discussions: unique.length,
      relevant_discussions: rel.length,
      relevance_rate,
      relevance_bands: { high: posts.filter((p) => p.relevance.band === "high").length, usable: posts.filter((p) => p.relevance.band === "usable").length, weak: posts.filter((p) => p.relevance.band === "weak").length, excluded: posts.filter((p) => p.relevance.band === "excluded").length },
      total_comments: comments.length,
      relevant_comments: relComments.length,
      comments_relevance_undeterminable: comments.filter((c) => c.relevant === null).length,
      problem_language_discussions: problemDiscussions,
      problem_language_ratio: rel.length ? r2(problemDiscussions / rel.length) : null,
      signal_counts, // number of relevant posts/comments containing each signal
      recency,
      engagement_by_platform,
      duplicate_rate,
    },
    evidence_quality: { score: quality_score, confidence, components: Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, r2(v)])), platforms: relPlatforms },
    posts, comments,
    note: "Signals are deterministic keyword indicators only; they are not understood or ranked pain points.",
  };
}
