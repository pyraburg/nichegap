import { describe, expect, it } from "vitest";
import { normalizeRedditItems, redactRaw } from "./reddit-apify.normalize";

const post = { kind: "post", id: "p1", query: "indoor herb gardening", title: "My basil keeps dying", body: "<p>Help &amp; advice?</p>", author: "someone", author_fullname: "t2_x", flair: "Help", score: 12, num_comments: 4, subreddit: "IndoorGarden", created_utc: "2026-05-01T10:00:00.000Z", url: "https://www.reddit.com/r/IndoorGarden/comments/p1/x/" };
const comment = { kind: "comment", id: "c1", postId: "p1", parentId: "t3_p1", body: "Too little light.", author: "other", score: 3, created_utc: "2026-05-02T10:00:00.000Z", permalink: "/r/IndoorGarden/comments/p1/x/c1/" };

describe("apify reddit normalization", () => {
  it("normalizes posts and comments without identity fields", () => {
    const r = normalizeRedditItems([post, comment]);
    expect(r.discussions).toHaveLength(1);
    expect(r.comments).toHaveLength(1);
    expect(r.discussions[0]!.body).toBe("Help & advice?");
    expect(JSON.stringify(r)).not.toMatch(/someone|t2_x|author/);
    expect(r.comments[0]!.comment_url).toBe("https://www.reddit.com/r/IndoorGarden/comments/p1/x/c1/");
  });
  it("dedupes on kind:id", () => {
    expect(normalizeRedditItems([post, post, comment]).discussions).toHaveLength(1);
  });
  it("keeps missing values as null, not zero", () => {
    const r = normalizeRedditItems([{ kind: "post", id: "p2", title: "x" }]);
    expect(r.discussions[0]!.score).toBeNull();
    expect(r.discussions[0]!.comment_count).toBeNull();
    expect(r.discussions[0]!.created_at).toBeNull();
  });
  it("redacts identity fields from raw", () => {
    expect(Object.keys(redactRaw(post))).not.toContain("author");
    expect(Object.keys(redactRaw(post))).not.toContain("flair");
  });
});
