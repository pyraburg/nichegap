// Community evidence provider abstraction (Phase 4A). Pure types + helpers; no network code here.
// Provider implementations live in *.server.ts files and must only return these normalized shapes.

export interface CommunitySearchOptions {
  query: string;
  sort: "relevance" | "hot" | "top" | "new" | "comments";
  timeframe: "all" | "year" | "month" | "week" | "day" | "hour";
  scrapeComments: boolean;
  maxPosts: number;
  maxComments: number;
}

export interface NormalizedDiscussion {
  source_platform: string; // e.g. "reddit"
  source_type: "post";
  discussion_id: string;
  discussion_url: string | null;
  community: string | null; // e.g. subreddit
  title: string | null;
  body: string | null;
  created_at: string | null;
  score: number | null;
  upvote_ratio: number | null;
  comment_count: number | null;
  is_deleted_or_removed: boolean | null;
  search_query: string | null;
}

export interface NormalizedComment {
  source_platform: string;
  source_type: "comment";
  comment_id: string;
  discussion_id: string | null;
  parent_id: string | null;
  comment_url: string | null;
  community: string | null;
  text: string | null;
  created_at: string | null;
  score: number | null;
  depth: number | null;
  is_deleted_or_removed: boolean | null;
  search_query: string | null;
}

export interface CommunitySearchResult {
  ok: boolean;
  partial: boolean; // true when the run did not finish cleanly but some items were retrieved
  error: string | null;
  provider: string; // e.g. "apify"
  operation: string; // e.g. actor id
  run_id: string | null;
  run_status: string | null;
  cost_usd: number | null; // actual provider-reported usage, null if not reported
  discussions: NormalizedDiscussion[];
  comments: NormalizedComment[];
  skipped_items: number;
  raw_item_count: number;
}

export interface CommunityProvider {
  readonly id: string;
  readonly platform: string;
  searchDiscussions(opts: CommunitySearchOptions): Promise<CommunitySearchResult>;
  normalizeDiscussion(raw: Record<string, unknown>): NormalizedDiscussion | null;
  normalizeComment(raw: Record<string, unknown>): NormalizedComment | null;
}

// ---------- shared deterministic helpers ----------
export const str = (v: unknown): string | null => (typeof v === "string" && v.trim() ? v : null);
export const num = (v: unknown): number | null => (typeof v === "number" && Number.isFinite(v) ? v : null);
export const bool = (v: unknown): boolean | null => (typeof v === "boolean" ? v : null);

/** Deterministic text cleaning: strips HTML/markup noise, keeps the author's words unchanged. */
export function cleanText(v: unknown): string | null {
  const s = str(v);
  if (!s) return null;
  const out = s
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ")
    .replace(/[?&](utm_[a-z]+|fbclid|gclid)=[^\s&)]+/gi, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!out || out === "[deleted]" || out === "[removed]") return null;
  return out;
}

/** ISO timestamp or null. Accepts ISO strings and unix seconds. */
export function isoDate(v: unknown): string | null {
  if (typeof v === "number" && Number.isFinite(v)) return new Date(v * 1000).toISOString();
  const s = str(v);
  if (!s) return null;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}
