import { describe, expect, it } from "vitest";
import { analyzeCommunity, detectSignals, postRelevance, buildRelevanceContext, recencyBucket } from "./signals_v1";
import { scoreV1_1 } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";
import type { NormalizedComment, NormalizedDiscussion } from "./provider";

const NICHE = "indoor herb gardening";
const AS_OF = "2026-10-01T00:00:00.000Z";
const kw = (keyword: string, v: number): GoogleKeyword => ({ keyword, search_volume: v, cpc: 1, competition: "HIGH", competition_index: 50, monthly_searches: null });
const google = [kw("indoor herb garden", 5000), kw("indoor herb garden kit", 2000), kw("herb grow light", 900)];
const post = (id: string, o: Partial<NormalizedDiscussion> = {}): NormalizedDiscussion => ({
  source_platform: "reddit", source_type: "post", discussion_id: id, discussion_url: null, community: "IndoorGarden",
  title: "Indoor herb garden tips", body: "My indoor herbs keep wilting in the garden", created_at: "2026-09-20T00:00:00.000Z",
  score: 10, upvote_ratio: null, comment_count: 3, is_deleted_or_removed: false, search_query: NICHE, ...o,
});
const comment = (id: string, pid: string, text: string): NormalizedComment => ({
  source_platform: "reddit", source_type: "comment", comment_id: id, discussion_id: pid, parent_id: null, comment_url: null,
  community: null, text, created_at: null, score: null, depth: null, is_deleted_or_removed: null, search_query: NICHE,
});
const ctx = buildRelevanceContext(NICHE, google);
const many = (n: number, o: Partial<NormalizedDiscussion> = {}) => Array.from({ length: n }, (_, i) => post(`p${i}`, { title: `Indoor herb garden question ${i}`, ...o }));

describe("community_signals_v1", () => {
  it("highly relevant discussion scores high", () => {
    expect(postRelevance(post("a"), ctx).band).toBe("high");
  });
  it("irrelevant discussion is excluded from authoritative metrics", () => {
    const off = post("b", { title: "Best gaming laptop 2026", body: "Need a GPU for streaming", search_query: NICHE });
    expect(postRelevance(off, ctx).band).toBe("excluded");
    const r = analyzeCommunity({ niche: NICHE, google, discussions: [post("a"), off], comments: [], as_of: AS_OF });
    expect(r.metrics.relevant_discussions).toBe(1);
    expect(r.posts).toHaveLength(2); // still stored for audit
  });
  it("handles duplicates by id and identical text", () => {
    const r = analyzeCommunity({ niche: NICHE, google, discussions: [post("a"), post("a"), post("c")], comments: [], as_of: AS_OF });
    expect(r.metrics.total_discussions).toBe(3);
    expect(r.metrics.unique_discussions).toBe(1);
    expect(r.metrics.duplicate_rate).toBeCloseTo(0.67, 2);
  });
  it("detects difficulty", () => expect(detectSignals("This is so hard to keep alive").flags.difficulty).toBe(true));
  it("detects frustration", () => expect(detectSignals("The kit doesn't work, total waste").counts.frustration).toBe(2));
  it("detects help-seeking", () => expect(detectSignals("How do I stop basil bolting? Any advice?").counts.help_seeking).toBe(2));
  it("detects replacement", () => expect(detectSignals("Looking for an alternative instead of AeroGarden").counts.replacement).toBe(2));
  it("detects purchase", () => expect(detectSignals("Is it worth it at that price?").counts.purchase).toBe(2));
  it("handles apostrophe variants", () => {
    for (const t of ["I can't", "I cant", "I can’t", "it doesn’t work", "it doesnt work"]) expect(detectSignals(t).any).toBe(true);
    expect(detectSignals("canteen").flags.difficulty).toBe(false);
  });
  it("classifies recency buckets and unknown", () => {
    const d = new Date(AS_OF);
    expect(recencyBucket("2026-09-15T00:00:00Z", d)).toBe("d0_30");
    expect(recencyBucket("2026-08-01T00:00:00Z", d)).toBe("d31_90");
    expect(recencyBucket("2026-01-01T00:00:00Z", d)).toBe("d91_365");
    expect(recencyBucket("2024-01-01T00:00:00Z", d)).toBe("d365_plus");
    expect(recencyBucket(null, d)).toBe("unknown");
  });
  it("missing engagement stays unknown", () => {
    const r = analyzeCommunity({ niche: NICHE, google, discussions: [post("a", { score: null, comment_count: null })], comments: [], as_of: AS_OF });
    expect(r.metrics.engagement_by_platform["reddit"]!.median_post_score).toBeNull();
    expect(r.metrics.engagement_by_platform["reddit"]!.median_comment_count).toBeNull();
  });
  it("comments inherit parent relevance but keep own signals", () => {
    const r = analyzeCommunity({ niche: NICHE, google, discussions: [post("a")], comments: [comment("c1", "a", "I'm so frustrated"), comment("c2", "zz", "help")], as_of: AS_OF });
    expect(r.metrics.relevant_comments).toBe(1);
    expect(r.metrics.comments_relevance_undeterminable).toBe(1);
    expect(r.metrics.signal_counts.frustration).toBe(1);
  });
  it("fewer than 5 relevant discussions is insufficient", () => {
    expect(analyzeCommunity({ niche: NICHE, google, discussions: many(4), comments: [], as_of: AS_OF }).evidence_quality.confidence).toBe("insufficient");
  });
  it("stronger evidence gives higher quality/confidence; single source gets no diversity credit", () => {
    const weak = analyzeCommunity({ niche: NICHE, google, discussions: many(6, { created_at: null, score: null, comment_count: null }), comments: [], as_of: AS_OF });
    const strong = analyzeCommunity({ niche: NICHE, google, discussions: many(35), comments: [], as_of: AS_OF });
    expect(strong.evidence_quality.score).toBeGreaterThan(weak.evidence_quality.score);
    expect(weak.evidence_quality.confidence).toBe("low");
    expect(strong.evidence_quality.confidence).toBe("high");
    expect(strong.evidence_quality.components["diversity"]).toBe(0);
  });
  it("is deterministic", () => {
    const i = { niche: NICHE, google, discussions: many(8), comments: [], as_of: AS_OF };
    expect(JSON.stringify(analyzeCommunity(i))).toBe(JSON.stringify(analyzeCommunity(i)));
  });
  it("regression: score_v1_1 output is unchanged", () => {
    const g = [kw("indoor herb garden", 5000), kw("indoor herb garden kit", 2000)];
    const amazon = [{ keyword: "indoor herb garden kit", results_count: 2000, categories: null, products: Array.from({ length: 20 }, (_, i) => ({ title: `Indoor Herb Garden Kit ${i}`, result_type: "amazon_serp", bought_past_month: 200, rating: 4.1, review_count: 40, is_amazon_choice: false, is_best_seller: false })) }];
    const r = scoreV1_1({ niche: "indoor herb garden", google: g, amazon: amazon as never });
    expect({ score: r.opportunity_score, cls: r.classification, conf: r.confidence }).toMatchInlineSnapshot(`
      {
        "cls": "Promising Opportunity",
        "conf": "medium",
        "score": 65.5359,
      }
    `);
  });
});
