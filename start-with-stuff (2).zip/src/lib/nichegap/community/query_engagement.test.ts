import { describe, expect, it } from "vitest";
import { normalizeRedditItems, normalizeRedditPost, normalizeRedditComment } from "./reddit-apify.normalize";
import { generateCommunityQueries, queryKey } from "./query_gen_v1";
import { scoreV1_1 } from "../scoring/score_v1_1";
import type { GoogleKeyword } from "../scoring/score_v1";

const P = (o: Record<string, unknown>) => ({ kind: "post", id: "p1", title: "t", ...o });
const Cm = (o: Record<string, unknown>) => ({ kind: "comment", id: "c1", postId: "p1", body: "x", ...o });

describe("engagement integrity", () => {
  it("genuine post zero stays 0", () => {
    const d = normalizeRedditPost(P({ score: 0, upvote_ratio: 0.5, num_comments: 0, body_html: "<div>hi</div>" }))!;
    expect([d.score, d.upvote_ratio, d.comment_count]).toEqual([0, 0.5, 0]);
  });
  it("missing post engagement stays null", () => {
    const d = normalizeRedditPost(P({}))!;
    expect([d.score, d.upvote_ratio, d.comment_count]).toEqual([null, null, null]);
  });
  it("positive post engagement is preserved", () => {
    const d = normalizeRedditPost(P({ score: 154, upvote_ratio: 0.97, num_comments: 42 }))!;
    expect([d.score, d.upvote_ratio, d.comment_count]).toEqual([154, 0.97, 42]);
  });
  it("feed-format placeholder zeros become null", () => {
    const html = "<div>x</div> &#32; submitted by &#32; <a>/u/x</a> <span><a>[link]</a></span> &#32; <span><a>[comments]</a></span>";
    const d = normalizeRedditPost(P({ score: 0, upvote_ratio: 0, num_comments: 0, body_html: html }))!;
    expect([d.score, d.upvote_ratio, d.comment_count]).toEqual([null, null, null]);
    expect(normalizeRedditPost(P({ score: 0, upvote_ratio: 0, num_comments: 3 }))!.score).toBeNull();
  });
  it("comment engagement: positive, genuine zero, placeholder zero, missing", () => {
    expect(normalizeRedditComment(Cm({ score: 17 }))!.score).toBe(17);
    expect(normalizeRedditComment(Cm({ score: 0, controversiality: 0, score_hidden: false }))!.score).toBe(0);
    expect(normalizeRedditComment(Cm({ score: 0, controversiality: null, score_hidden: null }))!.score).toBeNull();
    expect(normalizeRedditComment(Cm({}))!.score).toBeNull();
  });
  it("0 comments contradicted by comments in the dataset becomes null", () => {
    const r = normalizeRedditItems([P({ score: 5, upvote_ratio: 0.9, num_comments: 0 }), Cm({ score: 2 })]);
    expect(r.discussions[0]!.comment_count).toBeNull();
    expect(r.discussions[0]!.score).toBe(5);
  });
});

const kw = (keyword: string, v: number): GoogleKeyword => ({ keyword, search_volume: v, cpc: 1, competition: "HIGH", competition_index: 50, monthly_searches: null });
const google = [kw("basil grow light", 14800), kw("herb garden for inside", 9900), kw("indoor herb garden", 9900), kw("grow lamp for herbs", 5400), kw("grow herbs at home indoors", 3600), kw("raising herbs indoors", 3600), kw("kitchen herb garden", 1600)];
const NICHE = "indoor herb gardening";

describe("community_query_gen_v1", () => {
  const out = generateCommunityQueries({ niche: NICHE, google });
  it("is deterministic and same evidence => same queries", () => {
    expect(JSON.stringify(generateCommunityQueries({ niche: NICHE, google }))).toBe(JSON.stringify(out));
    expect(JSON.stringify(generateCommunityQueries({ niche: NICHE, google: [...google].reverse() }).queries)).toBe(JSON.stringify(out.queries));
  });
  it("returns at most 8 queries with source/reason/intent", () => {
    expect(out.queries.length).toBeLessThanOrEqual(8);
    expect(out.queries.length).toBe(8);
    for (const q of out.queries) expect(q.query && q.source_keyword && q.reason && q.intent).toBeTruthy();
  });
  it("has no token-equivalent duplicates", () => {
    const keys = out.queries.map((q) => queryKey(q.query));
    expect(new Set(keys).size).toBe(keys.length);
    expect(queryKey("indoor herb gardening problems")).toBe(queryKey("problems indoor herbs garden"));
  });
  it("drops duplicate / non-independent seeds", () => {
    expect(out.seeds.map((s) => s.text)).not.toContain("herb garden for inside"); // same tokens as niche
    expect(out.seeds.map((s) => s.text)).not.toContain("basil grow light"); // no niche tokens
  });
  it("covers diverse intents", () => {
    const intents = new Set(out.queries.map((q) => q.intent));
    for (const i of ["difficulty_problem", "help_seeking", "alternatives_recommendation", "purchase_validation"]) expect(intents.has(i as never)).toBe(true);
  });
  it("works with no Google evidence (niche only)", () => {
    const r = generateCommunityQueries({ niche: NICHE, google: null });
    expect(r.queries.length).toBeGreaterThan(0);
    expect(r.queries.every((q) => q.source_type === "niche")).toBe(true);
  });
  it("Opportunity Score remains exactly unchanged", () => {
    const amazon = [{ keyword: "indoor herb garden kit", results_count: 2000, categories: null, products: Array.from({ length: 20 }, (_, i) => ({ title: `Indoor Herb Garden Kit ${i}`, result_type: "amazon_serp", bought_past_month: 200, rating: 4.1, review_count: 40, is_amazon_choice: false, is_best_seller: false })) }];
    const a = scoreV1_1({ niche: "indoor herb garden", google: google, amazon: amazon as never });
    generateCommunityQueries({ niche: NICHE, google });
    expect(scoreV1_1({ niche: "indoor herb garden", google: google, amazon: amazon as never })).toEqual(a);
  });
});
