// Pure Apify cost-integrity rules (Phase 4A.4). No network code.
// Authoritative charge = completed run's `usageTotalUsd`, read only once the run is terminal AND Apify has
// finished accounting its pay-per-event charges (accountedChargedEventCounts == chargedEventCounts) AND a
// settle window after finishedAt has passed. Anything earlier is intermediate and stays `pending`.
// Costs are never calculated from result counts.

export const APIFY_COST_CONFIG = {
  settle_ms: 120_000, // minimum time after finishedAt before a cost may be finalized
  max_reconcile_attempts: 20, // after this, a still-unavailable cost becomes `unknown`
  cost_source: "apify.actor-run.usageTotalUsd",
} as const;

export const TERMINAL_RUN_STATUSES = ["SUCCEEDED", "FAILED", "ABORTED", "TIMED-OUT"] as const;

export interface ApifyRunMeta {
  id?: string;
  status?: string;
  finishedAt?: string | null;
  usageTotalUsd?: number | null;
  chargedEventCounts?: Record<string, number> | null;
  accountedChargedEventCounts?: Record<string, number> | null;
}

export type CostStatus = "final" | "pending" | "unknown";
export interface CostEvaluation { cost_status: CostStatus; cost: number | null; intermediate_cost: number | null; cost_source: string | null; reason: string }

const sameCounts = (a?: Record<string, number> | null, b?: Record<string, number> | null) => {
  if (!a && !b) return true;
  if (!a || !b) return false;
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  return [...keys].every((k) => (a[k] ?? 0) === (b[k] ?? 0));
};

export function evaluateRunCost(run: ApifyRunMeta, now: Date, attempts = 0): CostEvaluation {
  const usage = typeof run.usageTotalUsd === "number" && Number.isFinite(run.usageTotalUsd) ? run.usageTotalUsd : null;
  const pending = (reason: string): CostEvaluation =>
    attempts >= APIFY_COST_CONFIG.max_reconcile_attempts
      ? { cost_status: "unknown", cost: null, intermediate_cost: usage, cost_source: null, reason: `${reason}; gave up after ${attempts} reconcile attempts` }
      : { cost_status: "pending", cost: null, intermediate_cost: usage, cost_source: null, reason };
  if (!run.status || !(TERMINAL_RUN_STATUSES as readonly string[]).includes(run.status)) return pending(`run not terminal (${run.status ?? "unknown"})`);
  if (!run.finishedAt) return pending("run has no finishedAt");
  if (now.getTime() - new Date(run.finishedAt).getTime() < APIFY_COST_CONFIG.settle_ms) return pending("within settle window after finish");
  if (!sameCounts(run.chargedEventCounts, run.accountedChargedEventCounts)) return pending("charged events not fully accounted yet");
  if (usage === null) {
    return attempts >= APIFY_COST_CONFIG.max_reconcile_attempts
      ? { cost_status: "unknown", cost: null, intermediate_cost: null, cost_source: null, reason: "provider reported no usageTotalUsd" }
      : { cost_status: "pending", cost: null, intermediate_cost: null, cost_source: null, reason: "provider reported no usageTotalUsd yet" };
  }
  return { cost_status: "final", cost: usage, intermediate_cost: null, cost_source: APIFY_COST_CONFIG.cost_source, reason: `final ${run.status} run usage` };
}

export interface UsageRow { id: string; cost: number | null; cost_status: CostStatus; intermediate_cost: number | null; reconcile_attempts: number; cache_hit: boolean }

/** Idempotent reconciliation: returns the update to apply, or null when nothing should change. */
export function planReconciliation(row: UsageRow, run: ApifyRunMeta, now: Date) {
  if (row.cache_hit || row.cost_status === "final") return null; // cache hits stay $0; final is never rewritten
  const ev = evaluateRunCost(run, now, row.reconcile_attempts + 1);
  return {
    cost: ev.cost_status === "final" ? ev.cost : null,
    cost_status: ev.cost_status,
    cost_source: ev.cost_source,
    intermediate_cost: ev.intermediate_cost ?? row.intermediate_cost,
    cost_finalized_at: ev.cost_status === "final" ? now.toISOString() : null,
    reconcile_attempts: row.reconcile_attempts + 1,
    reason: ev.reason,
  };
}

// ---------- community research cost ceiling ----------
export const COMMUNITY_COST_DEFAULTS = { ceiling_usd: 1.0, pending_run_risk_usd: 0.25, max_pending_runs: 2 } as const;

export function communityCostConfig(env: Record<string, string | undefined>) {
  const n = (v: string | undefined, d: number) => { const x = v === undefined ? NaN : Number(v); return Number.isFinite(x) && x >= 0 ? x : d; };
  return {
    ceiling_usd: n(env["COMMUNITY_COST_CEILING_USD"], COMMUNITY_COST_DEFAULTS.ceiling_usd),
    pending_run_risk_usd: n(env["COMMUNITY_PENDING_RUN_RISK_USD"], COMMUNITY_COST_DEFAULTS.pending_run_risk_usd),
    max_pending_runs: n(env["COMMUNITY_MAX_PENDING_RUNS"], COMMUNITY_COST_DEFAULTS.max_pending_runs),
  };
}

/** Whether another paid provider call may start. Pending/unknown runs count at max(intermediate, risk allowance). */
export function canStartProviderCall(usage: Array<Pick<UsageRow, "cost" | "cost_status" | "intermediate_cost" | "cache_hit">>, cfg: ReturnType<typeof communityCostConfig>) {
  const paid = usage.filter((u) => !u.cache_hit);
  const final = paid.filter((u) => u.cost_status === "final").reduce((a, u) => a + (u.cost ?? 0), 0);
  const open = paid.filter((u) => u.cost_status !== "final");
  const risk = open.reduce((a, u) => a + Math.max(u.intermediate_cost ?? 0, cfg.pending_run_risk_usd), 0);
  const committed = Math.round((final + risk) * 1e6) / 1e6;
  if (open.filter((u) => u.cost_status === "pending").length >= cfg.max_pending_runs) return { allowed: false, committed_usd: committed, reason: "too many runs with unfinalized cost" };
  if (committed + cfg.pending_run_risk_usd > cfg.ceiling_usd) return { allowed: false, committed_usd: committed, reason: `cost ceiling $${cfg.ceiling_usd} would be exceeded` };
  return { allowed: true, committed_usd: committed, reason: "within ceiling" };
}
