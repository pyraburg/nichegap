import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const runKeywordResearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ research_query_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    // Ownership check runs as the user (RLS), so other users' jobs are invisible.
    const { data: job } = await context.supabase
      .from("research_queries")
      .select("id, user_id, query, target_country, language, status, stage, billing")
      .eq("id", data.research_query_id)
      .maybeSingle();
    if (!job || job.user_id !== context.userId) throw new Error("Research job not found.");
    // Legacy direct runner: credit-billed jobs must go through the reserved pipeline (admins excepted for /lab tooling).
    if (job.billing === "credit") {
      const { data: isAdmin } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
      if (!isAdmin) throw new Error("Research must be started from the research form.");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { runGoogleStage, runAmazonStage } = await import("./research.server");

    // Atomic claim: only one request can move pending/failed -> processing.
    const { data: claimed } = await supabaseAdmin
      .from("research_queries")
      .update({ status: "processing", started_at: new Date().toISOString(), error_message: null, completed_at: null })
      .eq("id", job.id)
      .in("status", ["pending", "failed"])
      .select("id");
    if (!claimed?.length) return { status: job.status, skipped: true };

    const setStage = (stage: string) =>
      supabaseAdmin.from("research_queries").update({ stage }).eq("id", job.id);
    const finish = (status: "completed" | "failed", error_message: string | null = null) =>
      supabaseAdmin.from("research_queries")
        .update({ status, error_message, completed_at: status === "completed" ? new Date().toISOString() : null })
        .eq("id", job.id);

    try {
      let handoff: { keywords?: import("./dataforseo.server").KeywordEvidence[] } | undefined;
      // Stage 1: Google keyword demand (skipped on retry if already past it).
      if (job.stage === "keyword_demand") {
        await setStage("keyword_demand");
        const g = await runGoogleStage(supabaseAdmin, job, context.userId);
        if (!g.ok) {
          await finish("failed", g.error);
          return { status: "failed", stage: "keyword_demand" };
        }
        handoff = { keywords: g.keywords };
        await setStage("amazon_supply");
      }

      // Stage 2: Amazon marketplace supply.
      const a = await runAmazonStage(supabaseAdmin, job, context.userId, handoff);
      if (!a.ok) {
        await finish("failed", a.error);
        return { status: "failed", stage: "amazon_supply" };
      }

      await setStage("complete");
      await finish("completed");
      try {
        const { scoreResearchJob } = await import("./scoring.server");
        await scoreResearchJob(job.id, job.query);
      } catch (e) {
        console.error("score_v1 failed (research kept)", e);
      }
      return { status: "completed", stage: "complete", selected: a.selected };
    } catch (err) {
      console.error("runKeywordResearch failed", err);
      const msg = err instanceof Error && err.message === "PROVIDER_NOT_CONFIGURED"
        ? "Market data provider is not configured yet."
        : err instanceof Error && err.message === "UNSUPPORTED_MARKET"
          ? "This target market is not supported yet."
          : "Research could not be completed. Please try again later.";
      await finish("failed", msg);
      return { status: "failed" };
    }
  });
