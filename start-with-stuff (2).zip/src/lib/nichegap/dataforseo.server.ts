// Server-only DataForSEO client. Credentials come from backend secrets and
// never leave the server.
export const DFS_ENDPOINT = "/v3/keywords_data/google_ads/keywords_for_keywords/live";

const LOCATION_CODES: Record<string, number> = {
  US: 2840, GB: 2826, CA: 2124, AU: 2036, ZA: 2710, DE: 2276, FR: 2250, ES: 2724,
};

export interface KeywordEvidence {
  keyword: string;
  search_volume: number | null;
  competition: string | null;
  competition_index: number | null;
  cpc: number | null;
  low_top_of_page_bid: number | null;
  high_top_of_page_bid: number | null;
  monthly_searches: Array<{ year: number; month: number; search_volume: number | null }> | null;
}

export function normalizeQuery(q: string) {
  return q.trim().toLowerCase().replace(/\s+/g, " ");
}

type Json = Record<string, unknown>;
const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);

export async function fetchKeywordDemand(query: string, country: string, language: string) {
  const login = process.env["DATAFORSEO_LOGIN"]?.trim();
  const password = process.env["DATAFORSEO_PASSWORD"]?.trim();
  if (!login || !password) throw new Error("PROVIDER_NOT_CONFIGURED");
  const location_code = LOCATION_CODES[country];
  if (!location_code) throw new Error("UNSUPPORTED_MARKET");

  const res = await fetch(`https://api.dataforseo.com${DFS_ENDPOINT}`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${login}:${password}`)}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify([{ keywords: [query], location_code, language_code: language }]),
  });
  const body = (await res.json().catch(() => null)) as Json | null;
  const cost = num(body?.["cost"]);
  const task = (body?.["tasks"] as Json[] | undefined)?.[0];
  if (!res.ok || !body || body["status_code"] !== 20000 || !task || task["status_code"] !== 20000) {
    console.error("DataForSEO error", res.status, body?.["status_message"], task?.["status_message"]);
    return { ok: false as const, cost, raw: body };
  }
  const items = (task["result"] as Json[] | null) ?? [];
  const keywords: KeywordEvidence[] = items.map((it) => ({
    keyword: String(it["keyword"] ?? ""),
    search_volume: num(it["search_volume"]),
    competition: typeof it["competition"] === "string" ? (it["competition"] as string) : null,
    competition_index: num(it["competition_index"]),
    cpc: num(it["cpc"]),
    low_top_of_page_bid: num(it["low_top_of_page_bid"]),
    high_top_of_page_bid: num(it["high_top_of_page_bid"]),
    monthly_searches: Array.isArray(it["monthly_searches"])
      ? (it["monthly_searches"] as Json[]).map((m) => ({
          year: Number(m["year"]), month: Number(m["month"]), search_volume: num(m["search_volume"]),
        }))
      : null,
  }));
  return { ok: true as const, cost, raw: body, keywords };
}
