// Server-only orchestration of the existing engines via pipeline_v1. A DB lease ensures one worker per job;
// every stage first reuses evidence already stored for the job, so resumes never pay twice.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  advancePipeline, initialState, jobStatusFor, normalizeState, PIPELINE_VERSION, resetForRetry,
  type PipelineStage, type PipelineState, type StageResult,
} from "./pipeline/pipeline_v1";
import { COMMUNITY_MULTI_DATA_TYPE } from "./community/multi_query_v1";
import { DEFAULT_SCORE_VERSION } from "./scoring.server";
import type { Job } from "./research.server";

const LEASE_MS = 6 * 60 * 1000;
const AI_STALE_MS = 10 * 60 * 1000; // > AI timeout (3 min) + lease // > AI timeout (3 min) + DataForSEO stages

async function loadJob(jobId: string, userId: string) {
  const { data: job } = await supabaseAdmin.from("research_queries")
    .select("id, user_id, query, target_country, language, status, stage, pipeline_version, pipeline_state, billing").eq("id", jobId).maybeSingle();
  if (!job || job.user_id !== userId) throw new Error("Research job not found.");
  return job;
}

async function acquireLease(jobId: string) {
  const token = crypto.randomUUID();
  const now = new Date();
  const { data } = await supabaseAdmin.from("research_queries")
    .update({ pipeline_lease_until: new Date(now.getTime() + LEASE_MS).toISOString(), pipeline_lease_token: token })
    .eq("id", jobId).or(`pipeline_lease_until.is.null,pipeline_lease_until.lt.${now.toISOString()}`).select("id");
  return data?.length ? token : null;
}
const releaseLease = (jobId: string, token: string) =>
  supabaseAdmin.from("research_queries").update({ pipeline_lease_until: null, pipeline_lease_token: null }).eq("id", jobId).eq("pipeline_lease_token", token);

async function has(jobId: string, dataType: string) {
  const { count } = await supabaseAdmin.from("research_data").select("id", { count: "exact", head: true }).eq("research_query_id", jobId).eq("data_type", dataType);
  return (count ?? 0) > 0;
}

// ---- Stage executors (thin wrappers over the existing tested engines) ----
async function runSearchDemand(job: Job, userId: string): Promise<StageResult> {
  if (await has(job.id, "google_keyword_demand")) return { kind: "completed" };
  const { runGoogleStage } = await import("./research.server");
  const r = await runGoogleStage(supabaseAdmin, job, userId);
  return r.ok ? { kind: "completed" } : { kind: "failed", code: r.error === "DATAFORSEO_CEILING" ? "dataforseo_ceiling" : "search_demand_failed" };
}

async function runMarketplace(job: Job, userId: string): Promise<StageResult> {
  const { runAmazonStage } = await import("./research.server");
  const r = await runAmazonStage(supabaseAdmin, job, userId); // skips keywords already stored for this job
  return r.ok ? { kind: "completed" } : { kind: "failed", code: r.error === "DATAFORSEO_CEILING" ? "dataforseo_ceiling" : "marketplace_failed" };
}

async function runCommunity(job: Job, userId: string): Promise<StageResult> {
  if (await has(job.id, COMMUNITY_MULTI_DATA_TYPE)) return { kind: "completed" };
  const mq = await import("./community/multi-query.server");
  const { data: usage } = await supabaseAdmin.from("external_api_usage").select("id, provider_run_id, status")
    .eq("research_query_id", job.id).eq("endpoint", mq.MULTI_ENDPOINT).eq("cache_hit", false).maybeSingle();

  if (usage && !usage.provider_run_id) {
    // Launch failed before Apify accepted a run: archive the lock row (audit kept, no charge) so a retry may relaunch.
    if (usage.status === "error") {
      await supabaseAdmin.from("external_api_usage").update({ endpoint: `${mq.MULTI_ENDPOINT}#start_failed` }).eq("id", usage.id);
      return { kind: "failed", code: "community_start_failed" };
    }
    return { kind: "failed", code: "community_start_unconfirmed" }; // may have launched; never relaunch blindly
  }
  if (usage?.provider_run_id) {
    const c = await mq.collectCommunityResearch(job.id, userId, 0);
    if (c.collected) return { kind: "completed" };
    return c.reason?.startsWith("run ") && !c.reason.includes("unreadable") ? { kind: "waiting" } : { kind: "failed", code: "community_collect_failed" };
  }

  const s = await mq.startCommunityResearch(job.id, userId);
  if (s.started) return { kind: "waiting" };
  if (s.cache_hit && s.research_data_id) {
    // Attach the cached evidence to this job ($0, usage already logged as cache_hit).
    const { data: src } = await supabaseAdmin.from("research_data").select("*").eq("id", s.research_data_id).single();
    if (!src) return { kind: "failed", code: "community_cache_missing" };
    const { error } = await supabaseAdmin.from("research_data").insert({
      research_query_id: job.id, provider: src.provider, data_type: src.data_type, source_query: src.source_query,
      normalized_query: src.normalized_query, target_country: job.target_country, language: job.language,
      raw_data: { cached_from_research_data_id: src.id } as never, processed_data: src.processed_data,
      cache_hit: true, collected_at: src.collected_at, expires_at: src.expires_at,
    });
    return error ? { kind: "failed", code: "community_cache_copy_failed" } : { kind: "completed" };
  }
  return { kind: "failed", code: "community_refused" }; // ceiling, pending-run limit, no queries
}

async function runScore(job: Job): Promise<StageResult> {
  const { scoreResearchJob } = await import("./scoring.server");
  await scoreResearchJob(job.id, job.query, DEFAULT_SCORE_VERSION); // idempotent per evidence hash
  return { kind: "completed" };
}

async function runAi(job: Job, userId: string): Promise<StageResult> {
  const { data: done } = await supabaseAdmin.from("ai_analyses").select("id").eq("research_query_id", job.id).eq("status", "completed").not("validated_output", "is", null).limit(1).maybeSingle();
  if (done) return { kind: "completed" };
  const { data: open } = await supabaseAdmin.from("ai_analyses").select("id, created_at").eq("research_query_id", job.id).eq("status", "running").limit(1).maybeSingle();
  if (open) {
    // A worker died mid-call: after the stale window mark it failed (needs attention, controlled retry only).
    if (Date.now() - new Date(open.created_at).getTime() < AI_STALE_MS) return { kind: "waiting" };
    await supabaseAdmin.from("ai_analyses").update({ status: "failed", error_message: "stale running analysis" }).eq("id", open.id).eq("status", "running");
    return { kind: "failed", code: "ai_stale" };
  }
  const { runAnalysis } = await import("./ai/analysis.server");
  const r = await runAnalysis(job.id, userId) as { analysis_id: string | null; refused?: string; error?: string };
  if (r.refused === "analysis already in progress") return { kind: "waiting" };
  if (r.refused) return { kind: "failed", code: r.refused.includes("disabled") ? "ai_disabled" : "ai_refused" };
  if (!r.analysis_id || r.error) return { kind: "failed", code: "ai_failed" };
  const { data: a } = await supabaseAdmin.from("ai_analyses").select("status").eq("id", r.analysis_id).single();
  return a?.status === "completed" ? { kind: "completed" } : a?.status === "running" ? { kind: "waiting" } : { kind: "failed", code: "ai_rejected" };
}

async function runReport(job: Job, userId: string): Promise<StageResult> {
  const { generateReportForJob } = await import("./report.server");
  await generateReportForJob(job.id, userId, { pipelineReady: true }); // reuses an identical existing snapshot
  return { kind: "completed" };
}

function executor(job: Job, userId: string) {
  return (stage: PipelineStage): Promise<StageResult> => {
    switch (stage) {
      case "search_demand": return runSearchDemand(job, userId);
      case "marketplace": return runMarketplace(job, userId);
      case "community": return runCommunity(job, userId);
      case "score": return runScore(job);
      case "ai_analysis": return runAi(job, userId);
      case "report": return runReport(job, userId);
    }
  };
}

const LEGACY_STAGE: Record<PipelineStage, string> = { search_demand: "keyword_demand", marketplace: "amazon_supply", community: "complete", score: "complete", ai_analysis: "complete", report: "complete" };

async function saveState(jobId: string, state: PipelineState, current: PipelineStage | null) {
  const status = jobStatusFor(state);
  await supabaseAdmin.from("research_queries").update({
    pipeline_state: state as never, status,
    stage: current ? LEGACY_STAGE[current] : "complete",
    completed_at: status === "completed" ? new Date().toISOString() : null,
    error_message: status === "failed" ? "pipeline_stage_failed" : null,
  }).eq("id", jobId);
}

/** Starts the automated pipeline for a pending job (idempotent: an already-started pipeline is not reset). */
export async function startPipeline(jobId: string, userId: string) {
  const job = await loadJob(jobId, userId);
  if (job.pipeline_version) return { started: true, queued: true };
  if (job.status !== "pending") return { started: false, reason: "not_pending" };
  // Credit-billed jobs reserve exactly 1 credit (idempotent per job) BEFORE any paid work is queued.
  // Legacy/pre-credit jobs are never charged.
  if (job.billing === "credit") {
    const { data: res, error: rErr } = await supabaseAdmin.rpc("reserve_research_credit", { _user: userId, _job: jobId, _key: `research:${jobId}` });
    if (rErr) throw new Error("Credit reservation failed.");
    const st = (res as { status?: string } | null)?.status;
    if (st === "insufficient") return { started: false, reason: "insufficient_credits" };
    if (st !== "reserved" && st !== "finalized") return { started: false, reason: "reservation_unavailable" };
  }
  const { data, error: qErr } = await supabaseAdmin.from("research_queries")
    .update({ pipeline_version: PIPELINE_VERSION, pipeline_state: initialState() as never, status: "processing", started_at: new Date().toISOString(), stage: "keyword_demand" })
    .eq("id", jobId).is("pipeline_version", null).eq("status", "pending").select("id");
  if (qErr) {
    // Queueing failed before any paid research could start: give the credit back.
    if (job.billing === "credit") await supabaseAdmin.rpc("release_research_credit", { _job: jobId, _reason: "queue_failed" });
    throw new Error("Research could not be queued.");
  }
  if (!data?.length) return { started: false, reason: "already_started" };
  return { started: true, queued: true }; // the background worker picks it up
}

/** One bounded worker pass. Concurrent callers get busy=true instead of running a stage twice. */
export async function advanceJob(jobId: string, userId: string, maxSteps?: number) {
  const job = await loadJob(jobId, userId);
  if (!job.pipeline_version) return { busy: false, outcome: "not_pipeline" as const };
  const token = await acquireLease(jobId);
  if (!token) return { busy: true };
  try {
    const run = executor(job as Job, userId);
    const res = await advancePipeline({
      load: async () => normalizeState((await loadJob(jobId, userId)).pipeline_state),
      save: async (s) => { const cur = (Object.keys(s) as PipelineStage[]).find((k) => s[k].status === "running") ?? null; await saveState(jobId, s, cur); },
      run, now: () => new Date().toISOString(),
    }, maxSteps);
    // Chargeable completion point: the full pipeline (incl. report) is complete. Idempotent; never re-reserves.
    if (res.outcome === "complete" && job.billing === "credit") await supabaseAdmin.rpc("finalize_research_credit", { _job: jobId });
    // Permanent technical failure (attempts exhausted): return the reserved credit (same type). Idempotent.
    if (res.outcome === "needs_attention" && job.billing === "credit") {
      const { creditDecision } = await import("./credit_policy_v1");
      const st = normalizeState((await loadJob(jobId, userId)).pipeline_state);
      if (creditDecision("needs_attention", st) === "release") await supabaseAdmin.rpc("release_research_credit", { _job: jobId, _reason: "permanent_failure" });
    }
    return { busy: false, outcome: res.outcome, waiting: res.waiting, ran: res.ran };
  } finally { await releaseLease(jobId, token); }
}

/** Customer "Try again": resets only failed stages (bounded attempts), then advances. */
export async function retryPipeline(jobId: string, userId: string) {
  const job = await loadJob(jobId, userId);
  if (!job.pipeline_version) return { retried: false, reason: "not_pipeline" };
  // A background nudge may briefly hold the lease; wait for it (bounded) instead of dropping the user's retry.
  let token = await acquireLease(jobId);
  for (let i = 0; !token && i < 10; i++) { await new Promise((r) => setTimeout(r, 2000)); token = await acquireLease(jobId); }
  if (!token) return { retried: false, reason: "busy" };
  let reset: PipelineStage[] = []; let exhausted: PipelineStage[] = [];
  try {
    const r = resetForRetry(normalizeState(job.pipeline_state));
    ({ reset, exhausted } = r);
    if (reset.length) await saveState(jobId, r.state, null);
  } finally { await releaseLease(jobId, token); }
  if (!reset.length) {
    if (exhausted.length && job.billing === "credit") await supabaseAdmin.rpc("release_research_credit", { _job: jobId, _reason: "permanent_failure" });
    return { retried: false, reason: exhausted.length ? "attempts_exhausted" : "nothing_to_retry" };
  }
  return { retried: true, queued: true }; // background worker resumes from the reset stage
}

/** Internal per-research cost audit (admin only; caller must verify the role first). */
export async function costSummaryForJob(jobId: string) {
  const { summarizeCosts } = await import("./pipeline/cost_summary_v1");
  const [{ data: ext }, { data: ai }] = await Promise.all([
    supabaseAdmin.from("external_api_usage").select("provider, endpoint, cost, cost_status, cache_hit, status").eq("research_query_id", jobId),
    supabaseAdmin.from("ai_usage").select("cost_usd, cost_status, status").eq("research_query_id", jobId),
  ]);
  return summarizeCosts((ext ?? []) as never, (ai ?? []) as never);
}

/** Background worker pass (called by the scheduler). Bounded: few jobs, few steps each, time budget.
 *  Only advances pending/running stages; failed stages are never retried here. */
export const TICK_LIMITS = { max_jobs: 3, steps_per_job: 2, budget_ms: 150_000 } as const;
/** Worker heartbeat (best effort, never blocks the tick). */
export async function recordWorkerHeartbeat(kind: "start" | "success" | "error", info: { jobs?: number; error?: string } = {}) {
  const now = new Date().toISOString();
  const patch = kind === "start" ? { last_started_at: now } : kind === "success" ? { last_success_at: now, last_jobs: info.jobs ?? 0 } : { last_error_at: now, last_error: (info.error ?? "unknown").slice(0, 200) };
  try { await supabaseAdmin.from("pipeline_worker_heartbeats").upsert({ name: "pipeline_tick", ...patch, updated_at: now }, { onConflict: "name" }); }
  catch (e) { console.error("worker heartbeat failed", e); }
}

export async function processPipelineTick() {
  const t0 = Date.now();
  await recordWorkerHeartbeat("start");
  const nowIso = new Date().toISOString();
  const { data: jobs } = await supabaseAdmin.from("research_queries").select("id, user_id")
    .eq("status", "processing").not("pipeline_version", "is", null)
    .or(`pipeline_lease_until.is.null,pipeline_lease_until.lt.${nowIso}`)
    .order("created_at", { ascending: true }).limit(TICK_LIMITS.max_jobs);
  const results: Array<{ id: string; outcome: unknown; busy?: boolean }> = [];
  for (const j of jobs ?? []) {
    if (Date.now() - t0 > TICK_LIMITS.budget_ms) break;
    try {
      const r = await advanceJob(j.id, j.user_id, TICK_LIMITS.steps_per_job) as { outcome?: unknown; busy?: boolean };
      results.push({ id: j.id, outcome: r.outcome ?? null, busy: !!r.busy });
    } catch (e) { console.error("pipeline tick job failed", j.id, e); results.push({ id: j.id, outcome: "error" }); }
  }
  // Pending authoritative provider costs are finalized even if no customer ever returns.
  let reconciled = 0;
  try { const { reconcileApifyUsage } = await import("./community/apify-cost.server"); reconciled = (await reconcileApifyUsage()).length; }
  catch (e) { console.error("apify reconcile failed", e); }
  const failed = results.filter((r) => r.outcome === "error").length;
  await recordWorkerHeartbeat(failed ? "error" : "success", failed ? { error: `${failed} job(s) raised errors` } : { jobs: results.length });
  return { jobs: results, reconciled };
}

/** Internal health snapshot (admin only; caller must verify the role first). */
export async function workerHealth() {
  const { data, error } = await supabaseAdmin.rpc("pipeline_worker_health");
  if (error) throw new Error("Health unavailable.");
  const { classifyWorker } = await import("./pipeline/worker_health_v1");
  const snap = data as unknown as import("./pipeline/worker_health_v1").HealthSnapshot;
  return { ...snap, ...classifyWorker(snap) };
}

/** Verifies the scheduler's token against the server-only DB row (never readable from browsers). */
export async function verifyWorkerToken(presented: string | null) {
  if (!presented) return false;
  const { data } = await supabaseAdmin.from("internal_worker_tokens").select("token").eq("name", "pipeline_tick").maybeSingle();
  const expected = data?.token;
  if (!expected || expected.length !== presented.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ presented.charCodeAt(i);
  return diff === 0;
}

/** Releases a reservation for a job that never started paid research (e.g. queue failure). */
export async function releaseCreditForJob(jobId: string, reason: string) {
  const { data } = await supabaseAdmin.rpc("release_research_credit", { _job: jobId, _reason: reason });
  return data;
}
