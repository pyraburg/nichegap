import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const scoreResearch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ research_query_id: z.string().uuid(), score_version: z.enum(["score_v1", "score_v1_1"]).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: job } = await context.supabase
      .from("research_queries")
      .select("id, user_id, query, status")
      .eq("id", data.research_query_id)
      .maybeSingle();
    if (!job || job.user_id !== context.userId) throw new Error("Research job not found.");
    if (job.status !== "completed") throw new Error("Research must be completed before scoring.");
    const { scoreResearchJob } = await import("./scoring.server");
    return scoreResearchJob(job.id, job.query, data.score_version);
  });
