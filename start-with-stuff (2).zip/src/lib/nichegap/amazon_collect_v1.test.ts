import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { amazonCacheKey, collectAmazon, mapLimitSettled, type AmazonDeps, type CacheRow, type EvidenceInsert, type UsageInsert } from "./amazon_collect_v1";
import { canStartDfsCall, DFS_COST_DEFAULTS } from "./dataforseo-cost";

const cfg = { ...DFS_COST_DEFAULTS };
const sel = (k: string) => ({ keyword: k, normalized: k, selection: { keyword: k } });
const FIVE = ["a", "b", "c", "d", "e"].map(sel);

/** In-memory world shared by any number of "jobs": cache table, lock table, provider. */
function world(opts: { delay?: number; fail?: Set<string>; timeout?: Set<string>; cost?: number } = {}) {
  const cache: CacheRow[] = [];
  const locks = new Map<string, { token: string; until: number }>();
  let clock = 0; let tok = 0; const providerCalls: string[] = []; let maxConc = 0; let conc = 0; let queries = 0;
  const realSleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  const job = (jobId: string, prior: UsageInsert[] = []) => {
    const usage: UsageInsert[] = [...prior]; const evidence: EvidenceInsert[] = [];
    const deps: AmazonDeps = {
      costConfig: cfg, cacheKey: (n) => amazonCacheKey({ endpoint: "/amz", dataType: "amz", country: "US", locale: "en_US", normalized: n }),
      sleep: async (ms) => { clock += ms; await realSleep(10); },
      lookupCache: async (n) => { queries++; return cache.filter((r) => n.includes(r.normalized_query!)); },
      usageRows: async () => { queries++; return usage.map((u) => ({ cost: u.cost, cache_hit: u.cache_hit, status: u.status })); },
      insertEvidence: async (rows) => { queries++; evidence.push(...rows); for (const r of rows) if (r.fetched) cache.push({ id: `${jobId}:${r.sel.normalized}`, normalized_query: r.sel.normalized, processed_data: {}, collected_at: String(Date.now()), expires_at: null }); },
      insertUsage: async (rows) => { queries++; usage.push(...rows); },
      claim: async (k) => { queries++; const l = locks.get(k); if (l && l.until > clock) return null; const t = `t${++tok}`; locks.set(k, { token: t, until: clock + 120_000 }); return t; },
      release: async (k, t) => { queries++; if (locks.get(k)?.token === t) locks.delete(k); },
      fetch: async (kw) => {
        providerCalls.push(`${jobId}:${kw}`); conc++; maxConc = Math.max(maxConc, conc);
        await realSleep(opts.delay ?? 5); conc--;
        if (opts.timeout?.has(kw)) throw new Error("TimeoutError");
        if (opts.fail?.has(kw)) return { ok: false, cost: 0, raw: {} };
        return { ok: true, cost: opts.cost ?? 0.0033, raw: {}, result: {} };
      },
      waitMs: 10_000, pollMs: 2_000,
    };
    return { deps, usage, evidence };
  };
  return { cache, locks, job, providerCalls, get maxConc() { return maxConc; }, get queries() { return queries; }, advance: (ms: number) => { clock += ms; } };
}

describe("amazon_collect_v1 concurrency", () => {
  it("five requests, never more than two in flight, faster than sequential (mocked 100ms)", async () => {
    const w = world({ delay: 100 });
    const { deps } = w.job("j1");
    const t0 = Date.now(); const r = await collectAmazon(FIVE, deps); const ms = Date.now() - t0;
    const seqW = world({ delay: 100 }); const seq = seqW.job("s"); seq.deps.concurrency = 1;
    const t1 = Date.now(); await collectAmazon(FIVE, seq.deps); const seqMs = Date.now() - t1;
    console.log(`mocked Amazon stage: sequential ${seqMs}ms -> concurrency-2 ${ms}ms`);
    expect(r.ok).toBe(true); expect(w.maxConc).toBe(2); expect(w.providerCalls.length).toBe(5);
    expect(ms).toBeLessThan(seqMs * 0.75);
  });
  it("deterministic result ordering = selection order", async () => {
    const w = world({ delay: 1 }); w.cache.push({ id: "c", normalized_query: "c", processed_data: {}, collected_at: "1", expires_at: null });
    const r = await collectAmazon(FIVE, w.job("j").deps);
    expect(r.outcomes.map((o) => o.keyword)).toEqual(["a", "b", "c", "d", "e"]);
    expect(r.outcomes[2]!.kind).toBe("cache_hit");
  });
  it("mapLimitSettled keeps order and isolates failures", async () => {
    const r = await mapLimitSettled([3, 1, 2], 2, async (n) => { await new Promise((x) => setTimeout(x, n)); if (n === 1) throw new Error("x"); return n; });
    expect(r.map((x) => x.status)).toEqual(["fulfilled", "rejected", "fulfilled"]);
  });
});

describe("cache + accounting", () => {
  it("mixed hits/misses: one batched lookup, hits $0 with one usage row each, misses one paid row each", async () => {
    const w = world(); for (const k of ["a", "b"]) w.cache.push({ id: k, normalized_query: k, processed_data: {}, collected_at: "1", expires_at: null });
    const j = w.job("j"); const r = await collectAmazon(FIVE, j.deps);
    expect(r.ok).toBe(true);
    expect(j.usage.filter((u) => u.cache_hit).length).toBe(2);
    expect(j.usage.filter((u) => !u.cache_hit).map((u) => u.cost)).toEqual([0.0033, 0.0033, 0.0033]);
    expect(w.providerCalls.length).toBe(3);
  });
  it("all-cached stage: 3 queries instead of 1 lookup + 3 per keyword", async () => {
    const w = world(); for (const s of FIVE) w.cache.push({ id: s.keyword, normalized_query: s.keyword, processed_data: {}, collected_at: "1", expires_at: null });
    await collectAmazon(FIVE, w.job("j").deps);
    expect(w.queries).toBe(3); // lookup + evidence batch + usage batch
    expect(w.providerCalls.length).toBe(0);
  });
  it("different markets/languages produce different cache keys", () => {
    const k = (country: string, locale: string) => amazonCacheKey({ endpoint: "/amz", dataType: "amz", country, locale, normalized: "x" });
    expect(new Set([k("US", "en_US"), k("GB", "en_GB"), k("CA", "en_CA"), k("CA", "fr_CA")]).size).toBe(4);
  });
});

describe("failures, timeouts, retry", () => {
  it("partial failure keeps successes and does not poison cache", async () => {
    const w = world({ fail: new Set(["c"]) }); const j = w.job("j");
    const r = await collectAmazon(FIVE, j.deps);
    expect(r.ok).toBe(false); expect(r.outcomes.find((o) => o.keyword === "c")!.kind).toBe("provider_error");
    expect(j.evidence.length).toBe(4); expect(w.cache.some((c) => c.normalized_query === "c")).toBe(false);
    expect(w.locks.size).toBe(0);
  });
  it("timeout logs unknown cost and blocks further paid calls in later retries", async () => {
    const w = world({ timeout: new Set(["a"]) }); const j = w.job("j"); j.deps.concurrency = 1;
    const r = await collectAmazon(FIVE, j.deps);
    expect(r.outcomes[0]!.kind).toBe("timeout");
    expect(j.usage.find((u) => u.status === "timeout")!.cost).toBeNull();
    expect(r.ceiling).toBe(true); // unknown cost => conservative refusal of remaining calls
    expect(w.providerCalls.length).toBe(1);
  });
  it("controlled retry only fetches what is still missing (never re-pays successes)", async () => {
    const w = world({ fail: new Set(["d"]) }); const j = w.job("j");
    await collectAmazon(FIVE, j.deps);
    const done = new Set(j.evidence.map((e) => e.sel.normalized));
    const w2calls = w.providerCalls.length;
    const retry = world(); retry.cache.push(...w.cache); const j2 = retry.job("j", j.usage);
    await collectAmazon(FIVE.filter((s) => !done.has(s.normalized)), j2.deps);
    expect(w2calls).toBe(5); expect(retry.providerCalls).toEqual(["j:d"]);
  });
  it("background resume after restart: an expired lease from a crashed worker is taken over", async () => {
    const w = world(); w.locks.set(w.job("x").deps.cacheKey("a"), { token: "dead", until: -1 });
    const r = await collectAmazon([sel("a")], w.job("j").deps);
    expect(r.ok).toBe(true); expect(w.providerCalls).toEqual(["j:a"]);
  });
});

describe("budget with concurrency", () => {
  it("in-flight calls count toward the ceiling", () => {
    expect(canStartDfsCall([{ cost: 0.22, cache_hit: false, status: "success" }], "amazon", cfg, 0).allowed).toBe(true);
    expect(canStartDfsCall([{ cost: 0.22, cache_hit: false, status: "success" }], "amazon", cfg, 3).allowed).toBe(false);
  });
  it("concurrent requests never exceed $0.25 (expensive mocked calls)", async () => {
    // Prior spend $0.22; each call worst-case at its $0.01 reserve. Only 3 more may start even with 2 in flight.
    const w = world({ delay: 20, cost: 0.01 }); const j = w.job("j", [{ cost: 0.22, cache_hit: false, status: "success" }]);
    const r = await collectAmazon(FIVE, j.deps);
    const spent = j.usage.reduce((s, u) => s + (u.cache_hit ? 0 : u.cost ?? 0), 0);
    expect(spent).toBeLessThanOrEqual(0.25 + 1e-9); expect(w.providerCalls.length).toBe(3); expect(r.ceiling).toBe(true);
  });
});

describe("cross-job single-flight", () => {
  it("two jobs, same uncached query simultaneously => one paid request, other reuses result", async () => {
    const w = world({ delay: 30 }); const a = w.job("A"); const b = w.job("B");
    const [ra, rb] = await Promise.all([collectAmazon([sel("x")], a.deps), collectAmazon([sel("x")], b.deps)]);
    expect(w.providerCalls.length).toBe(1);
    expect([ra.outcomes[0]!.kind, rb.outcomes[0]!.kind].sort()).toEqual(["fetched", "shared_hit"]);
    expect(a.usage.concat(b.usage).filter((u) => !u.cache_hit).length).toBe(1); // cost attributed to the paying job only
  });
  it("bounded wait: if the holder never finishes, waiter gives up as busy without paying", async () => {
    const w = world(); const k = w.job("x").deps.cacheKey("x"); w.locks.set(k, { token: "live", until: 1e12 });
    const r = await collectAmazon([sel("x")], w.job("B").deps);
    expect(r.outcomes[0]!.kind).toBe("busy"); expect(w.providerCalls.length).toBe(0);
  });
  it("stale worker cannot release a lease taken over by another worker", async () => {
    const w = world(); const d = w.job("A").deps; const k = d.cacheKey("x");
    const t1 = await d.claim(k); w.advance(200_000); const t2 = await w.job("B").deps.claim(k);
    expect(t1 && t2 && t1 !== t2).toBeTruthy();
    await d.release(k, t1!); expect(w.locks.get(k)!.token).toBe(t2);
  });
});

describe("wiring guards", () => {
  const rs = readFileSync("src/lib/nichegap/research.server.ts", "utf8");
  const mig = readFileSync("drizzle/migrations/0017_provider_fetch_single_flight.sql", "utf8");
  it("Amazon stage uses batched IN lookup, single-flight RPCs and no unrestricted Promise.all", () => {
    const amz = rs.slice(rs.indexOf("export async function runAmazonStage"));
    expect(amz).toContain('.in("normalized_query", norms)');
    expect(amz).toContain("claim_provider_fetch");
    expect(amz).not.toContain("Promise.all");
    expect(amz).toContain('.eq("research_query_id", job.id).eq("data_type", GOOGLE_DATA_TYPE)');
  });
  it("lease claim is one atomic statement that only takes over expired leases; release requires token", () => {
    expect(mig).toContain("ON CONFLICT (cache_key) DO UPDATE");
    expect(mig).toContain("WHERE public.provider_fetch_locks.lease_until < now()");
    expect(mig).toContain("cache_key = _key AND lease_token = _token");
    expect(mig).toMatch(/REVOKE ALL ON FUNCTION public\.claim_provider_fetch[\s\S]*FROM PUBLIC, anon, authenticated/);
  });
  it("report generation no longer re-queries score_runs for opportunity_id", () => {
    const rep = readFileSync("src/lib/nichegap/report.server.ts", "utf8");
    expect(rep.match(/from\("score_runs"\)/g)?.length).toBe(1);
  });
});
