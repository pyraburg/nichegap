import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { aggregate, maxExposure, scoreBand, VALIDATION_SET, type ValidationRow } from "./validation_v1";
import { summarizeCosts } from "../pipeline/cost_summary_v1";
import { showRefundNotice, REFUND_MESSAGE } from "../credit_policy_v1";

const costs = (g: number, a: number, c: number | null, ai: number) => summarizeCosts(
  [{ provider: "dataforseo", endpoint: "google", cost: g, cache_hit: false }, { provider: "dataforseo", endpoint: "amazon/x", cost: a, cache_hit: false },
   { provider: "apify", endpoint: "reddit", cost: c, cost_status: c === null ? "pending" : "final", cache_hit: false }],
  [{ cost_usd: ai, cost_status: "final", status: "completed" }]);
const row = (p: Partial<ValidationRow>): ValidationRow => ({ id: "x", query: "q", target_country: "US", language: "en", billing: "validation", status: "completed", benchmark: false, score: 50, classification: null, demand: null, competition: null, purchase_intent: null, trend: null, confidence: null, completeness: null, evidence_quality: 80, community_relevant: null, community_quality: 70, community_confidence: null, costs: null, report_final: true, failed_stages: 0, retries: 0, review: null, ...p });

describe("validation metrics", () => {
  it("8 proposed niches", () => expect(VALIDATION_SET.length).toBe(8));
  it("sourdough historical cost reproduces $0.45654", () => {
    expect(costs(0.09, 0.0165, 0.32035, 0.029693).total_known_usd).toBeCloseTo(0.456543, 6);
  });
  it("aggregates known costs; unknown cost jobs excluded and counted, never estimated", () => {
    const g = aggregate([row({ score: 66, costs: costs(0.09, 0.01, 0.25, 0.03) }), row({ score: 45, costs: costs(0.09, 0.0165, 0.32035, 0.029693) }), row({ score: 20, costs: costs(0.09, 0.01, null, 0.03) }), row({ report_final: false, retries: 1 })]);
    expect(g.cost_known_jobs).toBe(2); expect(g.cost_unknown_jobs).toBe(1);
    expect(g.avg_cost).toBeCloseTo((0.38 + 0.456543) / 2, 6);
    expect(g.median_cost).toBeCloseTo((0.38 + 0.456543) / 2, 6);
    expect(g.min_cost).toBeCloseTo(0.38, 6); expect(g.max_cost).toBeCloseTo(0.456543, 6);
    expect(g.completion_rate).toBe(0.75); expect(g.retry_rate).toBe(0.25);
    expect(g.score_distribution).toEqual({ "0-19": 0, "20-39": 1, "40-59": 1, "60-79": 1, "80-100": 0 });
  });
  it("empty set has no invented numbers", () => {
    const g = aggregate([]); expect(g.avg_cost).toBeNull(); expect(g.completion_rate).toBeNull();
  });
  it("score bands", () => { expect(scoreBand(66.2955)).toBe("60-79"); expect(scoreBand(44.8835)).toBe("40-59"); });
  it("max exposure uses ceilings; AI total capped by daily limit", () => {
    const x = maxExposure({ dataforseo_per_job: 0.25, community_per_job: 1, ai_per_analysis: 0.25, ai_daily: 5 }, 8);
    expect(x.per_report.total).toBe(1.5); expect(x.all.total).toBe(12); expect(x.all.ai_capped_by_daily).toBe(false);
    expect(maxExposure({ dataforseo_per_job: 0.25, community_per_job: 1, ai_per_analysis: 1, ai_daily: 5 }, 8).all.ai).toBe(5);
  });
  it("refund notice only after an actual release", () => {
    expect(showRefundNotice("released")).toBe(true);
    for (const s of ["reserved", "finalized", null, undefined]) expect(showRefundNotice(s)).toBe(false);
    expect(REFUND_MESSAGE).toBe("We couldn't complete your report, so your Research Credit has been returned.");
  });
});

describe("validation wiring (source guards)", () => {
  const fns = readFileSync("src/lib/nichegap/validation.functions.ts", "utf8");
  const srv = readFileSync("src/lib/nichegap/validation.server.ts", "utf8");
  const pipe = readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8");
  const mig = readFileSync("drizzle/migrations/0014_phase7_1_validation.sql", "utf8");
  it("every validation function is admin-gated before work", () => {
    expect(fns.match(/await requireAdmin\(context/g)?.length).toBe(3);
    expect(fns).toContain('z.literal("RUN PAID VALIDATION")');
  });
  it("validation jobs never reserve credits; customer jobs still do", () => {
    expect(srv).toContain('billing: "validation"');
    expect(pipe).toMatch(/if \(job\.billing === "credit"\) \{\s*const \{ data: res, error: rErr \} = await supabaseAdmin\.rpc\("reserve_research_credit"/);
  });
  it("QA review never writes scores", () => {
    const save = srv.slice(srv.indexOf("export async function saveReview"), srv.indexOf("export async function createValidationJob"));
    expect(save).toContain('from("validation_reviews")');
    expect(save).not.toMatch(/opportunities|score_runs|reports/);
    expect(mig).not.toMatch(/opportunities|score_runs/);
  });
});
