// Pure internal validation metrics (admin-only). Unknown costs stay unknown: a job whose cost is incomplete
// is excluded from cost aggregates and counted separately — never estimated.
import type { CostSummary } from "../pipeline/cost_summary_v1";

export const VALIDATION_SET = [
  "meal planning for busy parents", "dog anxiety", "budget home gym", "digital planners for students",
  "balcony vegetable gardening", "freelance bookkeeping", "home coffee roasting", "RV organization",
] as const;
export const VALIDATION_MARKET = { target_country: "US", language: "en" } as const;

export interface ValidationRow {
  id: string; query: string; target_country: string; language: string; billing: string; status: string;
  benchmark: boolean;
  score: number | null; classification: string | null;
  demand: number | null; competition: number | null; purchase_intent: number | null; trend: number | null;
  confidence: string | null; completeness: number | null; evidence_quality: number | null;
  community_relevant: number | null; community_quality: number | null; community_confidence: string | null;
  costs: CostSummary | null;
  report_final: boolean; failed_stages: number; retries: number;
  review: { rating: string; notes: string | null } | null;
}

export interface Ceilings { dataforseo_per_job: number; community_per_job: number; ai_per_analysis: number; ai_daily: number }

/** Configured worst case — uses ceilings, not expected costs. AI across N reports is also capped by the daily ceiling. */
export function maxExposure(c: Ceilings, reports: number) {
  const perReport = round(c.dataforseo_per_job + c.community_per_job + c.ai_per_analysis);
  const aiTotal = Math.min(c.ai_per_analysis * reports, c.ai_daily);
  return {
    per_report: { dataforseo: c.dataforseo_per_job, community: c.community_per_job, ai: c.ai_per_analysis, total: perReport },
    all: { reports, dataforseo: round(c.dataforseo_per_job * reports), community: round(c.community_per_job * reports), ai: round(aiTotal),
      total: round(c.dataforseo_per_job * reports + c.community_per_job * reports + aiTotal), ai_capped_by_daily: c.ai_per_analysis * reports > c.ai_daily },
  };
}

const round = (n: number) => Math.round(n * 1e6) / 1e6;
const avg = (xs: number[]) => (xs.length ? round(xs.reduce((a, b) => a + b, 0) / xs.length) : null);
const median = (xs: number[]) => {
  if (!xs.length) return null;
  const s = [...xs].sort((a, b) => a - b); const m = Math.floor(s.length / 2);
  return round(s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2);
};
const nums = (xs: (number | null)[]) => xs.filter((x): x is number => typeof x === "number" && Number.isFinite(x));

export function scoreBand(s: number) { return s >= 80 ? "80-100" : s >= 60 ? "60-79" : s >= 40 ? "40-59" : s >= 20 ? "20-39" : "0-19"; }

export function aggregate(rows: ValidationRow[]) {
  const done = rows.filter((r) => r.report_final);
  const costed = done.filter((r) => r.costs?.complete);
  const totals = costed.map((r) => r.costs!.total_known_usd);
  const line = (k: "google" | "amazon" | "community" | "ai") => avg(costed.map((r) => r.costs![k].known_usd));
  const dist: Record<string, number> = { "0-19": 0, "20-39": 0, "40-59": 0, "60-79": 0, "80-100": 0 };
  for (const s of nums(done.map((r) => r.score))) dist[scoreBand(s)]!++;
  const g = line("google"); const a = line("amazon");
  return {
    jobs: rows.length, completed: done.length,
    completion_rate: rows.length ? round(done.length / rows.length) : null,
    retry_rate: rows.length ? round(rows.filter((r) => r.retries > 0).length / rows.length) : null,
    cost_known_jobs: costed.length, cost_unknown_jobs: done.length - costed.length,
    avg_cost: avg(totals), median_cost: median(totals),
    min_cost: totals.length ? Math.min(...totals) : null, max_cost: totals.length ? Math.max(...totals) : null,
    avg_dataforseo: g === null || a === null ? null : round(g + a), avg_community: line("community"), avg_ai: line("ai"),
    avg_score: avg(nums(done.map((r) => r.score))), score_distribution: dist,
    avg_evidence_quality: avg(nums(done.map((r) => r.evidence_quality))),
    avg_community_quality: avg(nums(done.map((r) => r.community_quality))),
  };
}
