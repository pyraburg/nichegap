import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const generateReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ research_query_id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    // Ownership check as the user (RLS) before any privileged work.
    const { data: job } = await context.supabase.from("research_queries")
      .select("id, user_id").eq("id", data.research_query_id).maybeSingle();
    if (!job || job.user_id !== context.userId) throw new Error("Research job not found.");
    const { generateReportForJob } = await import("./report.server");
    return generateReportForJob(job.id, context.userId);
  });
