// Customer journey status mapping. Pure: derives customer-facing stages ONLY from facts that the
// backend has actually persisted (job status/stage, stored evidence, score runs, AI analyses, reports).
// No timers, no simulated progress, no provider names.

export type BackendJobStatus = "pending" | "processing" | "completed" | "failed" | string;

export interface JobFacts {
  status: BackendJobStatus;
  stage: string | null; // research_queries.stage: keyword_demand | amazon_supply | complete
  has_search_demand: boolean; // research_data google_keyword_demand
  has_marketplace: boolean; // research_data amazon_marketplace_supply
  has_community: boolean; // research_data community multi-query evidence
  has_score: boolean; // score_runs (default score version)
  has_ai_analysis: boolean; // ai_analyses status=completed with validated output
  has_report: boolean; // reports status=final
  generating_report?: boolean; // client-side: report request in flight
  /** Automated pipeline_v1 stage statuses (null for jobs created before Phase 5.3). */
  pipeline?: Partial<Record<PipelineStageKey, string>> | null;
}

export type PipelineStageKey = "search_demand" | "marketplace" | "community" | "score" | "ai_analysis" | "report";
const PIPELINE_FOR: Record<string, PipelineStageKey> = {
  search_demand: "search_demand", marketplace: "marketplace", customer_problems: "community",
  opportunity: "score", evidence_analysis: "ai_analysis", report: "report",
};
const PIPELINE_STATE: Record<string, StageState> = { completed: "done", skipped: "done", running: "active", failed: "attention", pending: "waiting" };

function pipelineStages(p: NonNullable<JobFacts["pipeline"]>): Stage[] {
  return STAGES.map((s) => ({ key: s.key, label: s.label, state: PIPELINE_STATE[p[PIPELINE_FOR[s.key]!] ?? "pending"] ?? "waiting" }));
}

export type StageState = "done" | "active" | "waiting" | "not_included" | "attention";
export interface Stage { key: string; label: string; state: StageState }

export const STAGES = [
  { key: "search_demand", label: "Checking search demand" },
  { key: "marketplace", label: "Analysing marketplace competition" },
  { key: "customer_problems", label: "Finding customer problems" },
  { key: "opportunity", label: "Calculating opportunity potential" },
  { key: "evidence_analysis", label: "Analysing the evidence" },
  { key: "report", label: "Preparing your report" },
] as const;

export function journeyStages(f: JobFacts): Stage[] {
  if (f.pipeline) return pipelineStages(f.pipeline);
  const running = f.status === "processing";
  const failed = f.status === "failed";
  const core = f.status === "completed";
  const onMarketplace = f.stage === "amazon_supply"; // backend stage pointer
  return STAGES.map((s) => {
    let state: StageState;
    switch (s.key) {
      case "search_demand":
        state = f.has_search_demand && (core || onMarketplace) ? "done" : running && !onMarketplace ? "active" : failed && !onMarketplace ? "attention" : "waiting"; break;
      case "marketplace":
        state = core ? (f.has_marketplace ? "done" : "not_included") : running && onMarketplace ? "active" : failed && onMarketplace ? "attention" : "waiting"; break;
      // Optional evidence: shown complete only when stored; otherwise "not included" once core research is done.
      case "customer_problems": state = f.has_community ? "done" : core ? "not_included" : "waiting"; break;
      case "opportunity": state = f.has_score ? "done" : "waiting"; break;
      case "evidence_analysis": state = f.has_ai_analysis ? "done" : core ? "not_included" : "waiting"; break;
      default: state = f.has_report ? "done" : f.generating_report ? "active" : "waiting";
    }
    return { key: s.key, label: s.label, state };
  });
}

export type CustomerStatus = "not_started" | "researching" | "ready_for_report" | "generating_report" | "complete" | "needs_attention";
export const CUSTOMER_STATUS_LABEL: Record<CustomerStatus, string> = {
  not_started: "Not started",
  researching: "Researching",
  ready_for_report: "Ready for report",
  generating_report: "Generating report",
  complete: "Complete",
  needs_attention: "Needs attention",
};

export function customerStatus(f: JobFacts): CustomerStatus {
  if (f.pipeline) {
    const v = Object.values(f.pipeline);
    if (v.includes("failed")) return "needs_attention";
    if (f.pipeline.report === "completed" && f.has_report) return "complete";
    return "researching"; // full report still being prepared automatically
  }
  if (f.status === "failed") return "needs_attention";
  if (f.status === "processing") return "researching";
  if (f.status === "pending") return "not_started";
  if (f.status === "completed") {
    if (f.has_report) return "complete";
    if (f.generating_report) return "generating_report";
    return "ready_for_report";
  }
  return "needs_attention";
}

/** Customer-safe failure copy. Raw backend/provider errors are never passed through. */
export const FAILURE_MESSAGE = "We couldn't complete this part of the research. Your existing results are safe. Please try again.";
export const REPORT_FAILURE_MESSAGE = "We couldn't prepare your report just now. Your research results are safe. Please try again.";

/** Plain-language band for a 0–100 component score (null = not enough data). */
export function indication(score: number | null | undefined): string {
  if (typeof score !== "number") return "Not enough data";
  if (score >= 70) return "Strong";
  if (score >= 45) return "Moderate";
  return "Limited";
}
