// Security regression guards: no unauthenticated server functions, no caller-controlled outbound URLs,
// no customer API keys/provider URLs, and the legacy browser-key workspace stays removed.
import { describe, expect, it } from "vitest";
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

function walk(dir: string, out: string[] = []) {
  for (const f of readdirSync(dir)) {
    const p = join(dir, f);
    if (statSync(p).isDirectory()) walk(p, out); else if (/\.(ts|tsx)$/.test(f) && !/\.test\.ts$/.test(f) && !p.includes("integrations/supabase")) out.push(p);
  }
  return out;
}
const files = walk("src").filter((f) => !f.endsWith("routeTree.gen.ts"));
const src = (f: string) => readFileSync(f, "utf8");

// Every outbound host the server is allowed to contact (constant, never caller-supplied).
const ALLOWED_FETCH = [/`\$\{API\}\$\{path\}`/, /`https:\/\/api\.dataforseo\.com\$\{(AMAZON_ENDPOINT|DFS_ENDPOINT)\}`/, /`\$\{GATEWAY_URL\}/, /"https:\/\/api\.openai\.com\/v1\/responses"/];

describe("security guards", () => {
  it("legacy browser-key workspace and AI proxy are removed", () => {
    for (const f of ["src/lib/nichegap/ai.functions.ts", "src/lib/nichegap/ai.server.ts", "src/lib/nichegap/store.ts", "src/lib/nichegap/types.ts"]) expect(existsSync(f)).toBe(false);
    for (const f of files) {
      const s = src(f);
      expect(s, f).not.toMatch(/testProvider|runNicheScan|generateOpportunityPlan|providerBaseUrl|ollama|11434/i);
    }
  });

  it("every server function requires authentication", () => {
    for (const f of files) {
      const s = src(f);
      const fns = s.match(/createServerFn\(/g)?.length ?? 0;
      if (!fns) continue;
      const authed = s.match(/\.middleware\(\[requireSupabaseAuth\]\)/g)?.length ?? 0;
      expect(authed, `${f}: ${fns} server functions, ${authed} authenticated`).toBe(fns);
    }
  });

  it("server-side fetches only go to fixed provider hosts (no caller-controlled URLs)", () => {
    for (const f of files.filter((x) => /\.server\.ts$|routes\/api\//.test(x))) {
      for (const m of src(f).matchAll(/\bfetch\(([^,)]+)/g)) {
        const target = m[1]!.trim();
        if (target === "input" || target === "url") continue; // only inside generated supabase fetch shims (excluded) — fail otherwise
        expect(ALLOWED_FETCH.some((r) => r.test(target)), `${f}: fetch(${target})`).toBe(true);
      }
    }
  });

  it("fixed provider base URLs are https constants, not private/metadata hosts", () => {
    const consts = files.flatMap((f) => [...src(f).matchAll(/(?:const|export const) (?:API|GATEWAY_URL)\s*=\s*"([^"]+)"/g)].map((m) => m[1]!));
    expect(consts.length).toBeGreaterThan(0);
    for (const u of consts) {
      expect(u).toMatch(/^https:\/\//);
      expect(u).not.toMatch(/localhost|127\.|10\.|192\.168\.|169\.254\.|metadata/);
    }
  });

  it("public HTTP routes verify the caller before doing work", () => {
    const tick = src("src/routes/api/public/pipeline-tick.ts");
    expect(tick.indexOf("verifyWorkerToken")).toBeLessThan(tick.indexOf("processPipelineTick("));
    const ls = src("src/lib/nichegap/billing.server.ts");
    expect(ls.indexOf("verifySignature(rawBody")).toBeLessThan(ls.indexOf("JSON.parse(rawBody)"));
  });

  it("server function results never echo raw provider bodies", () => {
    for (const f of files.filter((x) => x.endsWith(".functions.ts"))) expect(src(f), f).not.toMatch(/\.text\(\)|error\.message|String\(error\)/);
  });
});

describe("research job deletion guard (migration)", () => {
  const m = readFileSync("drizzle/migrations/0015_protect_research_job_deletion.sql", "utf8") + readFileSync("drizzle/migrations/0016_delete_guard_no_advisory_lock.sql", "utf8");
  it("FKs restrict deletion of jobs with credit records", () => {
    expect(m).toMatch(/credit_reservations[\s\S]*REFERENCES public\.research_queries\(id\) ON DELETE RESTRICT/);
    expect(m).toMatch(/credit_ledger[\s\S]*REFERENCES public\.research_queries\(id\) ON DELETE RESTRICT/);
  });
  it("trigger blocks credit-history and in-progress jobs for every role; customers only delete unstarted jobs", () => {
    expect(m).toContain("BEFORE DELETE ON public.research_queries");
    expect(m).toContain("status NOT IN ('completed','failed')");
    expect(m).toContain("USING (user_id = auth.uid() AND status = 'pending' AND pipeline_version IS NULL)");
  });
  it("only code path deleting jobs targets unstarted pending jobs", () => {
    const deletes = files.flatMap((f) => [...src(f).matchAll(/from\("research_queries"\)\.delete\(\)[^;]*/g)].map((x) => x[0]));
    expect(deletes.length).toBe(1);
    expect(deletes[0]).toContain('.eq("status", "pending")');
  });
});
