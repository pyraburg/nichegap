// Server-only Lemon Squeezy integration. Secrets: LEMONSQUEEZY_API_KEY, LEMONSQUEEZY_STORE_ID,
// LEMONSQUEEZY_WEBHOOK_SECRET, LEMONSQUEEZY_VARIANT_{MONTHLY,TOPUP_5,TOPUP_15,TOPUP_40}. Optional LEMONSQUEEZY_LIVE_ENABLED.
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { decideAction, ENTITLEMENTS, eventKey, resolveAccount, verifySignature, type PlanKey, type VariantMap, type WebhookPayload } from "./billing/lemonsqueezy_v1";

const API = "https://api.lemonsqueezy.com/v1";
const env = (k: string) => process.env[k]?.trim() || "";

const liveEnabled = () => env("LEMONSQUEEZY_LIVE_ENABLED") === "true";
// Live mode reads separate LEMONSQUEEZY_LIVE_* secrets (live IDs/keys differ from test); test mode keeps the originals.
const cfg = (k: string) => env(liveEnabled() ? k.replace("LEMONSQUEEZY_", "LEMONSQUEEZY_LIVE_") : k);
export function variantMap(): VariantMap {
  return { monthly: cfg("LEMONSQUEEZY_VARIANT_MONTHLY"), topup_5: cfg("LEMONSQUEEZY_VARIANT_TOPUP_5"), topup_15: cfg("LEMONSQUEEZY_VARIANT_TOPUP_15"), topup_40: cfg("LEMONSQUEEZY_VARIANT_TOPUP_40") };
}
export const billingConfigured = () => !!(cfg("LEMONSQUEEZY_API_KEY") && cfg("LEMONSQUEEZY_STORE_ID"));

async function ls(path: string, init?: RequestInit) {
  const r = await fetch(`${API}${path}`, { ...init, headers: { Accept: "application/vnd.api+json", "Content-Type": "application/vnd.api+json", Authorization: `Bearer ${env("LEMONSQUEEZY_API_KEY")}` } });
  if (!r.ok) throw new Error(`lemonsqueezy_${r.status}`);
  return r.json() as Promise<{ data: { id: string; attributes: Record<string, unknown> } }>;
}

export async function createCheckoutUrl(userId: string, email: string | null, plan: PlanKey, origin: string) {
  const variant = variantMap()[plan];
  if (!billingConfigured() || !variant) throw new Error("billing_not_configured");
  const body = {
    data: {
      type: "checkouts",
      attributes: {
        checkout_data: { ...(email ? { email } : {}), custom: { user_id: userId, plan } },
        product_options: { redirect_url: `${origin}/plan?checkout=done`, enabled_variants: [Number(variant)] },
        test_mode: !liveEnabled(),
      },
      relationships: { store: { data: { type: "stores", id: env("LEMONSQUEEZY_STORE_ID") } }, variant: { data: { type: "variants", id: variant } } },
    },
  };
  const j = await ls("/checkouts", { method: "POST", body: JSON.stringify(body) });
  return String(j.data.attributes["url"]);
}

/** Fresh signed customer-portal URL (expires ~24h; never persisted). */
export async function customerPortalUrl(userId: string) {
  const { data } = await supabaseAdmin.from("billing_subscriptions").select("provider_subscription_id").eq("user_id", userId).order("updated_at", { ascending: false }).limit(1).maybeSingle();
  if (!data) return null;
  const j = await ls(`/subscriptions/${encodeURIComponent(data.provider_subscription_id)}`);
  const urls = j.data.attributes["urls"] as { customer_portal?: string } | undefined;
  return urls?.customer_portal ?? null;
}

async function ownerOf(subId: string) {
  const { data } = await supabaseAdmin.from("billing_subscriptions").select("user_id").eq("provider_subscription_id", subId).maybeSingle();
  return data?.user_id ?? null;
}

async function profileExists(id: string) {
  const { data } = await supabaseAdmin.from("profiles").select("id").eq("id", id).maybeSingle();
  return !!data;
}

/** Returns HTTP status: 200 handled/ignored (no retry), 400 bad, 401 bad signature, 500 retry later (incl. missing signing secret). */
export async function handleWebhook(rawBody: string, signature: string | null): Promise<{ status: number; outcome: string }> {
  const secret = env("LEMONSQUEEZY_WEBHOOK_SECRET");
  if (!secret) return { status: 500, outcome: "not_configured" };
  if (!(await verifySignature(rawBody, signature, secret))) return { status: 401, outcome: "invalid_signature" };
  let p: WebhookPayload;
  try { p = JSON.parse(rawBody); } catch { return { status: 400, outcome: "bad_json" }; }

  const action = decideAction(p, variantMap(), { allowLive: liveEnabled() });
  const custom = p.meta?.custom_data?.["user_id"];
  const key = eventKey(p);
  // Replays get their own log row (suffixed key) labelled "duplicate:", so they're distinguishable from the original.
  const log = async (outcome: string, user_id: string | null) => {
    const k = outcome.startsWith("duplicate:") ? `${key}:dup:${Date.now()}:${crypto.randomUUID().slice(0, 8)}` : key;
    await supabaseAdmin.from("billing_webhook_events").upsert({ event_key: k, event_name: p.meta?.event_name ?? "unknown", user_id, outcome, test_mode: p.meta?.test_mode ?? null }, { onConflict: "event_key", ignoreDuplicates: true });
  };

  if (action.type === "ignore") { await log(`ignored:${action.reason}`, null); return { status: 200, outcome: action.reason }; }
  if (action.type === "reject") { await log(`rejected:${action.reason}`, null); return { status: 200, outcome: action.reason }; }

  if (action.type === "upsert_subscription") {
    const acct = resolveAccount(custom, await ownerOf(action.subscription_id));
    if ("error" in acct || !(await profileExists(acct.user_id))) { await log("rejected:account", null); return { status: 200, outcome: "account" }; }
    const { error } = await supabaseAdmin.from("billing_subscriptions").upsert({
      user_id: acct.user_id, provider_subscription_id: action.subscription_id, provider_customer_id: action.customer_id, variant_id: action.variant_id,
      status: action.status, cancelled: action.cancelled, renews_at: action.renews_at, ends_at: action.ends_at, test_mode: p.meta?.test_mode === true, updated_at: new Date().toISOString(),
    }, { onConflict: "provider_subscription_id" });
    if (error) return { status: 500, outcome: "db_error" };
    // End of the paid period: remaining monthly credits expire; purchased credits are untouched.
    if (action.status === "expired") {
      const { error: xErr } = await supabaseAdmin.rpc("expire_monthly_credits", { _user: acct.user_id, _key: `ls_expired:${action.subscription_id}` });
      if (xErr) return { status: 500, outcome: "db_error" };
    }
    await log(`subscription:${action.status}`, acct.user_id);
    return { status: 200, outcome: "subscription_saved" };
  }

  if (action.type === "subscription_payment_failed") {
    const owner = await ownerOf(action.subscription_id);
    if (owner) await supabaseAdmin.from("billing_subscriptions").update({ status: "past_due", updated_at: new Date().toISOString() }).eq("provider_subscription_id", action.subscription_id);
    await log("payment_failed_no_credits", owner);
    return { status: 200, outcome: "payment_failed" };
  }

  if (action.type === "allocate_monthly") {
    const owner = await ownerOf(action.subscription_id);
    // Subscription not yet known (events may arrive out of order): ask Lemon Squeezy to retry later.
    if (!owner) return { status: 500, outcome: "subscription_unknown_retry" };
    const acct = resolveAccount(custom, owner);
    if ("error" in acct) { await log("rejected:account", null); return { status: 200, outcome: "account" }; }
    const { data: res, error } = await supabaseAdmin.rpc("allocate_monthly_credits", { _user: acct.user_id, _amount: ENTITLEMENTS.monthly.credits, _period_key: `ls_invoice:${action.invoice_id}` });
    if (error) return { status: 500, outcome: "db_error" };
    const dupM = (res as { status?: string } | null)?.status === "duplicate";
    await log(`${dupM ? "duplicate:" : ""}monthly_allocated:${action.billing_reason}`, acct.user_id);
    return { status: 200, outcome: "monthly_allocated" };
  }

  // grant_topup
  const acct = resolveAccount(custom, null);
  if ("error" in acct || !(await profileExists(acct.user_id))) { await log("rejected:account", null); return { status: 200, outcome: "account" }; }
  const { data: res, error } = await supabaseAdmin.rpc("grant_research_credits", {
    _user: acct.user_id, _amount: action.credits, _type: "purchased", _event: "topup_purchase",
    _key: `ls_order:${action.order_id}`, _metadata: { plan: action.plan, provider: "lemonsqueezy" },
  });
  if (error) return { status: 500, outcome: "db_error" };
  const dupT = (res as { status?: string } | null)?.status === "duplicate";
  await log(`${dupT ? "duplicate:" : ""}topup:${action.plan}`, acct.user_id);
  return { status: 200, outcome: "topup_granted" };
}
