// Server-only Amazon marketplace research via DataForSEO Merchant Amazon API.
// Credentials come from backend secrets and never leave the server.
import { normalizeQuery, type KeywordEvidence } from "./dataforseo.server";

export const AMAZON_ENDPOINT = "/v3/merchant/amazon/products/live/advanced";
export const AMAZON_DATA_TYPE = "amazon_marketplace_supply";
export const AMAZON_CACHE_DAYS = 7;
export const MAX_AMAZON_KEYWORDS = 5;
export const STRONG_COMPETITOR_RULE = "strong_competitor_v1";
// strong_competitor_v1: review_count >= 100 AND rating >= 4.3 AND bought_past_month > 0

const LOCATION_CODES: Record<string, number> = {
  US: 2840, GB: 2826, CA: 2124, AU: 2036, ZA: 2710, DE: 2276, FR: 2250, ES: 2724,
};

// Amazon language codes are locale-specific (en_US, en_GB, ...).
const AMAZON_LOCALES: Record<string, string> = {
  "US:en": "en_US", "GB:en": "en_GB", "CA:en": "en_CA", "CA:fr": "fr_CA",
  "AU:en": "en_AU", "DE:de": "de_DE", "FR:fr": "fr_FR", "ES:es": "es_ES",
  "ZA:en": "en_GB",
};

export function amazonLocale(country: string, language: string): string | null {
  return AMAZON_LOCALES[`${country}:${language}`] ?? null;
}

// ---------------------------------------------------------------------------
// Deterministic keyword selection (no AI)
// ---------------------------------------------------------------------------

const PRODUCT_MODIFIERS = [
  "best", "kit", "buy", "system", "product", "for beginners", "with", "under", "starter", "set",
];

const STOPWORDS = new Set([
  "a", "an", "the", "and", "or", "of", "in", "on", "at", "to", "for", "with", "your", "you",
]);

export function importantWords(text: string): string[] {
  return normalizeQuery(text)
    .split(" ")
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));
}

export interface SelectedKeyword {
  keyword: string;
  score: number;
  reasons: string[];
}

export function selectAmazonKeywords(
  keywords: KeywordEvidence[],
  niche: string,
  max = MAX_AMAZON_KEYWORDS,
): SelectedKeyword[] {
  const nicheWords = new Set(importantWords(niche));
  const volumes = keywords.map((k) => k.search_volume ?? 0);
  const maxVol = Math.max(1, ...volumes);
  const cpcs = keywords.map((k) => k.cpc ?? 0);
  const maxCpc = Math.max(0.01, ...cpcs);

  const scored = keywords.map((k) => {
    const kw = normalizeQuery(k.keyword);
    const reasons: string[] = [];
    let score = 0;

    const vol = k.search_volume ?? 0;
    if (vol > 0) {
      score += (vol / maxVol) * 40;
      reasons.push(`search volume ${vol.toLocaleString()}`);
    }
    const cpc = k.cpc ?? 0;
    if (cpc > 0) {
      score += (cpc / maxCpc) * 20;
      reasons.push(`CPC $${cpc.toFixed(2)} signals commercial intent`);
    }
    const modifiers = PRODUCT_MODIFIERS.filter((m) => kw.includes(m));
    if (modifiers.length) {
      score += Math.min(25, modifiers.length * 10);
      reasons.push(`product-oriented wording: ${modifiers.join(", ")}`);
    }
    const overlap = importantWords(kw).filter((w) => nicheWords.has(w));
    if (overlap.length) {
      score += Math.min(15, overlap.length * 5);
      reasons.push(`relevant to niche (${overlap.join(", ")})`);
    }
    return { keyword: k.keyword, score: Math.round(score * 100) / 100, reasons };
  });

  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, max);
}

// ---------------------------------------------------------------------------
// DataForSEO Amazon Products fetch
// ---------------------------------------------------------------------------

type Json = Record<string, unknown>;
const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);

export interface AmazonProduct {
  title: string | null;
  asin: string | null;
  result_type: string | null;
  rank_group: number | null;
  rank_absolute: number | null;
  price: number | null;
  currency: string | null;
  bought_past_month: number | null;
  rating: number | null;
  review_count: number | null;
  is_amazon_choice: boolean;
  is_best_seller: boolean;
  relevant: boolean;
}

export interface AmazonQueryResult {
  keyword: string;
  results_count: number | null;
  categories: string[] | null;
  items_count: number | null;
  collected_at: string;
  products: AmazonProduct[];
  metrics: AmazonMetrics;
}

export async function fetchAmazonProducts(keyword: string, country: string, language: string) {
  const login = process.env["DATAFORSEO_LOGIN"]?.trim();
  const password = process.env["DATAFORSEO_PASSWORD"]?.trim();
  if (!login || !password) throw new Error("PROVIDER_NOT_CONFIGURED");
  const location_code = LOCATION_CODES[country];
  const language_code = amazonLocale(country, language);
  if (!location_code || !language_code) throw new Error("UNSUPPORTED_MARKET");

  const res = await fetch(`https://api.dataforseo.com${AMAZON_ENDPOINT}`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${login}:${password}`)}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify([{ keyword, location_code, language_code }]),
    signal: AbortSignal.timeout(45_000), // amazon_collect_v1 AMAZON_FETCH_TIMEOUT_MS; throws on timeout
  });
  const body = (await res.json().catch(() => null)) as Json | null;
  const cost = num(body?.["cost"]);
  const task = (body?.["tasks"] as Json[] | undefined)?.[0];
  if (!res.ok || !body || body["status_code"] !== 20000 || !task || task["status_code"] !== 20000) {
    console.error("DataForSEO Amazon error", res.status, body?.["status_message"], task?.["status_message"]);
    return { ok: false as const, cost, raw: body };
  }
  const result = (task["result"] as Json[] | null)?.[0] ?? null;
  return { ok: true as const, cost, raw: body, result };
}

// ---------------------------------------------------------------------------
// Normalization, relevance filtering, derived metrics
// ---------------------------------------------------------------------------

function isRelevant(title: string | null, nicheWords: Set<string>, keywordWords: Set<string>): boolean {
  if (!title) return false;
  const titleWords = new Set(importantWords(title));
  for (const w of keywordWords) if (titleWords.has(w)) return true;
  for (const w of nicheWords) if (titleWords.has(w)) return true;
  return false;
}

export function normalizeAmazonResult(
  result: Json,
  keyword: string,
  niche: string,
  collectedAt: string,
): AmazonQueryResult {
  const nicheWords = new Set(importantWords(niche));
  const keywordWords = new Set(importantWords(keyword));
  const items = (result["items"] as Json[] | null) ?? [];

  const products: AmazonProduct[] = items
    .filter((it) => it["type"] === "amazon_serp" || it["type"] === "amazon_paid")
    .map((it) => {
      const rating = it["rating"] as Json | null;
      const title = typeof it["title"] === "string" ? (it["title"] as string) : null;
      return {
        title,
        asin: typeof it["data_asin"] === "string" ? (it["data_asin"] as string) : null,
        result_type: typeof it["type"] === "string" ? (it["type"] as string) : null,
        rank_group: num(it["rank_group"]),
        rank_absolute: num(it["rank_absolute"]),
        price: num(it["price_from"]) ?? num(it["price_to"]),
        currency: typeof it["currency"] === "string" ? (it["currency"] as string) : null,
        bought_past_month: num(it["bought_past_month"]),
        rating: rating ? num(rating["value"]) : null,
        review_count: rating ? num(rating["votes_count"]) : null,
        is_amazon_choice: it["is_amazon_choice"] === true,
        is_best_seller: it["is_best_seller"] === true,
        relevant: isRelevant(title, nicheWords, keywordWords),
      };
    });

  return {
    keyword,
    results_count: num(result["se_results_count"]),
    categories: Array.isArray(result["categories"])
      ? (result["categories"] as unknown[]).map(String)
      : null,
    items_count: num(result["items_count"]),
    collected_at: collectedAt,
    products,
    metrics: computeMetrics(products),
  };
}

export interface AmazonMetrics {
  relevant_product_count: number;
  paid_result_count: number;
  organic_result_count: number;
  paid_result_ratio: number | null;
  median_price: number | null;
  median_rating: number | null;
  median_review_count: number | null;
  products_with_bought_past_month: number;
  estimated_recent_purchase_signal: number | null;
  amazon_choice_count: number;
  best_seller_count: number;
  strong_competitor_ratio: number | null;
  strong_competitor_rule: string;
}

function median(values: number[]): number | null {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  const m = s.length % 2 ? s[mid]! : (s[mid - 1]! + s[mid]!) / 2;
  return Math.round(m * 100) / 100;
}

export function computeMetrics(products: AmazonProduct[]): AmazonMetrics {
  const relevant = products.filter((p) => p.relevant);
  const base = relevant.length ? relevant : []; // competition calcs use relevant only
  const paid = base.filter((p) => p.result_type === "amazon_paid").length;
  const organic = base.filter((p) => p.result_type === "amazon_serp").length;
  const withBought = base.filter((p) => (p.bought_past_month ?? 0) > 0);
  const strong = base.filter(
    (p) => (p.review_count ?? 0) >= 100 && (p.rating ?? 0) >= 4.3 && (p.bought_past_month ?? 0) > 0,
  );
  return {
    relevant_product_count: relevant.length,
    paid_result_count: paid,
    organic_result_count: organic,
    paid_result_ratio: base.length ? Math.round((paid / base.length) * 1000) / 1000 : null,
    median_price: median(base.map((p) => p.price).filter((v): v is number => v !== null)),
    median_rating: median(base.map((p) => p.rating).filter((v): v is number => v !== null)),
    median_review_count: median(base.map((p) => p.review_count).filter((v): v is number => v !== null)),
    products_with_bought_past_month: withBought.length,
    estimated_recent_purchase_signal: withBought.length
      ? withBought.reduce((sum, p) => sum + (p.bought_past_month ?? 0), 0)
      : null,
    amazon_choice_count: base.filter((p) => p.is_amazon_choice).length,
    best_seller_count: base.filter((p) => p.is_best_seller).length,
    strong_competitor_ratio: base.length ? Math.round((strong.length / base.length) * 1000) / 1000 : null,
    strong_competitor_rule: STRONG_COMPETITOR_RULE,
  };
}
