import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function requireAdmin(context: { supabase: { rpc: (...a: never[]) => unknown }; userId: string }) {
  const { data } = await (context.supabase.rpc as unknown as (n: string, a: object) => Promise<{ data: boolean | null }>)("has_role", { _user_id: context.userId, _role: "admin" });
  if (!data) throw new Error("Not authorized.");
}

export const getValidationDashboard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await requireAdmin(context as never);
    const { validationDashboard } = await import("./validation.server");
    return validationDashboard();
  });

/** Human QA only: writes validation_reviews, never scores. */
export const saveValidationReview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ research_query_id: z.string().uuid(), rating: z.enum(["good", "questionable", "poor"]), notes: z.string().trim().max(4000).nullable() }).parse(d))
  .handler(async ({ data, context }) => {
    await requireAdmin(context as never);
    const { saveReview } = await import("./validation.server");
    return saveReview(data.research_query_id, context.userId, data.rating, data.notes || null);
  });

/** Admin-only. Starts a real (paid, ceiling-guarded) validation job that never consumes Research Credits. */
export const startValidationJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ query: z.string().trim().min(2).max(200), target_country: z.string().min(2).max(8), language: z.string().min(2).max(8), confirm: z.literal("RUN PAID VALIDATION") }).parse(d))
  .handler(async ({ data, context }) => {
    await requireAdmin(context as never);
    const { createValidationJob } = await import("./validation.server");
    return createValidationJob(context.userId, data.query, data.target_country, data.language);
  });
