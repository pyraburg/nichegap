import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { creditDecision, CREDIT_POLICY_TEXT } from "./credit_policy_v1";
import { initialState, MAX_STAGE_ATTEMPTS, PIPELINE_STAGES, resetForRetry, type PipelineState } from "./pipeline/pipeline_v1";

const done = (): PipelineState => Object.fromEntries(PIPELINE_STAGES.map((s) => [s, { status: "completed", attempts: 1, updated_at: null, error_code: null }])) as PipelineState;
const failAt = (stage: (typeof PIPELINE_STAGES)[number], attempts: number): PipelineState => ({ ...done(), [stage]: { status: "failed", attempts, updated_at: null, error_code: "x" } });

describe("credit policy v1", () => {
  it("successful report finalizes regardless of score (score is not an input)", () => {
    expect(creditDecision("complete", done())).toBe("finalize");
    expect(creditDecision.length).toBe(2);
  });
  it("in progress keeps reservation", () => expect(creditDecision("in_progress", initialState())).toBe("keep_reserved"));
  it("temporary failure keeps reservation; retry resets only that stage", () => {
    const st = failAt("marketplace", 1);
    expect(creditDecision("needs_attention", st)).toBe("keep_reserved");
    const r = resetForRetry(st);
    expect(r.reset).toEqual(["marketplace"]);
  });
  for (const stage of PIPELINE_STAGES) {
    it(`exhausted ${stage} failure releases credit`, () => {
      expect(creditDecision("needs_attention", failAt(stage, MAX_STAGE_ATTEMPTS))).toBe("release");
      expect(resetForRetry(failAt(stage, MAX_STAGE_ATTEMPTS)).reset).toEqual([]);
    });
  }
  it("customer wording", () => expect(CREDIT_POLICY_TEXT).toContain("your credit won't be lost"));
});

describe("wiring (source guards)", () => {
  const pipe = readFileSync("src/lib/nichegap/pipeline.server.ts", "utf8");
  const mig = readFileSync("drizzle/migrations/0013_phase6_3_credit_commercial_rules.sql", "utf8");
  const bill = readFileSync("src/lib/nichegap/billing.server.ts", "utf8");
  it("release on exhaustion in worker and retry; never reserve there", () => {
    expect(pipe.match(/release_research_credit", \{ _job: jobId, _reason: "permanent_failure" \}/g)?.length).toBe(2);
  });
  it("release returns same credit type, flags late period, serialized with finalize", () => {
    expect(mig).toContain("VALUES (r.user_id, 1, r.credit_type, 'research_release'");
    expect(mig.match(/pg_advisory_xact_lock/g)?.length).toBeGreaterThanOrEqual(3);
    expect(mig).toContain("'late_period', late");
  });
  it("subscription expiry expires monthly only, idempotently; no auto top-up anywhere", () => {
    expect(bill).toContain('rpc("expire_monthly_credits"');
    expect(mig).toContain("'monthly', 'monthly_expiry'");
    expect(pipe).not.toMatch(/topup_purchase|grant_research_credits/);
  });
});
