import type { ReactNode } from "react";

export function AuthShell({ title, subtitle, children }: { title: string; subtitle: string; children: ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 20 }}>
      <div className="panel" style={{ width: "100%", maxWidth: 420, padding: 28 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <img src="/nichegap-icon.png" alt="" width={32} height={32} style={{ borderRadius: 8 }} />
          <strong style={{ fontSize: 16 }}>NicheGap AI</strong>
        </div>
        <h1 style={{ margin: "0 0 6px", fontSize: 22 }}>{title}</h1>
        <p style={{ margin: "0 0 20px", color: "var(--muted)", fontSize: 13 }}>{subtitle}</p>
        {children}
      </div>
    </div>
  );
}
