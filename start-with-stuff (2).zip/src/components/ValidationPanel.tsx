// Internal-only (/lab): multi-niche validation dashboard. Server refuses non-admins.
import { Fragment, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getValidationDashboard, saveValidationReview } from "@/lib/nichegap/validation.functions";
import { VALIDATION_SET } from "@/lib/nichegap/validation/validation_v1";

const usd = (v: number | null | undefined) => (v == null ? "unknown" : `$${v.toFixed(5)}`);
const num = (v: number | null | undefined, d = 1) => (v == null ? "—" : v.toFixed(d));

export function ValidationPanel() {
  const fn = useServerFn(getValidationDashboard);
  const save = useServerFn(saveValidationReview);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["validation"], queryFn: () => fn(), retry: false });
  const [notes, setNotes] = useState<Record<string, string>>({});
  const m = useMutation({
    mutationFn: (v: { id: string; rating: "good" | "questionable" | "poor" }) => save({ data: { research_query_id: v.id, rating: v.rating, notes: notes[v.id] ?? null } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["validation"] }),
  });
  if (q.isError) return <div className="nj-card"><h3>Validation</h3><p className="nj-hint">Admin only.</p></div>;
  if (!q.data) return <div className="nj-card"><h3>Validation</h3><p className="nj-muted">Loading…</p></div>;
  const { rows, aggregate: a, benchmark_aggregate: b, exposure: x } = q.data;
  const cost = (r: (typeof rows)[number], k: "google" | "amazon" | "community" | "ai") => !r.costs ? "unknown" : r.costs[k].unknown_or_pending ? `${usd(r.costs[k].known_usd)} + unknown` : usd(r.costs[k].known_usd);
  return (
    <div className="nj-card">
      <h3>Multi-niche validation (admin)</h3>
      <p className="nj-hint">Validation jobs never use Research Credits. QA ratings never change scores. Unknown costs are shown as unknown.</p>
      <h4>Configured maximum exposure (ceilings, not expected cost)</h4>
      <p>Per report: DataForSEO {usd(x.per_report.dataforseo)} · Apify {usd(x.per_report.community)} · OpenAI {usd(x.per_report.ai)} · <strong>Total {usd(x.per_report.total)}</strong></p>
      <p>All {x.all.reports}: DataForSEO {usd(x.all.dataforseo)} · Apify {usd(x.all.community)} · OpenAI {usd(x.all.ai)}{x.all.ai_capped_by_daily ? " (capped by daily AI limit)" : ""} · <strong>Total {usd(x.all.total)}</strong></p>
      <h4>Proposed set (not run) — United States · English</h4>
      <ol>{VALIDATION_SET.map((n) => <li key={n}>{n}</li>)}</ol>
      <h4>Aggregates — validation jobs ({a.jobs}) / benchmarks ({b.jobs})</h4>
      <div style={{ overflowX: "auto" }}>
        <table className="ng-table"><thead><tr><th>Metric</th><th>Validation</th><th>Benchmarks</th></tr></thead><tbody>
          {([["Completion rate", "completion_rate", 2], ["Retry rate", "retry_rate", 2], ["Avg cost/report", "avg_cost", -1], ["Median cost", "median_cost", -1], ["Min cost", "min_cost", -1], ["Max cost", "max_cost", -1], ["Avg DataForSEO", "avg_dataforseo", -1], ["Avg community", "avg_community", -1], ["Avg AI", "avg_ai", -1], ["Avg score", "avg_score", 2], ["Avg evidence quality", "avg_evidence_quality", 1], ["Avg community quality", "avg_community_quality", 1], ["Jobs with unknown cost", "cost_unknown_jobs", 0]] as const).map(([l, k, d]) => (
            <tr key={k}><td>{l}</td>{[a, b].map((g, i) => <td key={i}>{d === -1 ? (g[k] == null ? "—" : usd(g[k] as number)) : num(g[k] as number | null, d)}</td>)}</tr>
          ))}
          <tr><td>Score distribution</td>{[a, b].map((g, i) => <td key={i}>{Object.entries(g.score_distribution).map(([k, v]) => `${k}:${v}`).join(" ")}</td>)}</tr>
        </tbody></table>
      </div>
      <h4>Jobs</h4>
      <div style={{ overflowX: "auto" }}>
        <table className="ng-table"><thead><tr>
          <th>Niche</th><th>Market</th><th>Score</th><th>Class</th><th>D/C/P/T</th><th>Conf.</th><th>Compl.</th><th>EQ</th><th>Comm. rel / quality</th><th>Google</th><th>Amazon</th><th>Community</th><th>AI</th><th>Total</th><th>Report</th><th>Retries / failed</th><th>QA</th>
        </tr></thead><tbody>
          {rows.map((r) => (
            <Fragment key={r.id}><tr>
              <td>{r.query}{r.benchmark ? " (benchmark)" : ""}</td><td>{r.target_country}/{r.language}</td>
              <td>{num(r.score, 4)}</td><td>{r.classification ?? "—"}</td>
              <td>{[r.demand, r.competition, r.purchase_intent, r.trend].map((v) => num(v, 1)).join(" / ")}</td>
              <td>{r.confidence ?? "—"}</td><td>{num(r.completeness, 0)}%</td><td>{num(r.evidence_quality, 1)}</td>
              <td>{r.community_relevant ?? "—"} / {num(r.community_quality, 2)} {r.community_confidence ?? ""}</td>
              <td>{cost(r, "google")}</td><td>{cost(r, "amazon")}</td><td>{cost(r, "community")}</td><td>{cost(r, "ai")}</td>
              <td>{!r.costs ? "unknown" : r.costs.complete ? usd(r.costs.total_known_usd) : `${usd(r.costs.total_known_usd)} + unknown`}</td>
              <td>{r.report_final ? "final" : r.status}</td><td>{r.retries} / {r.failed_stages}</td>
              <td>
                {r.review ? <strong>{r.review.rating}</strong> : "—"}
                <div className="nj-actions">{(["good", "questionable", "poor"] as const).map((g) => <button key={g} className="button button--ghost button--small" disabled={m.isPending} onClick={() => m.mutate({ id: r.id, rating: g })}>{g}</button>)}</div>
                <input aria-label="QA notes" placeholder={r.review?.notes ?? "Notes / anomalies"} value={notes[r.id] ?? ""} onChange={(e) => setNotes({ ...notes, [r.id]: e.target.value })} maxLength={4000} />
              </td>
            </tr></Fragment>
          ))}
        </tbody></table>
      </div>
    </div>
  );
}
