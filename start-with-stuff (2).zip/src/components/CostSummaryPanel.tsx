// Internal-only (/lab): per-research variable cost audit. The server refuses non-admin callers.
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getResearchCostSummary } from "@/lib/nichegap/pipeline.functions";

const usd = (n: number) => `$${n.toFixed(5)}`;

export function CostSummaryPanel({ researchQueryId }: { researchQueryId: string }) {
  const fn = useServerFn(getResearchCostSummary);
  const q = useMutation({ mutationFn: () => fn({ data: { research_query_id: researchQueryId } }) });
  const lines = q.data ? ([["Google demand", q.data.google], ["Amazon marketplace", q.data.amazon], ["Community", q.data.community], ["AI analysis", q.data.ai]] as const) : [];
  return (
    <div className="nj-card">
      <button className="button button--quiet button--small" disabled={q.isPending} onClick={() => q.mutate()}>
        {q.isPending ? "Loading costs…" : "Internal cost summary"}
      </button>
      {q.isError && <p role="alert">Cost summary unavailable (admin only).</p>}
      {q.data && (
        <table>
          <thead><tr><th>Stage</th><th>Known cost</th><th>Calls</th><th>Cache hits</th><th>Unknown/pending</th></tr></thead>
          <tbody>
            {lines.map(([label, l]) => <tr key={label}><td>{label}</td><td>{usd(l.known_usd)}</td><td>{l.calls}</td><td>{l.cache_hits}</td><td>{l.unknown_or_pending}</td></tr>)}
            <tr><td><strong>Total variable cost</strong></td><td><strong>{usd(q.data.total_known_usd)}</strong></td><td colSpan={3}>{q.data.complete ? "All costs final" : "Some costs unknown or pending — not estimated"}</td></tr>
          </tbody>
        </table>
      )}
    </div>
  );
}
