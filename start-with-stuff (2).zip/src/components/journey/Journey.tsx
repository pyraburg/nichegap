import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import type { ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { COUNTRIES, labelFor } from "@/lib/nichegap/markets";
import { CUSTOMER_STATUS_LABEL, customerStatus, type CustomerStatus } from "@/lib/nichegap/journey";
import type { JourneyJob } from "@/lib/nichegap/journey-data";

export function JourneyShell({ email, children }: { email?: string | null | undefined; children: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  async function signOut() {
    await supabase.auth.signOut();
    qc.clear();
    navigate({ to: "/auth" });
  }
  return (
    <div className="nj">
      <header className="nj-top">
        <Link to="/dashboard" className="nj-brand">
          <img src="/nichegap-icon.png" alt="" width={28} height={28} />
          <span>NicheGap</span>
        </Link>
        <nav className="nj-nav" aria-label="Main">
          <Link to="/dashboard" activeProps={{ className: "is-active" }} activeOptions={{ exact: true }}>Dashboard</Link>
          <Link to="/research" activeProps={{ className: "is-active" }} activeOptions={{ exact: true }}>My Research</Link>
          <Link to="/plan" activeProps={{ className: "is-active" }}>Plan & Credits</Link>
        </nav>
        <div className="nj-account">
          {email && <span className="nj-email">{email}</span>}
          <button className="button button--quiet button--small" onClick={signOut}>Log out</button>
        </div>
      </header>
      <main className="nj-main">{children}</main>
    </div>
  );
}

export function StatusBadge({ status }: { status: CustomerStatus }) {
  return <span className={`nj-badge nj-badge--${status}`}>{CUSTOMER_STATUS_LABEL[status]}</span>;
}

const fmtDate = (d: string) => new Date(d).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

export function JobCard({ job }: { job: JourneyJob }) {
  const st = customerStatus(job.facts);
  return (
    <li className="nj-job">
      <Link to="/research/$id" params={{ id: job.id }} className="nj-job__main">
        <div className="nj-job__title">{job.query}</div>
        <div className="nj-job__meta">{labelFor(COUNTRIES, job.target_country)} · {fmtDate(job.created_at)}</div>
      </Link>
      <div className="nj-job__score">
        {job.score?.display != null ? (
          <>
            <span className="nj-job__num">{job.score.display}</span>
            <span className="nj-job__class">{job.score.classification}</span>
          </>
        ) : <span className="nj-job__class">Score pending</span>}
      </div>
      <div className="nj-job__actions">
        <StatusBadge status={st} />
        {st === "complete" ? (
          <Link to="/research/$id/report" params={{ id: job.id }} className="button button--primary button--small">View Report</Link>
        ) : (
          <Link to="/research/$id" params={{ id: job.id }} className="button button--ghost button--small">{st === "ready_for_report" ? "Preview" : "Open"}</Link>
        )}
      </div>
    </li>
  );
}
