// Customer-visible Research Credit balance. Read server-side through get_my_credit_balance (own account only);
// shows only credit counts, never internal accounting details.
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { balanceLabel, OUT_OF_CREDITS_MESSAGE, totalCredits, type CreditBalance as Bal } from "@/lib/nichegap/credits";

export const creditBalanceQuery = {
  queryKey: ["credits", "balance"] as const,
  queryFn: async (): Promise<Bal> => {
    const { data, error } = await supabase.rpc("get_my_credit_balance");
    if (error) throw error;
    const row = (Array.isArray(data) ? data[0] : data) as { monthly?: number; purchased?: number } | null;
    return { monthly: row?.monthly ?? 0, purchased: row?.purchased ?? 0 };
  },
};

export function useCreditBalance() { return useQuery(creditBalanceQuery); }

export function CreditBalanceBadge() {
  const q = useCreditBalance();
  if (!q.data) return null;
  const l = balanceLabel(q.data);
  return (
    <div className="nj-credits" aria-live="polite">
      <strong>{l.headline}</strong>
      {l.split && <span className="nj-muted"> · {l.split}</span>}
    </div>
  );
}

export function OutOfCredits() {
  return (
    <section className="nj-card nj-attention" role="status">
      <h2 className="nj-card__title">{OUT_OF_CREDITS_MESSAGE}</h2>
      <p className="nj-muted">Each complete Opportunity Report uses 1 Research Credit. Add credits to start new research — your existing reports stay available.</p>
      <div className="nj-actions">
        <Link to="/plan" className="button button--primary button--small">Get More Credits</Link>
        <Link to="/plan" className="button button--ghost button--small">Manage Plan</Link>
      </div>
    </section>
  );
}

export const hasCredits = (b: Bal | undefined) => !!b && totalCredits(b) > 0;
