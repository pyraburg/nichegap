import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { scoreResearch } from "@/lib/nichegap/scoring.functions";
import type { ScoreResult, Component } from "@/lib/nichegap/scoring/score_v1";

const LABELS: Array<[keyof ScoreResult["components"], string]> = [
  ["demand", "Demand"], ["competition", "Competition Opportunity"],
  ["purchase_intent", "Purchase Intent"], ["trend", "Trend"],
];

function Row({ label, c }: { label: string; c: Component }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{ padding: "8px 0", borderTop: "1px solid var(--line, rgba(255,255,255,0.08))" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
        <span style={{ fontSize: 13 }}>{label} <span style={{ color: "var(--muted)", fontSize: 11 }}>· {Math.round(c.weight * 100)}%</span></span>
        <span style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {c.confidence && <span style={{ color: "var(--muted)", fontSize: 11 }}>confidence: {c.confidence}</span>}
          <strong style={{ fontSize: 13 }}>{c.status === "ok" && c.score !== null ? `${Math.round(c.score)} / 100` : "Insufficient data"}</strong>
          <button className="button button--quiet button--small" onClick={() => setOpen(!open)}>{open ? "Hide" : "Why this score?"}</button>
        </span>
      </div>
      {open && (
        <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 6 }}>
          <p style={{ margin: "0 0 4px" }}>{c.explanation.text}</p>
          {c.sub_scores && (
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {Object.entries(c.sub_scores).map(([k, s]) => (
                <li key={k}>{k.replace(/_/g, " ")}: {s.score === null ? "unavailable (reweighted)" : `${Math.round(s.score)} / 100`} · weight {Math.round(s.effective_weight * 100)}%</li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}

export function ScoreBreakdown({ researchQueryId }: { researchQueryId: string }) {
  const qc = useQueryClient();
  const scoreFn = useServerFn(scoreResearch);
  const q = useQuery({
    queryKey: ["opportunity_score", researchQueryId],
    queryFn: async () => {
      const { data, error } = await supabase.from("opportunities")
        .select("score_breakdown, scored_at, score_version")
        .eq("research_query_id", researchQueryId)
        .order("scored_at", { ascending: false, nullsFirst: false }).limit(1).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const calc = useMutation({
    mutationFn: (v?: "score_v1" | "score_v1_1") => scoreFn({ data: { research_query_id: researchQueryId, score_version: v } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["opportunity_score", researchQueryId] }),
  });
  if (q.isLoading) return <p style={{ fontSize: 13, color: "var(--muted)" }}>Loading score…</p>;
  const r = q.data?.score_breakdown as unknown as ScoreResult | null;
  if (!r) {
    return (
      <div style={{ padding: "6px 0 12px" }}>
        <h3 style={{ fontSize: 13, margin: "0 0 6px" }}>Score breakdown</h3>
        <button className="button button--quiet button--small" disabled={calc.isPending} onClick={() => calc.mutate(undefined)}>
          {calc.isPending ? "Scoring…" : "Calculate score"}
        </button>
        {calc.error && <p style={{ fontSize: 12, color: "#ff9aaa" }}>{calc.error.message}</p>}
      </div>
    );
  }
  return (
    <div className="panel" style={{ margin: "6px 0 14px", padding: "14px 16px" }}>
      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: 8, alignItems: "baseline" }}>
        <h3 style={{ fontSize: 13, margin: 0 }}>Opportunity Score</h3>
        <span style={{ fontSize: 11, color: "var(--muted)", display: "flex", gap: 8, alignItems: "center" }}>
          Score model: {r.score_version}
          {r.score_version !== "score_v1_1" && (
            <button className="button button--quiet button--small" disabled={calc.isPending} onClick={() => calc.mutate("score_v1_1")}>
              {calc.isPending ? "Scoring…" : "Rescore with score_v1_1"}
            </button>
          )}
        </span>
      </div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 16, alignItems: "baseline", margin: "6px 0 8px" }}>
        <strong style={{ fontSize: 26 }}>{r.opportunity_score_display ?? "Insufficient data"}</strong>
        <span style={{ fontSize: 13 }}>{r.classification}</span>
        <span style={{ fontSize: 12, color: "var(--muted)" }}>Confidence: {r.confidence} · Evidence completeness {Math.round(r.evidence_completeness_percent)}%{typeof r.evidence_quality_score === "number" ? ` · Evidence quality ${Math.round(r.evidence_quality_score)}/100` : ""}</span>
      </div>
      {LABELS.map(([k, label]) => <Row key={k} label={label} c={r.components[k]} />)}
      <p style={{ fontSize: 11, color: "var(--muted)", margin: "8px 0 0" }}>
        Scores describe the collected evidence; they are not a guarantee of product success.
      </p>
    </div>
  );
}
