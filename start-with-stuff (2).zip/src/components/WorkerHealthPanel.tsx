// Internal-only (/lab): background worker health. Server refuses non-admins.
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getWorkerHealth } from "@/lib/nichegap/pipeline.functions";

const LABEL: Record<string, string> = {
  healthy_active: "Healthy — processing", healthy_idle: "Healthy — idle (no work waiting)",
  stopped: "STOPPED — work is waiting but the worker is not running", erroring: "ERRORING", scheduler_disabled: "Scheduler disabled",
};
const t = (v: string | null | undefined) => (v ? new Date(v).toLocaleString() : "never");
const age = (v: string | null | undefined) => (v ? `${Math.round((Date.now() - Date.parse(v)) / 60000)} min` : "—");

export function WorkerHealthPanel() {
  const fn = useServerFn(getWorkerHealth);
  const q = useQuery({ queryKey: ["worker-health"], queryFn: () => fn(), retry: false, refetchInterval: 60_000 });
  if (q.isError) return <div className="nj-card"><h3>Background worker</h3><p className="nj-hint">Admin only.</p></div>;
  if (!q.data) return <div className="nj-card"><h3>Background worker</h3><p className="nj-muted">Loading…</p></div>;
  const h = q.data;
  return (
    <div className="nj-card">
      <h3>Background worker: {LABEL[h.state] ?? h.state}</h3>
      {h.reasons.length > 0 && <ul>{h.reasons.map((r) => <li key={r} className="nj-error">{r}</li>)}</ul>}
      <table className="ng-table"><tbody>
        <tr><td>Last successful run</td><td>{t(h.heartbeat?.last_success_at)}</td></tr>
        <tr><td>Last worker error</td><td>{h.heartbeat?.last_error_at ? `${t(h.heartbeat.last_error_at)} — ${h.heartbeat.last_error}` : "none"}</td></tr>
        <tr><td>Last scheduler call</td><td>{h.last_scheduler_http ? `${h.last_scheduler_http.status ?? "no response"} at ${t(h.last_scheduler_http.at)}` : "none"} · failures (1h): {h.scheduler_http_failures_1h}</td></tr>
        <tr><td>Queued (not started) jobs</td><td>{h.queued_jobs}</td></tr>
        <tr><td>Processing jobs</td><td>{h.processing_jobs} · oldest {age(h.oldest_processing_started_at)}</td></tr>
        <tr><td>Stale job locks / provider locks</td><td>{h.stale_locks} / {h.stale_fetch_locks}</td></tr>
        <tr><td>Jobs needing attention</td><td>{h.needs_attention_jobs}</td></tr>
        <tr><td>Pending provider costs</td><td>{h.pending_provider_costs}</td></tr>
      </tbody></table>
    </div>
  );
}
