// Internal-only (/lab): grant test Research Credits. The server refuses non-admins; every grant is a ledger entry.
import { useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { grantTestCredits } from "@/lib/nichegap/credits.functions";

export function AdminCreditGrant() {
  const fn = useServerFn(grantTestCredits);
  const qc = useQueryClient();
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState(5);
  const [type, setType] = useState<"monthly" | "purchased">("purchased");
  const rid = useRef<string | null>(null);
  const m = useMutation({
    mutationFn: () => { rid.current ??= crypto.randomUUID(); return fn({ data: { request_id: rid.current, amount, credit_type: type, ...(email.trim() ? { email: email.trim() } : {}) } }); },
    onSuccess: () => { rid.current = null; qc.invalidateQueries({ queryKey: ["credits"] }); },
  });
  return (
    <div className="nj-card">
      <h3>Grant test Research Credits (admin)</h3>
      <div className="nj-form__row">
        <input aria-label="Account email (blank = me)" placeholder="Account email (blank = me)" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255} />
        <input aria-label="Amount" type="number" min={1} max={100} value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
        <select aria-label="Credit type" className="ng-select" value={type} onChange={(e) => setType(e.target.value as "monthly" | "purchased")}>
          <option value="purchased">Purchased</option><option value="monthly">Monthly</option>
        </select>
        <button className="button button--primary button--small" disabled={m.isPending} onClick={() => m.mutate()}>{m.isPending ? "Granting…" : "Grant"}</button>
      </div>
      {m.isError && <p role="alert" className="nj-error">Grant failed (admin only).</p>}
      {m.data && <p className="nj-hint">Result: {m.data.status}</p>}
    </div>
  );
}
