import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { runCommunityTest } from "@/lib/nichegap/community.functions";

// Controlled Phase 4A test: one fixed Reddit search via Apify. Does not affect scores or reports.
export function CommunityTestPanel({ researchQueryId }: { researchQueryId: string }) {
  const fn = useServerFn(runCommunityTest);
  const m = useMutation({ mutationFn: () => fn({ data: { research_query_id: researchQueryId } }) });
  const s = m.data?.summary as Record<string, unknown> | null | undefined;
  return (
    <div style={{ padding: "6px 0 16px" }}>
      <h3 style={{ fontSize: 13, margin: "12px 0 6px" }}>Community evidence (controlled test)</h3>
      <p style={{ fontSize: 11, color: "var(--muted)", margin: "0 0 8px" }}>
        Runs one fixed Reddit search ("indoor herb gardening", past year, 10 posts, 20 comments each) through Apify. Results are stored for audit only and do not change any score.
      </p>
      <button className="button button--quiet button--small" disabled={m.isPending} onClick={() => m.mutate()}>
        {m.isPending ? "Running (up to ~3 min)…" : "Run community test"}
      </button>
      {m.error && <p style={{ fontSize: 12, color: "var(--destructive)" }}>{m.error.message}</p>}
      {s && (
        <p style={{ fontSize: 12, marginTop: 8 }}>
          {m.data?.cache_hit ? "Reused cached result (no charge). " : ""}
          Status: {String(s["run_status"] ?? "—")} · Posts: {String(s["posts"] ?? "—")} · Comments: {String(s["comments"] ?? "—")} · Cost: {typeof s["cost_usd"] === "number" ? `$${(s["cost_usd"] as number).toFixed(4)} (intermediate; final cost settles later)` : "not reported"}
        </p>
      )}
    </div>
  );
}
