export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      ai_analyses: {
        Row: {
          analysis_version: string
          completed_at: string | null
          created_at: string
          error_message: string | null
          evidence_packet: Json | null
          evidence_packet_hash: string
          id: string
          model: string
          packet_version: string
          provider: string
          raw_output: Json | null
          research_query_id: string
          status: string
          user_id: string
          validated_output: Json | null
          validation_report: Json | null
        }
        Insert: {
          analysis_version: string
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          evidence_packet?: Json | null
          evidence_packet_hash: string
          id?: string
          model: string
          packet_version: string
          provider: string
          raw_output?: Json | null
          research_query_id: string
          status?: string
          user_id: string
          validated_output?: Json | null
          validation_report?: Json | null
        }
        Update: {
          analysis_version?: string
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          evidence_packet?: Json | null
          evidence_packet_hash?: string
          id?: string
          model?: string
          packet_version?: string
          provider?: string
          raw_output?: Json | null
          research_query_id?: string
          status?: string
          user_id?: string
          validated_output?: Json | null
          validation_report?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_analyses_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_usage: {
        Row: {
          ai_analysis_id: string | null
          analysis_version: string
          cached_input_tokens: number | null
          completed_at: string | null
          cost_status: string
          cost_usd: number | null
          created_at: string
          evidence_packet_hash: string
          id: string
          input_tokens: number | null
          model: string
          output_tokens: number | null
          provider: string
          request_id: string | null
          research_query_id: string | null
          status: string
          user_id: string | null
        }
        Insert: {
          ai_analysis_id?: string | null
          analysis_version: string
          cached_input_tokens?: number | null
          completed_at?: string | null
          cost_status?: string
          cost_usd?: number | null
          created_at?: string
          evidence_packet_hash: string
          id?: string
          input_tokens?: number | null
          model: string
          output_tokens?: number | null
          provider: string
          request_id?: string | null
          research_query_id?: string | null
          status: string
          user_id?: string | null
        }
        Update: {
          ai_analysis_id?: string | null
          analysis_version?: string
          cached_input_tokens?: number | null
          completed_at?: string | null
          cost_status?: string
          cost_usd?: number | null
          created_at?: string
          evidence_packet_hash?: string
          id?: string
          input_tokens?: number | null
          model?: string
          output_tokens?: number | null
          provider?: string
          request_id?: string | null
          research_query_id?: string | null
          status?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_usage_ai_analysis_id_fkey"
            columns: ["ai_analysis_id"]
            isOneToOne: false
            referencedRelation: "ai_analyses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ai_usage_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      billing_subscriptions: {
        Row: {
          cancelled: boolean
          created_at: string
          ends_at: string | null
          id: string
          provider: string
          provider_customer_id: string | null
          provider_subscription_id: string
          renews_at: string | null
          status: string
          test_mode: boolean
          updated_at: string
          user_id: string
          variant_id: string | null
        }
        Insert: {
          cancelled?: boolean
          created_at?: string
          ends_at?: string | null
          id?: string
          provider?: string
          provider_customer_id?: string | null
          provider_subscription_id: string
          renews_at?: string | null
          status: string
          test_mode?: boolean
          updated_at?: string
          user_id: string
          variant_id?: string | null
        }
        Update: {
          cancelled?: boolean
          created_at?: string
          ends_at?: string | null
          id?: string
          provider?: string
          provider_customer_id?: string | null
          provider_subscription_id?: string
          renews_at?: string | null
          status?: string
          test_mode?: boolean
          updated_at?: string
          user_id?: string
          variant_id?: string | null
        }
        Relationships: []
      }
      billing_webhook_events: {
        Row: {
          event_key: string
          event_name: string
          id: string
          outcome: string
          received_at: string
          test_mode: boolean | null
          user_id: string | null
        }
        Insert: {
          event_key: string
          event_name: string
          id?: string
          outcome: string
          received_at?: string
          test_mode?: boolean | null
          user_id?: string | null
        }
        Update: {
          event_key?: string
          event_name?: string
          id?: string
          outcome?: string
          received_at?: string
          test_mode?: boolean | null
          user_id?: string | null
        }
        Relationships: []
      }
      credit_ledger: {
        Row: {
          amount: number
          created_at: string
          credit_type: string
          event_type: string
          id: string
          idempotency_key: string
          metadata: Json
          research_query_id: string | null
          reservation_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          credit_type: string
          event_type: string
          id?: string
          idempotency_key: string
          metadata?: Json
          research_query_id?: string | null
          reservation_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          credit_type?: string
          event_type?: string
          id?: string
          idempotency_key?: string
          metadata?: Json
          research_query_id?: string | null
          reservation_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_ledger_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      credit_reservations: {
        Row: {
          amount: number
          created_at: string
          credit_type: string
          finalized_at: string | null
          id: string
          idempotency_key: string
          released_at: string | null
          research_query_id: string
          status: string
          user_id: string
        }
        Insert: {
          amount?: number
          created_at?: string
          credit_type: string
          finalized_at?: string | null
          id?: string
          idempotency_key: string
          released_at?: string | null
          research_query_id: string
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          credit_type?: string
          finalized_at?: string | null
          id?: string
          idempotency_key?: string
          released_at?: string | null
          research_query_id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "credit_reservations_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: true
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      external_api_usage: {
        Row: {
          cache_hit: boolean
          cost: number | null
          cost_finalized_at: string | null
          cost_source: string | null
          cost_status: string
          created_at: string
          currency: string
          endpoint: string
          id: string
          intermediate_cost: number | null
          provider: string
          provider_run_id: string | null
          reconcile_attempts: number
          research_query_id: string | null
          status: string
          user_id: string | null
        }
        Insert: {
          cache_hit?: boolean
          cost?: number | null
          cost_finalized_at?: string | null
          cost_source?: string | null
          cost_status?: string
          created_at?: string
          currency?: string
          endpoint: string
          id?: string
          intermediate_cost?: number | null
          provider: string
          provider_run_id?: string | null
          reconcile_attempts?: number
          research_query_id?: string | null
          status: string
          user_id?: string | null
        }
        Update: {
          cache_hit?: boolean
          cost?: number | null
          cost_finalized_at?: string | null
          cost_source?: string | null
          cost_status?: string
          created_at?: string
          currency?: string
          endpoint?: string
          id?: string
          intermediate_cost?: number | null
          provider?: string
          provider_run_id?: string | null
          reconcile_attempts?: number
          research_query_id?: string | null
          status?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "external_api_usage_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      internal_worker_tokens: {
        Row: {
          created_at: string
          name: string
          token: string
        }
        Insert: {
          created_at?: string
          name: string
          token: string
        }
        Update: {
          created_at?: string
          name?: string
          token?: string
        }
        Relationships: []
      }
      opportunities: {
        Row: {
          competition_opportunity_score: number | null
          created_at: string
          demand_score: number | null
          description: string | null
          evidence_completeness_percent: number | null
          evidence_hash: string | null
          id: string
          opportunity_score: number | null
          purchase_intent_score: number | null
          research_query_id: string
          score_breakdown: Json | null
          score_classification: string | null
          score_confidence: string | null
          score_version: string | null
          scored_at: string | null
          title: string | null
          trend_score: number | null
        }
        Insert: {
          competition_opportunity_score?: number | null
          created_at?: string
          demand_score?: number | null
          description?: string | null
          evidence_completeness_percent?: number | null
          evidence_hash?: string | null
          id?: string
          opportunity_score?: number | null
          purchase_intent_score?: number | null
          research_query_id: string
          score_breakdown?: Json | null
          score_classification?: string | null
          score_confidence?: string | null
          score_version?: string | null
          scored_at?: string | null
          title?: string | null
          trend_score?: number | null
        }
        Update: {
          competition_opportunity_score?: number | null
          created_at?: string
          demand_score?: number | null
          description?: string | null
          evidence_completeness_percent?: number | null
          evidence_hash?: string | null
          id?: string
          opportunity_score?: number | null
          purchase_intent_score?: number | null
          research_query_id?: string
          score_breakdown?: Json | null
          score_classification?: string | null
          score_confidence?: string | null
          score_version?: string | null
          scored_at?: string | null
          title?: string | null
          trend_score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "opportunities_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      pipeline_worker_heartbeats: {
        Row: {
          last_error: string | null
          last_error_at: string | null
          last_jobs: number | null
          last_started_at: string | null
          last_success_at: string | null
          name: string
          updated_at: string
        }
        Insert: {
          last_error?: string | null
          last_error_at?: string | null
          last_jobs?: number | null
          last_started_at?: string | null
          last_success_at?: string | null
          name: string
          updated_at?: string
        }
        Update: {
          last_error?: string | null
          last_error_at?: string | null
          last_jobs?: number | null
          last_started_at?: string | null
          last_success_at?: string | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      provider_fetch_locks: {
        Row: {
          cache_key: string
          claimed_at: string
          holder_job: string
          lease_token: string
          lease_until: string
        }
        Insert: {
          cache_key: string
          claimed_at?: string
          holder_job: string
          lease_token: string
          lease_until: string
        }
        Update: {
          cache_key?: string
          claimed_at?: string
          holder_job?: string
          lease_token?: string
          lease_until?: string
        }
        Relationships: []
      }
      reports: {
        Row: {
          created_at: string
          finalized_at: string | null
          generated_at: string | null
          id: string
          opportunity_id: string | null
          report_data: Json | null
          report_version: string | null
          research_query_id: string
          score_run_id: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          finalized_at?: string | null
          generated_at?: string | null
          id?: string
          opportunity_id?: string | null
          report_data?: Json | null
          report_version?: string | null
          research_query_id: string
          score_run_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          finalized_at?: string | null
          generated_at?: string | null
          id?: string
          opportunity_id?: string | null
          report_data?: Json | null
          report_version?: string | null
          research_query_id?: string
          score_run_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reports_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reports_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reports_score_run_id_fkey"
            columns: ["score_run_id"]
            isOneToOne: false
            referencedRelation: "score_runs"
            referencedColumns: ["id"]
          },
        ]
      }
      research_data: {
        Row: {
          cache_hit: boolean
          collected_at: string
          created_at: string
          data_type: string
          expires_at: string | null
          id: string
          language: string | null
          normalized_query: string | null
          processed_data: Json | null
          provider: string
          raw_data: Json | null
          research_query_id: string
          source_query: string | null
          target_country: string | null
        }
        Insert: {
          cache_hit?: boolean
          collected_at?: string
          created_at?: string
          data_type: string
          expires_at?: string | null
          id?: string
          language?: string | null
          normalized_query?: string | null
          processed_data?: Json | null
          provider: string
          raw_data?: Json | null
          research_query_id: string
          source_query?: string | null
          target_country?: string | null
        }
        Update: {
          cache_hit?: boolean
          collected_at?: string
          created_at?: string
          data_type?: string
          expires_at?: string | null
          id?: string
          language?: string | null
          normalized_query?: string | null
          processed_data?: Json | null
          provider?: string
          raw_data?: Json | null
          research_query_id?: string
          source_query?: string | null
          target_country?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "research_data_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      research_queries: {
        Row: {
          billing: string
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          language: string
          pipeline_lease_token: string | null
          pipeline_lease_until: string | null
          pipeline_state: Json
          pipeline_version: string | null
          query: string
          stage: string
          started_at: string | null
          status: string
          target_country: string
          user_id: string
        }
        Insert: {
          billing?: string
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          language?: string
          pipeline_lease_token?: string | null
          pipeline_lease_until?: string | null
          pipeline_state?: Json
          pipeline_version?: string | null
          query: string
          stage?: string
          started_at?: string | null
          status?: string
          target_country?: string
          user_id: string
        }
        Update: {
          billing?: string
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          language?: string
          pipeline_lease_token?: string | null
          pipeline_lease_until?: string | null
          pipeline_state?: Json
          pipeline_version?: string | null
          query?: string
          stage?: string
          started_at?: string | null
          status?: string
          target_country?: string
          user_id?: string
        }
        Relationships: []
      }
      score_runs: {
        Row: {
          created_at: string
          evidence_hash: string
          evidence_research_data_ids: string[]
          id: string
          opportunity_id: string | null
          research_query_id: string
          result: Json
          score_version: string
        }
        Insert: {
          created_at?: string
          evidence_hash: string
          evidence_research_data_ids: string[]
          id?: string
          opportunity_id?: string | null
          research_query_id: string
          result: Json
          score_version: string
        }
        Update: {
          created_at?: string
          evidence_hash?: string
          evidence_research_data_ids?: string[]
          id?: string
          opportunity_id?: string | null
          research_query_id?: string
          result?: Json
          score_version?: string
        }
        Relationships: [
          {
            foreignKeyName: "score_runs_opportunity_id_fkey"
            columns: ["opportunity_id"]
            isOneToOne: false
            referencedRelation: "opportunities"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "score_runs_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: false
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      validation_reviews: {
        Row: {
          created_at: string
          notes: string | null
          rating: string
          research_query_id: string
          reviewer_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          notes?: string | null
          rating: string
          research_query_id: string
          reviewer_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          notes?: string | null
          rating?: string
          research_query_id?: string
          reviewer_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "validation_reviews_research_query_id_fkey"
            columns: ["research_query_id"]
            isOneToOne: true
            referencedRelation: "research_queries"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      allocate_monthly_credits: {
        Args: { _amount: number; _period_key: string; _user: string }
        Returns: Json
      }
      claim_provider_fetch: {
        Args: { _job: string; _key: string; _ttl_seconds: number }
        Returns: string
      }
      credit_balance: {
        Args: { _user: string }
        Returns: {
          monthly: number
          purchased: number
        }[]
      }
      expire_monthly_credits: {
        Args: { _key: string; _user: string }
        Returns: Json
      }
      finalize_research_credit: { Args: { _job: string }; Returns: Json }
      get_my_credit_balance: {
        Args: never
        Returns: {
          monthly: number
          purchased: number
        }[]
      }
      get_my_plan: {
        Args: never
        Returns: {
          cancelled: boolean
          ends_at: string
          renews_at: string
          status: string
        }[]
      }
      grant_research_credits: {
        Args: {
          _amount: number
          _event: string
          _key: string
          _metadata?: Json
          _type: string
          _user: string
        }
        Returns: Json
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      owns_research_query: { Args: { _query_id: string }; Returns: boolean }
      pipeline_worker_health: { Args: never; Returns: Json }
      release_provider_fetch: {
        Args: { _key: string; _token: string }
        Returns: boolean
      }
      release_research_credit: {
        Args: { _job: string; _reason: string }
        Returns: Json
      }
      reserve_research_credit: {
        Args: { _job: string; _key: string; _user: string }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
