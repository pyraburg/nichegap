import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { JobCard, JourneyShell } from "@/components/journey/Journey";
import { fetchJourneyJobs } from "@/lib/nichegap/journey-data";

export const Route = createFileRoute("/_authenticated/research")({
  head: () => ({
    meta: [
      { title: "My Research — NicheGap" },
      { name: "description", content: "All of your NicheGap niche research and Opportunity Reports in one place." },
      { property: "og:title", content: "My Research — NicheGap" },
      { property: "og:description", content: "All of your NicheGap niche research and Opportunity Reports in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Library,
});

function Library() {
  const { user } = Route.useRouteContext();
  const jobs = useQuery({ queryKey: ["journey", "all"], queryFn: () => fetchJourneyJobs() });
  return (
    <JourneyShell email={user.email}>
      <div className="nj-section__head nj-section__head--page">
        <div>
          <h1 className="nj-h2">My Research</h1>
          <p className="nj-muted">Every niche you've researched. Only you can see these.</p>
        </div>
        <Link to="/research/new" className="button button--primary button--small">Start New Research</Link>
      </div>
      {jobs.isLoading ? <p className="nj-muted">Loading your research…</p>
        : jobs.error ? <p className="nj-muted">We couldn't load your research just now. Please refresh the page.</p>
        : !jobs.data?.length ? (
          <div className="nj-empty">
            <h3>No research yet</h3>
            <p className="nj-muted">Your research will appear here once you start.</p>
            <Link to="/research/new" className="button button--primary button--small">Research a Niche</Link>
          </div>
        ) : <ul className="nj-jobs">{jobs.data.map((j) => <JobCard key={j.id} job={j} />)}</ul>}
    </JourneyShell>
  );
}
