import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { generateReport } from "@/lib/nichegap/report.functions";
import { COUNTRIES, LANGUAGES, labelFor } from "@/lib/nichegap/markets";
import type { ReportSnapshot } from "@/lib/nichegap/report/report_v1";
import type { ReportSnapshotV2 } from "@/lib/nichegap/report/report_v2";
import type { AiSection as AiSectionData, ResolvedEvidence } from "@/lib/nichegap/report/report_v3";
import { band, COMPONENT_COPY, reportToc, scoreDisplay, strongestHypothesis } from "@/lib/nichegap/report/present";

export const Route = createFileRoute("/_authenticated/research_/$id/report")({
  head: () => ({
    meta: [
      { title: "Opportunity Report — NicheGap AI" },
      { name: "description", content: "Evidence-based opportunity report built from real Google and Amazon market data." },
      { property: "og:title", content: "Opportunity Report — NicheGap AI" },
      { property: "og:description", content: "Evidence-based opportunity report built from real Google and Amazon market data." },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { print?: boolean } => (s["print"] === true || s["print"] === "true" ? { print: true } : {}),
  component: ReportPage,
});

const cap = (s: string | null | undefined) => (s ? s.charAt(0).toUpperCase() + s.slice(1).replace(/_/g, " ") : "—");
const n = (v: unknown, d = 0) => (typeof v === "number" ? v.toLocaleString("en-US", { maximumFractionDigits: d }) : "Unknown");
const pct = (v: unknown) => (typeof v === "number" ? `${Math.round(v * 100)}%` : "Unknown");
const money = (v: unknown, c: string | null) => (typeof v === "number" ? `${c === "USD" || !c ? "$" : `${c} `}${v.toFixed(2)}` : "Unknown");
const date = (v: string | null | undefined) => (v ? new Date(v).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) : "—");

function ReportPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const gen = useServerFn(generateReport);
  const [genError, setGenError] = useState<string | null>(null);
  const started = useRef(false);

  const job = useQuery({
    queryKey: ["report_job", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("research_queries").select("id, status, query").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const report = useQuery({
    queryKey: ["report", id],
    enabled: job.data?.status === "completed",
    queryFn: async () => {
      const { data, error } = await supabase.from("reports").select("id, report_data, generated_at, status")
        .eq("research_query_id", id).eq("status", "final").order("generated_at", { ascending: false, nullsFirst: false }).limit(1).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    // Always ask the server once: it reuses an up-to-date snapshot or builds a newer one (e.g. new evidence).
    if (job.data?.status !== "completed" || report.isLoading || started.current) return;
    started.current = true;
    gen({ data: { research_query_id: id } })
      .then(() => qc.invalidateQueries({ queryKey: ["report", id] }))
      .catch((e: unknown) => setGenError(e instanceof Error ? e.message : "Report could not be generated."));
  }, [job.data?.status, report.isLoading, report.data, id, gen, qc]);

  const { print } = Route.useSearch();
  const printed = useRef(false);
  const ready = !!report.data?.report_data;
  useEffect(() => {
    if (print && ready && !printed.current) { printed.current = true; setTimeout(() => window.print(), 400); }
  }, [print, ready]);
  const back = <Link to="/research/$id" params={{ id }} className="button button--quiet button--small no-print">← Back to research</Link>;
  if (job.isLoading) return <Shell>{back}<p className="rp-muted">Loading…</p></Shell>;
  if (!job.data) return <Shell>{back}<h1 className="rp-title">Report not found</h1><p className="rp-muted">This research job does not exist or belongs to another account.</p></Shell>;
  if (job.data.status !== "completed") return <Shell>{back}<h1 className="rp-title">{job.data.query}</h1><p className="rp-muted">This research is {job.data.status}. A report becomes available once research completes.</p></Shell>;
  if (genError && !report.data) return <Shell>{back}<p className="rp-muted">{genError}</p></Shell>;
  const s = report.data?.report_data as unknown as ReportSnapshot | undefined;
  if (!s) return <Shell>{back}<p className="rp-muted">Preparing your report…</p></Shell>;
  return <Shell><ReportView s={s} back={back} /></Shell>;
}

function Shell({ children }: { children: ReactNode }) {
  return <div className="rp">{children}</div>;
}
function Card({ title, tag, id, children }: { title: string; tag?: "data" | "calc" | "ai"; id?: string; children: ReactNode }) {
  return (
    <section className="panel rp-card" id={id}>
      <div className="rp-card__head">
        <h2>{title}</h2>
        {tag && <span className={`rp-tag rp-tag--${tag}`}>{tag === "data" ? "Real market data" : tag === "ai" ? "AI analysis" : "NicheGap calculation"}</span>}
      </div>
      {children}
    </section>
  );
}
function Stat({ label, value, tag }: { label: string; value: ReactNode; tag?: "data" | "calc" }) {
  return (
    <div className={`rp-stat ${tag ? `rp-stat--${tag}` : ""}`}>
      <div className="rp-stat__label">{label}</div>
      <div className="rp-stat__value">{value}</div>
    </div>
  );
}

function Part({ id, title, children }: { id: string; title: string; children: ReactNode }) {
  return (
    <div className="rp-part" id={id}>
      <h2 className="rp-part__title">{title}</h2>
      {children}
    </div>
  );
}

export function ReportToc({ hasAi }: { hasAi: boolean }) {
  const items = reportToc(hasAi);
  return (
    <nav className="rp-toc no-print" aria-label="Report sections">
      <details className="rp-toc__mobile">
        <summary>Jump to section</summary>
        <ul>{items.map((t) => <li key={t.id}><a href={`#${t.id}`} onClick={(e) => e.currentTarget.closest("details")?.removeAttribute("open")}>{t.label}</a></li>)}</ul>
      </details>
      <ul className="rp-toc__desktop">{items.map((t) => <li key={t.id}><a href={`#${t.id}`}>{t.label}</a></li>)}</ul>
    </nav>
  );
}

export function Snapshot({ s, ai }: { s: ReportSnapshot; ai: AiSectionData | null }) {
  const sc = s.score;
  const c = (s as Partial<ReportSnapshotV2>).community;
  const top = strongestHypothesis(ai?.hypotheses);
  const comp = (k: "demand" | "competition" | "purchase_intent" | "trend") => sc.components[k].status === "ok" ? sc.components[k].score : null;
  const cConf = c && c.status !== "missing" ? cap(c.metrics.confidence) : "Not included";
  return (
    <section className="panel rp-card rp-snapshot" aria-label="Executive Opportunity Snapshot">
      <div className="rp-card__head"><h2>Executive Opportunity Snapshot</h2><span className="rp-tag rp-tag--calc">NicheGap calculation</span></div>
      <div className="rp-snap-grid">
        <Stat label="Search demand" value={band(comp("demand"))} tag="calc" />
        <Stat label="Competition opportunity" value={band(comp("competition"), "competition")} tag="calc" />
        <Stat label="Purchase intent" value={band(comp("purchase_intent"))} tag="calc" />
        <Stat label="Trend" value={band(comp("trend"))} tag="calc" />
        <Stat label="Score confidence" value={cap(sc.confidence)} tag="calc" />
        <Stat label="Community evidence" value={cConf} tag="calc" />
      </div>
      <ul className="rp-snap-facts">
        {s.demand.primary_keyword && <li><strong>Strongest demand:</strong> “{s.demand.primary_keyword}”{typeof s.demand.clusters[0]?.monthly_search_volume === "number" ? ` — about ${n(s.demand.clusters[0]!.monthly_search_volume)} searches a month` : ""} <span className="rp-tag rp-tag--data">Real market data</span></li>}
        <li><strong>Competition:</strong> {band(comp("competition"), "competition")} — median {n(s.marketplace.median_review_count)} reviews and {s.marketplace.median_rating != null ? `${s.marketplace.median_rating.toFixed(1)}★` : "unknown"} rating across {n(s.marketplace.relevant_products_analyzed)} relevant products <span className="rp-tag rp-tag--data">Real market data</span></li>
        {ai && ai.problems.length > 0 && <li><strong>Main customer problems:</strong> {ai.problems.map((p) => p.title).join("; ")} <span className="rp-tag rp-tag--ai">AI analysis</span></li>}
      </ul>
      {ai?.executive_summary.text && <p className="rp-summary">{ai.executive_summary.text} <span className="rp-tag rp-tag--ai">AI analysis</span></p>}
      {top && (
        <div className="rp-validate">
          <div className="rp-validate__label">Opportunity to Validate <span className="rp-tag rp-tag--ai">AI analysis</span></div>
          <div className="rp-validate__title">{top.hypothesis}</div>
          <p className="rp-small">{top.rationale}</p>
          <div className="rp-small rp-muted">{cap(top.confidence)} confidence · {top.evidence_count} supporting evidence items · An evidence-grounded hypothesis to test, not a guaranteed business opportunity.</div>
          <a href="#opportunities" className="rp-jump no-print">See all {ai!.hypotheses.length} opportunity hypotheses →</a>
        </div>
      )}
    </section>
  );
}

function Methodology({ hasAi }: { hasAi: boolean }) {
  return (
    <Card title="How NicheGap researched this opportunity">
      <ol className="rp-list rp-small">
        <li>Examined how many people search for this niche and related terms each month.</li>
        <li>Examined the marketplace: relevant competing products, prices, ratings and reviews.</li>
        <li>Analysed public customer discussions for problem, help-seeking and buying language.</li>
        <li>Calculated the NicheGap Opportunity Score with a fixed, transparent formula.</li>
        {hasAi && <li>Used AI to interpret the collected evidence. Every AI finding must cite stored evidence and is checked by NicheGap.</li>}
      </ol>
      <p className="rp-fine">Measured market data, the NicheGap calculation and AI interpretation are kept separate and labelled throughout. AI never changes the Opportunity Score.</p>
    </Card>
  );
}

function ReportView({ s, back }: { s: ReportSnapshot; back: ReactNode }) {
  const ai = (s as { ai?: AiSectionData | null }).ai ?? null;
  const sc = s.score;
  const comps = (["demand", "competition", "purchase_intent", "trend"] as const).map((k) => ({ ...sc.components[k], key: k }));
  const m = s.marketplace;
  return (
    <>
      <div className="rp-actions no-print">
        {back}
        <button className="button button--ghost button--small" onClick={() => window.print()}>Print / Save as PDF</button>
      </div>

      <header className="panel rp-card rp-header">
        <div className="rp-eyebrow">NicheGap Opportunity Report</div>
        <h1 className="rp-title">{cap(s.research.query)}</h1>
        <p className="rp-muted">{labelFor(COUNTRIES, s.research.target_country)} · {labelFor(LANGUAGES, s.research.language)} · Researched {date(s.research.research_date)}</p>
        <div className="rp-hero">
          <div>
            <div className="rp-stat__label">Opportunity Score</div>
            {sc.sufficient ? (
              <div className="rp-score">{scoreDisplay(sc.opportunity_score)}<span> / 100</span></div>
            ) : (
              <div className="rp-score rp-score--na">Insufficient data</div>
            )}
            <div className="rp-class">{sc.sufficient ? sc.classification : "Insufficient evidence to calculate a reliable Opportunity Score."}</div>
          </div>
          <div className="rp-grid rp-grid--3">
            <Stat label="Confidence" value={cap(sc.confidence)} tag="calc" />
            <Stat label="Evidence completeness" value={`${Math.round(sc.evidence_completeness_percent)}%`} tag="calc" />
            <Stat label="Evidence quality" value={typeof sc.evidence_quality_score === "number" ? `${Math.round(sc.evidence_quality_score)}%` : "Not measured"} tag="calc" />
          </div>
        </div>
        <p className="rp-fine">The score describes the strength of the evidence collected. It is not a guarantee that a product will succeed.</p>
      </header>

      <ReportToc hasAi={!!ai} />

      <Part id="overview" title="Opportunity Overview">
      <Snapshot s={s} ai={ai} />

      <Card title="Score Breakdown" tag="calc">
        <div className="rp-grid rp-grid--2">
          {comps.map((c) => (
            <div key={c.label} className="rp-comp">
              <div className="rp-comp__top">
                <strong>{COMPONENT_COPY[c.key]?.name ?? c.label} — {Math.round(c.weight * 100)}%</strong>
                <span className="rp-comp__score">{c.status === "ok" && c.score !== null ? `${Math.round(c.score)} / 100` : "Insufficient data"}</span>
              </div>
              <div className="rp-muted rp-small">Confidence: {cap(c.confidence)}</div>
              {c.note && <div className="rp-note">{c.note}</div>}
              <p className="rp-small">{COMPONENT_COPY[c.key]?.plain}</p>
              <p className="rp-small rp-muted">{c.explanation}</p>
            </div>
          ))}
        </div>
      </Card>

      <Card title="What the Evidence Says" tag="calc">
        <ul className="rp-list">{s.findings.map((f) => <li key={f.rule}>{f.text}</li>)}</ul>
      </Card>

      </Part>

      <Part id="market-evidence" title="Market Evidence">
      <Card title="Search Demand" tag="data">
        <div className="rp-grid rp-grid--3">
          <Stat label="Weighted search demand" value={`${n(s.demand.weighted_search_demand)} / month`} tag="calc" />
          <Stat label="Primary keyword group" value={s.demand.primary_keyword ?? "—"} tag="data" />
          <Stat label="Independent keyword groups" value={n(s.demand.independent_groups)} tag="calc" />
        </div>
        {s.demand.clusters.length > 0 && (
          <div className="rp-table-wrap">
            <table className="ng-table">
              <thead><tr><th>Keyword group</th><th>Monthly searches</th><th>CPC</th><th>Google Ads competition</th><th>Variants grouped</th></tr></thead>
              <tbody>
                {s.demand.clusters.map((k) => (
                  <tr key={k.representative_keyword}>
                    <td data-label="Keyword group">{k.representative_keyword}</td><td data-label="Monthly searches">{n(k.monthly_search_volume)}</td>
                    <td data-label="CPC">{money(k.cpc, "USD")}</td><td data-label="Ads competition">{cap(k.google_ads_competition?.toLowerCase())}</td><td data-label="Variants grouped">{k.grouped_keywords}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="rp-fine">Search volume represents search activity, not guaranteed customers or sales. CPC and Google Ads competition are advertising signals, not market size.</p>
      </Card>

      <Card title="Marketplace Competition" tag="data">
        <div className="rp-note">Competition Opportunity: higher means the competitive environment appears more favorable.</div>
        <div className="rp-grid rp-grid--4">
          <Stat label="Amazon searches analyzed" value={`${m.amazon_searches_used} used of ${m.amazon_searches_analyzed}`} tag="calc" />
          <Stat label="Relevant products analyzed" value={n(m.relevant_products_analyzed)} tag="calc" />
          <Stat label="Products excluded as irrelevant" value={n(m.products_excluded)} tag="calc" />
          <Stat label="Median price" value={money(m.median_price, m.currency)} tag="data" />
          <Stat label="Median rating" value={typeof m.median_rating === "number" ? `${m.median_rating.toFixed(1)}★` : "Unknown"} tag="data" />
          <Stat label="Median review count" value={n(m.median_review_count)} tag="data" />
          <Stat label="Strong competitors" value={pct(m.strong_competitor_ratio)} tag="calc" />
          <Stat label="Sponsored results" value={pct(m.sponsored_ratio)} tag="data" />
          <Stat label="Amazon's Choice" value={n(m.amazon_choice_count)} tag="data" />
          <Stat label="Best Sellers" value={n(m.best_seller_count)} tag="data" />
        </div>
        <details className="rp-details">
          <summary>Which Amazon searches were used?</summary>
          <ul className="rp-list rp-small">
            {m.searches.map((x) => <li key={x.keyword}><strong>{x.keyword}</strong> — relevance {Math.round(x.relevance_score)}/100, {x.status}</li>)}
          </ul>
        </details>
        {m.sample_products.length > 0 && (
          <>
            <h3 className="rp-h3">Sample relevant competitors</h3>
            <div className="rp-table-wrap">
              <table className="ng-table">
                <thead><tr><th>Product</th><th>Price</th><th>Rating</th><th>Reviews</th><th>Bought past month</th></tr></thead>
                <tbody>
                  {m.sample_products.map((p, i) => (
                    <tr key={i}>
                      <td data-label="Product">{p.title}{p.is_best_seller ? " · Best Seller" : ""}{p.is_amazon_choice ? " · Amazon's Choice" : ""}</td>
                      <td data-label="Price">{money(p.price, m.currency)}</td><td data-label="Rating">{p.rating ?? "Unknown"}</td><td data-label="Reviews">{n(p.review_count)}</td>
                      <td data-label="Bought past month">{typeof p.bought_past_month === "number" ? `${n(p.bought_past_month)}+` : "Unknown"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
        <p className="rp-fine">Marketplace evidence reflects the Amazon results analyzed and should not be interpreted as the total number of competitors in the market.</p>
      </Card>

      <Card title="Purchase Intent" tag="data">
        <div className="rp-grid rp-grid--4">
          <Stat label="Weighted CPC" value={money(s.purchase.weighted_cpc, "USD")} tag="data" />
          <Stat label="Commercial keyword groups" value={pct(s.purchase.commercial_share)} tag="calc" />
          <Stat label="Amazon purchase signal" value={typeof s.purchase.marketplace_purchase_score === "number" ? `${Math.round(s.purchase.marketplace_purchase_score)} / 100` : "Unknown"} tag="calc" />
          <Stat label="Purchase-signal coverage" value={pct(s.purchase.purchase_signal_coverage)} tag="calc" />
        </div>
        <ul className="rp-list rp-small rp-muted">
          <li>CPC (cost per click) is an advertising signal of commercial intent.</li>
          <li>"Bought in past month" is an Amazon marketplace signal shown for some products only.</li>
          <li>Products without a purchase count are treated as unknown, not as zero sales.</li>
        </ul>
      </Card>

      <Card title="Trend & Seasonality" tag="data">
        <div className="rp-grid rp-grid--4">
          <Stat label="Trend score" value={sc.components.trend.score !== null ? `${Math.round(sc.components.trend.score)} / 100` : "Insufficient data"} tag="calc" />
          <Stat label="Classification" value={s.trend.classification === "seasonal" ? "Possible seasonality" : cap(s.trend.classification)} tag="calc" />
          <Stat label="Last 3 months avg" value={n(s.trend.recent_average)} tag="data" />
          <Stat label="Prior 3 months avg" value={n(s.trend.previous_average)} tag="data" />
          <Stat label="Change" value={typeof s.trend.growth_rate === "number" ? `${s.trend.growth_rate >= 0 ? "+" : ""}${Math.round(s.trend.growth_rate * 100)}%` : "Unknown"} tag="calc" />
          <Stat label="12-month average" value={n(s.trend.twelve_month_average)} tag="data" />
          <Stat label="Peak month" value={(s.trend.peak_month as { month?: string } | null)?.month ?? "Unknown"} tag="data" />
          <Stat label="Peak / average" value={typeof s.trend.seasonality_ratio === "number" ? `${s.trend.seasonality_ratio.toFixed(2)}×` : "Unknown"} tag="calc" />
          <Stat label="Trend confidence" value={cap(sc.components.trend.confidence)} tag="calc" />
          <Stat label="Seasonality confidence" value={cap(s.trend.seasonality_confidence as string | null)} tag="calc" />
        </div>
        <TrendBars series={s.trend.series as Array<{ month: string; volume: number }>} />
        {s.trend.history_note && <p className="rp-note">{s.trend.history_note}</p>}
      </Card>

      <div id="community-evidence"><CommunitySection c={(s as Partial<ReportSnapshotV2>).community} /></div>

      <Card title="Evidence Quality" tag="calc">
        <div className="rp-grid rp-grid--3">
          <Stat label="Evidence completeness" value={`${Math.round(sc.evidence_completeness_percent)}%`} />
          <Stat label="Evidence quality" value={typeof sc.evidence_quality_score === "number" ? `${Math.round(sc.evidence_quality_score)}%` : "Not measured"} />
          <Stat label="Overall confidence" value={cap(sc.confidence)} />
        </div>
        <p className="rp-fine">Completeness measures whether each type of data was present. Quality measures how independent, relevant and deep that data was.</p>
        <div className="rp-grid rp-grid--2">
          {s.quality.map((q) => (
            <div key={q.key} className="rp-comp">
              <div className="rp-comp__top"><strong>{q.label}</strong><span className="rp-comp__score">{q.score === null ? "N/A" : `${q.score} / 100`}</span></div>
              <p className="rp-small rp-muted">{q.text}</p>
            </div>
          ))}
        </div>
      </Card>

      </Part>

      {ai && <Part id="opportunity-analysis" title="Opportunity Analysis">
      <AiAnalysisSection a={(s as { ai?: AiSectionData | null }).ai ?? null} />
      </Part>}

      <Part id="next-steps" title="What To Do Next">
      <Card title="Recommended Next Validation Steps">
        <ol className="rp-list">{s.validation_steps.map((v) => <li key={v.rule}>{v.text}</li>)}</ol>
      </Card>

      <Card title="What to Watch" tag="calc">
        {s.cautions.length ? <ul className="rp-list">{s.cautions.map((c) => <li key={c.rule}>{c.text}</li>)}</ul> : <p className="rp-muted">No cautions were triggered by the evidence.</p>}
      </Card>

      <Methodology hasAi={!!ai} />

      <Card title="Research Sources">
        <ul className="rp-list rp-small">
          {s.provenance.sources.map((x) => <li key={x.name}><strong>{x.name}</strong> — collected {date(x.collected_at)}</li>)}
          <li>Market: {labelFor(COUNTRIES, s.provenance.market)} · Language: {labelFor(LANGUAGES, s.provenance.language)}</li>
          <li>Report generated {date(s.generated_at)}</li>
        </ul>
        <div className="rp-legend">
          <span className="rp-tag rp-tag--data">Real market data</span> values come directly from Google, Amazon and public community data.
          <span className="rp-tag rp-tag--calc">NicheGap calculation</span> values are deterministic scores calculated from that data.
          {(s as { ai?: AiSectionData | null }).ai
            ? <><span className="rp-tag rp-tag--ai">AI analysis</span> sections are evidence-grounded interpretations of that data; they never change the Opportunity Score.</>
            : " No AI analysis is included in this report."}
        </div>
      </Card>
      </Part>
    </>
  );
}

export function CommunitySection({ c }: { c: ReportSnapshotV2["community"] | undefined }) {
  if (!c) return null;
  return (
    <Card title="Customer Problem Evidence" tag="data">
      <p className="rp-summary">{c.summary}</p>
      {c.status !== "missing" && (
        <>
          <div className="rp-grid rp-grid--4">
            <Stat label="Relevant public discussions" value={n(c.metrics.relevant_discussions)} tag="data" />
            <Stat label="Relevant comments" value={n(c.metrics.relevant_comments)} tag="data" />
            <Stat label="Community evidence quality" value={typeof c.metrics.evidence_quality === "number" ? `${c.metrics.evidence_quality.toFixed(2)} / 100` : "Not measured"} tag="calc" />
            <Stat label="Evidence confidence" value={cap(c.metrics.confidence)} tag="calc" />
          </div>
          <h3 className="rp-h3">Language signals found</h3>
          <div className="rp-grid rp-grid--5">
            {c.metrics.signals.map((x) => <Stat key={x.key} label={`${cap(x.label)} signals`} value={n(x.count)} tag="data" />)}
          </div>
          <h3 className="rp-h3">Recency of relevant discussions</h3>
          <div className="rp-grid rp-grid--5">
            {c.metrics.recency.map((r) => <Stat key={r.key} label={r.label} value={n(r.count)} tag="data" />)}
          </div>
          {c.samples.length > 0 && (
            <>
              <h3 className="rp-h3">Recent discussion evidence</h3>
              <ul className="rp-samples">
                {c.samples.map((x, i) => (
                  <li key={i} className="rp-sample">
                    <div className="rp-sample__title">{x.url ? <a href={x.url} target="_blank" rel="noopener noreferrer nofollow">{x.title ?? "Untitled discussion"}</a> : (x.title ?? "Untitled discussion")}</div>
                    {x.snippet && <blockquote className="rp-sample__quote">{x.snippet}</blockquote>}
                    <div className="rp-small rp-muted">
                      {x.platform} · {date(x.created_at)} ({x.recency}) · Relevance: {cap(x.relevance_band)}
                      {x.signals.length ? ` · Signals: ${x.signals.join(", ")}` : ""}
                      {typeof x.upvotes === "number" ? ` · ${n(x.upvotes)} upvote${x.upvotes === 1 ? "" : "s"}` : ""}
                      {typeof x.comments === "number" ? ` · ${n(x.comments)} comment${x.comments === 1 ? "" : "s"}` : ""}
                    </div>
                  </li>
                ))}
              </ul>
            </>
          )}
          <ul className="rp-list rp-small rp-muted">{c.notes.map((t) => <li key={t}>{t}</li>)}</ul>
        </>
      )}
    </Card>
  );
}

const conf = (c: string) => <span className={`rp-conf rp-conf--${c}`}>{cap(c)} confidence</span>;

function EvidenceDetails({ refs, ev }: { refs: string[]; ev: Record<string, ResolvedEvidence> }) {
  if (!refs.length) return null;
  return (
    <details className="rp-details rp-ev">
      <summary>View supporting evidence ({refs.length})</summary>
      <ul className="rp-ev__list">
        {refs.map((r) => {
          const e = ev[r]; if (!e) return null;
          const facts = [
            "monthly_searches" in e && typeof e.monthly_searches === "number" ? `${n(e.monthly_searches)} searches / month` : null,
            "cpc_usd" in e && typeof e.cpc_usd === "number" ? `CPC ${money(e.cpc_usd, "USD")}` : null,
            "competition" in e && e.competition ? `Ads competition ${cap(e.competition.toLowerCase())}` : null,
            "results_count" in e && typeof e.results_count === "number" ? `${n(e.results_count)} results` : null,
            "price" in e && typeof e.price === "number" ? money(e.price, e.currency ?? null) : null,
            "rating" in e && typeof e.rating === "number" ? `${e.rating}★` : null,
            "review_count" in e && typeof e.review_count === "number" ? `${n(e.review_count)} reviews` : null,
            "platform" in e && e.platform ? e.platform : null,
            "date" in e && e.date ? date(e.date) : null,
          ].filter(Boolean);
          const url = "url" in e ? e.url : null;
          return (
            <li key={r} className="rp-ev__item">
              <div className="rp-small"><strong>{e.kind}</strong>{e.title ? ": " : ""}{url ? <a href={url} target="_blank" rel="noopener noreferrer nofollow">{e.title}</a> : e.title}</div>
              {"snippet" in e && e.snippet && <blockquote className="rp-sample__quote">{e.snippet}</blockquote>}
              {facts.length > 0 && <div className="rp-small rp-muted">{facts.join(" · ")}</div>}
            </li>
          );
        })}
      </ul>
    </details>
  );
}

export function AiAnalysisSection({ a }: { a: AiSectionData | null }) {
  if (!a) return null;
  const ev = a.evidence;
  return (
    <Card title="AI Opportunity Analysis" tag="ai">
      <p className="rp-note">{a.intro}</p>
      {a.executive_summary.text && <p className="rp-summary">{a.executive_summary.text}</p>}
      <EvidenceDetails refs={a.executive_summary.evidence} ev={ev} />

      <h3 className="rp-h3" id="customer-problems">Key Customer Problems</h3>
      <div className="rp-grid rp-grid--2">
        {a.problems.map((p) => (
          <div key={p.title} className="rp-comp">
            <div className="rp-comp__top"><strong>{p.title}</strong></div>
            <div className="rp-small rp-muted">{conf(p.confidence)} · {p.evidence_count} supporting evidence items</div>
            <p className="rp-small">{p.description}</p>
            <EvidenceDetails refs={p.evidence} ev={ev} />
          </div>
        ))}
      </div>

      <h3 className="rp-h3">Potential Unmet Needs</h3>
      <ul className="rp-ai-list">
        {a.unmet_needs.map((x) => (
          <li key={x.need}><strong>{x.need}</strong> <span className="rp-small rp-muted">· {conf(x.confidence)}</span><p className="rp-small">{x.explanation}</p><EvidenceDetails refs={x.evidence} ev={ev} /></li>
        ))}
      </ul>

      <h3 className="rp-h3">What People Dislike About Existing Solutions</h3>
      <ul className="rp-ai-list">
        {a.complaints.map((x) => (
          <li key={x.complaint}><strong>{x.complaint}</strong> <span className="rp-small rp-muted">{x.solution_type ? `· ${x.solution_type} ` : ""}· {conf(x.confidence)}</span><EvidenceDetails refs={x.evidence} ev={ev} /></li>
        ))}
      </ul>

      {a.language.length > 0 && (
        <>
          <h3 className="rp-h3">Customer Language</h3>
          <ul className="rp-ai-list">
            {a.language.map((l) => (
              <li key={l.phrase}>
                {l.verified_quote
                  ? <><span className="rp-lang rp-lang--quote">Verified quote</span> <q className="rp-quote">{l.phrase}</q></>
                  : <><span className="rp-lang rp-lang--para">AI paraphrase</span> <span className="rp-para">{l.phrase}</span></>}
                <EvidenceDetails refs={l.evidence} ev={ev} />
              </li>
            ))}
          </ul>
        </>
      )}

      <h3 className="rp-h3" id="opportunities">Opportunity Hypotheses</h3>
      <p className="rp-note">{a.hypotheses_note}</p>
      <div className="rp-grid rp-grid--2">
        {a.hypotheses.map((h) => (
          <div key={h.hypothesis} className="rp-comp rp-hyp">
            <div className="rp-hyp__title">{h.hypothesis}</div>
            <div className="rp-small rp-muted">{conf(h.confidence)} · {h.evidence_count} supporting evidence items</div>
            <p className="rp-small">{h.rationale}</p>
            <EvidenceDetails refs={h.evidence} ev={ev} />
          </div>
        ))}
      </div>

      <h3 className="rp-h3">Risks &amp; Uncertainties</h3>
      <ul className="rp-ai-list">{a.risks.map((r) => <li key={r.risk}>{r.risk}<EvidenceDetails refs={r.evidence} ev={ev} /></li>)}</ul>

      <h3 className="rp-h3">Recommended Validation Steps</h3>
      <ol className="rp-list">{a.validation_steps.map((v) => <li key={v.recommendation}><strong>{v.recommendation}</strong> <span className="rp-small rp-muted">— {v.addresses}</span></li>)}</ol>

      <p className="rp-fine">AI-assisted interpretation of the stored evidence only, then checked by NicheGap: every finding cites real evidence, unsupported quotes are labelled as paraphrases, and confidence is limited by the amount of supporting evidence.</p>
    </Card>
  );
}

function TrendBars({ series }: { series: Array<{ month: string; volume: number }> }) {
  if (!series?.length) return null;
  const max = Math.max(...series.map((x) => x.volume), 1);
  return (
    <div className="rp-bars" aria-label="Monthly search volume">
      {series.map((x) => (
        <div key={x.month} className="rp-bar" title={`${x.month}: ${x.volume.toLocaleString("en-US")}`}>
          <div className="rp-bar__fill" style={{ height: `${Math.max(3, (x.volume / max) * 100)}%` }} />
          <div className="rp-bar__label">{x.month.slice(2)}</div>
        </div>
      ))}
    </div>
  );
}
