import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { JobCard, JourneyShell } from "@/components/journey/Journey";
import { fetchJourneyJobs } from "@/lib/nichegap/journey-data";
import { CreditBalanceBadge } from "@/components/journey/CreditBalance";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — NicheGap" },
      { name: "description", content: "Research a niche and review your recent market research in NicheGap." },
      { property: "og:title", content: "Dashboard — NicheGap" },
      { property: "og:description", content: "Research a niche and review your recent market research in NicheGap." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const { user } = Route.useRouteContext();
  const jobs = useQuery({ queryKey: ["journey", "recent"], queryFn: () => fetchJourneyJobs({ limit: 5 }) });
  return (
    <JourneyShell email={user.email}>
      <section className="nj-hero">
        <div className="nj-eyebrow">Real market evidence · NicheGap analysis · AI-assisted interpretation</div>
        <h1 className="nj-h1">Research a Niche</h1>
        <p className="nj-lead">Discover real customer problems, market demand, competition and product opportunities.</p>
        <Link to="/research/new" className="button button--primary nj-cta">Research a Niche</Link>
        <CreditBalanceBadge />
      </section>

      <section className="nj-section">
        <div className="nj-section__head">
          <h2>Recent research</h2>
          {!!jobs.data?.length && <Link to="/research" className="nj-link">View all</Link>}
        </div>
        {jobs.isLoading ? <p className="nj-muted">Loading your research…</p>
          : jobs.error ? <p className="nj-muted">We couldn't load your research just now. Please refresh the page.</p>
          : !jobs.data?.length ? (
            <div className="nj-empty">
              <h3>No research yet</h3>
              <p className="nj-muted">Start with a niche or product idea. NicheGap checks real search demand, marketplace competition and public customer discussions.</p>
              <Link to="/research/new" className="button button--primary button--small">Research your first niche</Link>
            </div>
          ) : <ul className="nj-jobs">{jobs.data.map((j) => <JobCard key={j.id} job={j} />)}</ul>}
      </section>
    </JourneyShell>
  );
}
