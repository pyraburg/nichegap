import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { JourneyShell, StatusBadge } from "@/components/journey/Journey";
import { fetchJourneyJobs, type JourneyJob } from "@/lib/nichegap/journey-data";
import { customerStatus, FAILURE_MESSAGE, indication, journeyStages, REPORT_FAILURE_MESSAGE, type StageState } from "@/lib/nichegap/journey";
import { runKeywordResearch } from "@/lib/nichegap/research.functions";
import { retryResearchPipeline } from "@/lib/nichegap/pipeline.functions";
import { generateReport } from "@/lib/nichegap/report.functions";
import { COUNTRIES, LANGUAGES, labelFor } from "@/lib/nichegap/markets";
import { supabase } from "@/integrations/supabase/client";
import { REFUND_MESSAGE, showRefundNotice } from "@/lib/nichegap/credit_policy_v1";

export const Route = createFileRoute("/_authenticated/research_/$id/")({
  head: () => ({
    meta: [
      { title: "Your Research — NicheGap" },
      { name: "description", content: "Follow your niche research and preview the opportunity before generating the full report." },
      { property: "og:title", content: "Your Research — NicheGap" },
      { property: "og:description", content: "Follow your niche research and preview the opportunity before generating the full report." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResearchJourney,
});

const STATE_LABEL: Record<StageState, string> = { done: "Complete", active: "In progress", waiting: "Waiting", not_included: "Not included in this research", attention: "Needs attention" };
const cap = (s: string | null | undefined) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : "—");

function ResearchJourney() {
  const { id } = Route.useParams();
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const runFn = useServerFn(runKeywordResearch);
  const genFn = useServerFn(generateReport);
  const retryPipeFn = useServerFn(retryResearchPipeline);

  const gen = useMutation({
    mutationFn: () => genFn({ data: { research_query_id: id } }),
    onSettled: () => qc.invalidateQueries({ queryKey: ["journey"] }),
  });
  const retry = useMutation({
    mutationFn: async () => { qc.setQueryData(["journey", "job", id], (j: JourneyJob | null | undefined) => (j ? { ...j, facts: { ...j.facts, status: "processing" } } : j)); const isPipe = !!qc.getQueryData<JourneyJob | null>(["journey", "job", id])?.facts.pipeline;
      return isPipe ? retryPipeFn({ data: { research_query_id: id } }) : runFn({ data: { research_query_id: id } }); },
    onSettled: () => qc.invalidateQueries({ queryKey: ["journey"] }),
  });

  const job = useQuery({
    queryKey: ["journey", "job", id],
    queryFn: async () => (await fetchJourneyJobs({ id }))[0] ?? null,
    // Poll only while the backend is actually working.
    refetchInterval: (q) => (q.state.data?.facts.status === "processing" ? 5000 : false), // display only; the server drives progress
  });

  // Credit refund notice: only when the reservation for this job was actually released (own row via RLS).
  const reservation = useQuery({
    queryKey: ["credits", "reservation", id],
    queryFn: async () => (await supabase.from("credit_reservations").select("status").eq("research_query_id", id).maybeSingle()).data ?? null,
    enabled: job.data?.facts.status === "failed",
  });
  const refunded = showRefundNotice(reservation.data?.status);

  if (job.isLoading) return <JourneyShell email={user.email}><p className="nj-muted">Loading…</p></JourneyShell>;
  if (!job.data) return (
    <JourneyShell email={user.email}>
      <div className="nj-empty"><h3>Research not found</h3><p className="nj-muted">This research doesn't exist or belongs to another account.</p><Link to="/research" className="button button--ghost button--small">My Research</Link></div>
    </JourneyShell>
  );

  const j = job.data;
  const facts = { ...j.facts, generating_report: gen.isPending };
  const st = customerStatus(facts);
  const stages = journeyStages(facts);

  return (
    <JourneyShell email={user.email}>
      <div className="nj-section__head nj-section__head--page">
        <div>
          <Link to="/research" className="nj-link">← My Research</Link>
          <h1 className="nj-h2">{j.query}</h1>
          <p className="nj-muted">{labelFor(COUNTRIES, j.target_country)} · {labelFor(LANGUAGES, j.language)}</p>
        </div>
        <StatusBadge status={st} />
      </div>

      {st === "complete" && (
        <section className="nj-ready">
          <h2>Your Opportunity Report is Ready</h2>
          <p className="nj-muted">Built from real market evidence, NicheGap's scoring and an evidence-checked interpretation.</p>
          <div className="nj-actions">
            <Link to="/research/$id/report" params={{ id }} className="button button--primary nj-cta">View Opportunity Report</Link>
            <Link to="/research/$id/report" params={{ id }} search={{ print: true }} className="button button--ghost">Print / Save PDF</Link>
            <Link to="/research/new" className="button button--quiet">Start New Research</Link>
          </div>
        </section>
      )}

      {(st === "ready_for_report" || st === "generating_report" || st === "complete" || (j.facts.pipeline && j.facts.has_score)) && <Preview j={j} />}
      {j.facts.pipeline && st !== "complete" && j.facts.has_score && (
        <p className="nj-hint">Your full Opportunity Report is still being prepared. This preview shows the early market results.</p>
      )}

      {(st === "ready_for_report" || st === "generating_report") && (
        <section className="nj-card nj-generate">
          <div>
            <h2>Get the full Opportunity Report</h2>
            <p className="nj-muted">Includes the score breakdown, demand and competition detail, customer problem evidence and recommended validation steps.</p>
            {gen.isError && <p role="alert" className="nj-error">{REPORT_FAILURE_MESSAGE}</p>}
          </div>
          <button className="button button--primary nj-cta" disabled={gen.isPending}
            onClick={() => gen.mutate(undefined, { onSuccess: () => navigate({ to: "/research/$id/report", params: { id } }) })}>
            {gen.isPending ? "Preparing your report…" : "Generate Opportunity Report"}
          </button>
        </section>
      )}

      {refunded && (
        <section className="nj-card nj-attention" role="status"><p>{REFUND_MESSAGE}</p></section>
      )}
      {st === "needs_attention" && !refunded && (
        <section className="nj-card nj-attention" role="alert">
          <p>{FAILURE_MESSAGE}</p>
          <button className="button button--primary button--small" disabled={retry.isPending} onClick={() => retry.mutate()}>{retry.isPending ? "Retrying…" : "Try again"}</button>
        </section>
      )}
      {st === "not_started" && (
        <section className="nj-card nj-attention">
          <p>This research hasn't started yet.</p>
          <button className="button button--primary button--small" disabled={retry.isPending} onClick={() => retry.mutate()}>Start research</button>
        </section>
      )}

      <section className="nj-card">
        <h2 className="nj-card__title">{st === "researching" ? "Researching your niche…" : "Research progress"}</h2>
        <ol className="nj-stages">
          {stages.map((s, i) => (
            <li key={s.key} className={`nj-stage nj-stage--${s.state}`}>
              <span className="nj-stage__dot" aria-hidden>{s.state === "done" ? "✓" : i + 1}</span>
              <span className="nj-stage__label">{s.label}</span>
              <span className="nj-stage__state">{STATE_LABEL[s.state]}</span>
            </li>
          ))}
        </ol>
        {st === "researching" && <p className="nj-hint">{j.facts.pipeline ? "Your research will continue even if you leave this page. It usually takes a few minutes — come back any time to see the progress or your finished report." : "This usually takes a minute or two. You can leave this page; your research continues and will appear in My Research."}</p>}
      </section>
    </JourneyShell>
  );
}

function Preview({ j }: { j: JourneyJob }) {
  const missing = !j.facts.pipeline ? "Not included" : j.facts.pipeline.community === "failed" ? "Needs attention" : "In progress";
  return (
    <section className="nj-card">
      <h2 className="nj-card__title">Opportunity Preview</h2>
      <div className="nj-preview">
        <div className="nj-pv nj-pv--score">
          <div className="nj-pv__label">Opportunity Score</div>
          <div className="nj-pv__value">{j.score?.display != null ? <>{j.score.display}<small> / 100</small></> : "Not enough data"}</div>
          {j.score?.classification && <div className="nj-pv__sub">{j.score.classification}</div>}
        </div>
        <div className="nj-pv"><div className="nj-pv__label">Search demand</div><div className="nj-pv__value">{indication(j.score?.demand)}</div></div>
        <div className="nj-pv"><div className="nj-pv__label">Marketplace competition</div><div className="nj-pv__value">{j.score?.competition == null ? "Not enough data" : indication(j.score.competition) === "Strong" ? "Favourable" : indication(j.score.competition) === "Moderate" ? "Moderate" : "Crowded"}</div></div>
        <div className="nj-pv"><div className="nj-pv__label">Relevant customer discussions</div><div className="nj-pv__value">{j.community?.relevant_discussions ?? missing}</div></div>
        <div className="nj-pv"><div className="nj-pv__label">Community evidence confidence</div><div className="nj-pv__value">{j.community ? cap(j.community.confidence) : missing}</div></div>
      </div>
      <p className="nj-hint">The score reflects the strength of the evidence collected. It isn't a guarantee of success.</p>
    </section>
  );
}
