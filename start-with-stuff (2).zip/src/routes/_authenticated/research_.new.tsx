import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState, type FormEvent } from "react";
import { createResearch } from "@/lib/nichegap/credits.functions";
import { CreditBalanceBadge, OutOfCredits, hasCredits, useCreditBalance } from "@/components/journey/CreditBalance";
import { COUNTRIES, LANGUAGES } from "@/lib/nichegap/markets";
import { JourneyShell } from "@/components/journey/Journey";
import { CREDIT_POLICY_TEXT } from "@/lib/nichegap/credit_policy_v1";

export const Route = createFileRoute("/_authenticated/research_/new")({
  head: () => ({
    meta: [
      { title: "Research a Niche — NicheGap" },
      { name: "description", content: "Enter a niche or product idea to research its demand, competition and customer problems." },
      { property: "og:title", content: "Research a Niche — NicheGap" },
      { property: "og:description", content: "Enter a niche or product idea to research its demand, competition and customer problems." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: NewResearch,
});

function NewResearch() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const run = useServerFn(createResearch);
  const credits = useCreditBalance();
  const [outOfCredits, setOutOfCredits] = useState(false);
  // One stable id per intended research: double clicks and retried requests reuse it, so at most one credit is reserved.
  const requestId = useRef<string | null>(null);
  const [query, setQuery] = useState("");
  const [country, setCountry] = useState("US");
  const [language, setLanguage] = useState("en");

  const create = useMutation({
    mutationFn: async () => {
      const text = query.trim();
      if (text.length < 2 || text.length > 200) throw new Error("Describe a niche in 2 to 200 characters.");
      requestId.current ??= crypto.randomUUID();
      const r = await run({ data: { submission_id: requestId.current, query: text, target_country: country, language } });
      if (r.status === "out_of_credits") { requestId.current = null; setOutOfCredits(true); return null; }
      if (r.status !== "started" || !r.job_id) { requestId.current = null; throw new Error("We couldn't start your research. Please try again."); }
      return r.job_id;
    },
    onSettled: () => { qc.invalidateQueries({ queryKey: ["journey"] }); qc.invalidateQueries({ queryKey: ["credits"] }); },
    onSuccess: (id) => { if (id) navigate({ to: "/research/$id", params: { id } }); },
  });

  function submit(e: FormEvent) { e.preventDefault(); create.mutate(); }

  return (
    <JourneyShell email={user.email}>
      <section className="nj-form-wrap">
        <h1 className="nj-h2">Research a Niche</h1>
        <p className="nj-muted">Tell us the niche or product idea. NicheGap gathers the market evidence for you.</p>
        <CreditBalanceBadge />
        {(outOfCredits || (credits.data && !hasCredits(credits.data))) && <OutOfCredits />}
        <form onSubmit={submit} className="nj-form">
          <div className="field-group">
            <label htmlFor="niche">Niche or idea</label>
            <input id="niche" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. indoor herb gardening" maxLength={200} required autoFocus />
            <p className="nj-hint">Examples: indoor herb gardening, meal planning for busy parents, dog anxiety</p>
          </div>
          <div className="nj-form__row">
            <div className="field-group">
              <label htmlFor="country">Target market</label>
              <select id="country" className="ng-select" value={country} onChange={(e) => setCountry(e.target.value)}>
                {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
              </select>
            </div>
            <div className="field-group">
              <label htmlFor="language">Language</label>
              <select id="language" className="ng-select" value={language} onChange={(e) => setLanguage(e.target.value)}>
                {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
              </select>
            </div>
          </div>
          {create.error && <p role="alert" className="nj-error">{create.error.message}</p>}
          <p className="nj-hint">{CREDIT_POLICY_TEXT}</p>
          <button className="button button--primary nj-cta" type="submit" disabled={create.isPending || outOfCredits || (!!credits.data && !hasCredits(credits.data))}>
            {create.isPending ? "Starting…" : "Research This Niche"}
          </button>
        </form>
      </section>
    </JourneyShell>
  );
}
