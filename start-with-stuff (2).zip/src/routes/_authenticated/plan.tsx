import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { JourneyShell } from "@/components/journey/Journey";
import { useCreditBalance } from "@/components/journey/CreditBalance";
import { balanceLabel, totalCredits } from "@/lib/nichegap/credits";
import { CREDIT_POLICY_TEXT } from "@/lib/nichegap/credit_policy_v1";
import { ENTITLEMENTS, type PlanKey } from "@/lib/nichegap/billing/lemonsqueezy_v1";
import { openCustomerPortal, startCheckout } from "@/lib/nichegap/billing.functions";

export const Route = createFileRoute("/_authenticated/plan")({
  validateSearch: z.object({ checkout: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Plan & Credits — NicheGap" },
      { name: "description", content: "Manage your NicheGap plan and Research Credits." },
      { property: "og:title", content: "Plan & Credits — NicheGap" },
      { property: "og:description", content: "Manage your NicheGap plan and Research Credits." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PlanPage,
});

const STATUS: Record<string, string> = { active: "Active", on_trial: "Trial", past_due: "Payment issue", unpaid: "Payment issue", cancelled: "Cancelled", expired: "Expired", paused: "Paused" };
const fmt = (d: string | null) => (d ? new Date(d).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : null);

function PlanPage() {
  const { user } = Route.useRouteContext();
  const { checkout } = Route.useSearch();
  const qc = useQueryClient();
  const credits = useCreditBalance();
  const plan = useQuery({
    queryKey: ["credits", "plan"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_my_plan");
      if (error) throw error;
      return (Array.isArray(data) ? data[0] : data) as { status: string; cancelled: boolean; renews_at: string | null; ends_at: string | null } | undefined ?? null;
    },
  });
  const go = useServerFn(startCheckout);
  const portal = useServerFn(openCustomerPortal);
  const [err, setErr] = useState<string | null>(null);
  const buy = useMutation({
    mutationFn: async (p: PlanKey) => { setErr(null); const r = await go({ data: { plan: p } }); if (!r.url) throw new Error(); window.location.href = r.url; },
    onError: () => setErr("Checkout isn't available right now. Please try again shortly."),
  });
  const manage = useMutation({
    mutationFn: async () => { setErr(null); const r = await portal(); if (!r.url) throw new Error(); window.location.href = r.url; },
    onError: () => setErr("We couldn't open plan management right now."),
  });

  // After checkout: poll server-side balance until the verified payment shows up (max ~2 min). Redirect alone grants nothing.
  const start = useRef<number | null>(null);
  const [confirming, setConfirming] = useState(checkout === "done");
  useEffect(() => {
    if (!confirming) return;
    if (start.current == null) start.current = credits.data ? totalCredits(credits.data) : -1;
    const t = setInterval(async () => {
      await qc.invalidateQueries({ queryKey: ["credits"] });
    }, 4000);
    const stop = setTimeout(() => setConfirming(false), 120_000);
    return () => { clearInterval(t); clearTimeout(stop); };
  }, [confirming, qc, credits.data]);
  useEffect(() => {
    if (confirming && credits.data && start.current != null && start.current >= 0 && totalCredits(credits.data) > start.current) setConfirming(false);
  }, [credits.data, confirming]);

  const p = plan.data;
  const subscribed = !!p && ["active", "on_trial", "past_due", "paused"].includes(p.status);
  const l = credits.data ? balanceLabel(credits.data) : null;

  return (
    <JourneyShell email={user.email}>
      <section className="nj-form-wrap">
        <h1 className="nj-h2">Plan &amp; Credits</h1>
        {checkout === "done" && (
          <div className="nj-card" role="status">
            {confirming ? <p>Payment received. We're confirming your Research Credits.</p> : <p>Thanks! Your Research Credits are shown below. If they haven't updated yet, refresh in a minute.</p>}
          </div>
        )}
        <div className="nj-card">
          <h2 className="nj-card__title">Research Credits</h2>
          <p><strong>{l ? `${totalCredits(credits.data!)} total` : "…"}</strong>{l?.split && <span className="nj-muted"> · {l.split}</span>}</p>
          <p className="nj-hint">{CREDIT_POLICY_TEXT} Monthly credits are used first; purchased credits never expire with your plan.</p>
        </div>
        <div className="nj-card">
          <h2 className="nj-card__title">Plan</h2>
          {subscribed ? (
            <>
              <p><strong>{ENTITLEMENTS.monthly.label}</strong> · $9.99/month · {STATUS[p!.status] ?? p!.status}{p!.cancelled ? " (cancels at period end)" : ""}</p>
              {p!.renews_at && !p!.cancelled && <p className="nj-muted">Next renewal: {fmt(p!.renews_at)}</p>}
              {p!.ends_at && <p className="nj-muted">Ends: {fmt(p!.ends_at)}</p>}
              <div className="nj-actions"><button className="button button--ghost button--small" disabled={manage.isPending} onClick={() => manage.mutate()}>Manage Plan</button></div>
            </>
          ) : (
            <>
              <p className="nj-muted">{p ? `Your plan is ${STATUS[p.status]?.toLowerCase() ?? p.status}.` : "No active plan."} NicheGap Monthly includes 10 Research Credits each month.</p>
              <div className="nj-actions">
                <button className="button button--primary button--small" disabled={buy.isPending} onClick={() => buy.mutate("monthly")}>Start NicheGap — $9.99/month</button>
                {p && <button className="button button--ghost button--small" disabled={manage.isPending} onClick={() => manage.mutate()}>Manage Plan</button>}
              </div>
            </>
          )}
        </div>
        <div className="nj-card">
          <h2 className="nj-card__title">Get More Credits</h2>
          <p className="nj-muted">One-time packs. Purchased credits stay on your account.</p>
          <div className="nj-actions">
            {(["topup_5", "topup_15", "topup_40"] as const).map((k) => (
              <button key={k} className="button button--ghost button--small" disabled={buy.isPending} onClick={() => buy.mutate(k)}>
                {ENTITLEMENTS[k].label} — ${ENTITLEMENTS[k].price_usd.toFixed(2)}
              </button>
            ))}
          </div>
        </div>
        {err && <p role="alert" className="nj-error">{err}</p>}
      </section>
    </JourneyShell>
  );
}
