import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Fragment, useState, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { runKeywordResearch } from "@/lib/nichegap/research.functions";
import { ScoreBreakdown } from "@/components/ScoreBreakdown";
import { CommunityTestPanel } from "@/components/CommunityTestPanel";
import { CostSummaryPanel } from "@/components/CostSummaryPanel";
import { AdminCreditGrant } from "@/components/AdminCreditGrant";
import { ValidationPanel } from "@/components/ValidationPanel";
import { WorkerHealthPanel } from "@/components/WorkerHealthPanel";
import { supabase } from "@/integrations/supabase/client";
import { COUNTRIES, LANGUAGES, labelFor } from "@/lib/nichegap/markets";

export const Route = createFileRoute("/_authenticated/lab")({
  head: () => ({
    meta: [
      { title: "Internal research tools — NicheGap" },
      { name: "description", content: "Internal tools for inspecting research evidence." },
      { property: "og:title", content: "Internal research tools — NicheGap" },
      { property: "og:description", content: "Internal tools for inspecting research evidence." },
      { property: "og:type", content: "website" },
      { name: "robots", content: "noindex" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResearchPage,
});

function ResearchPage() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [query, setQuery] = useState("");
  const [country, setCountry] = useState("US");
  const [language, setLanguage] = useState("en");

  const history = useQuery({
    queryKey: ["research_queries", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("research_queries")
        .select("id, query, target_country, language, status, stage, created_at, error_message")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const text = query.trim();
      if (text.length < 2 || text.length > 200) throw new Error("Describe a niche in 2 to 200 characters.");
      const { data, error } = await supabase
        .from("research_queries")
        .insert({ user_id: user.id, query: text, target_country: country, language, status: "pending" })
        .select("id")
        .single();
      if (error) throw error;
      return data.id;
    },
    onSuccess: (id) => {
      setQuery("");
      queryClient.invalidateQueries({ queryKey: ["research_queries", user.id] });
      run.mutate(id);
    },
  });

  const runFn = useServerFn(runKeywordResearch);
  const [running, setRunning] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const run = useMutation({
    mutationFn: async (id: string) => {
      setRunning(id);
      queryClient.setQueryData(["research_queries", user.id], (rows: typeof history.data) =>
        rows?.map((r) => (r.id === id ? { ...r, status: "processing" } : r)));
      return runFn({ data: { research_query_id: id } });
    },
    onSettled: () => {
      setRunning(null);
      queryClient.invalidateQueries({ queryKey: ["research_queries", user.id] });
      queryClient.invalidateQueries({ queryKey: ["research_data"] });
    },
  });

  function submit(event: FormEvent) {
    event.preventDefault();
    create.mutate();
  }

  async function signOut() {
    await supabase.auth.signOut();
    queryClient.clear();
    navigate({ to: "/auth" });
  }

  return (
    <div style={{ maxWidth: 920, margin: "0 auto", padding: "28px 18px 60px" }}>
      <AdminCreditGrant />
      <WorkerHealthPanel />
      <ValidationPanel />
      <header style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center", justifyContent: "space-between", marginBottom: 22 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <img src="/nichegap-icon.png" alt="" width={30} height={30} style={{ borderRadius: 8 }} />
          <div>
            <strong>NicheGap AI</strong>
            <div style={{ fontSize: 11, color: "var(--muted)" }}>{user.email}</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="button button--ghost button--small" onClick={signOut}>Log out</button>
        </div>
      </header>

      <section className="panel" style={{ marginBottom: 20 }}>
        <div className="panel__heading">
          <div>
            <h2>New research job</h2>
            <p>Jobs are queued as pending. Market data collection is added in a later phase.</p>
          </div>
        </div>
        <form onSubmit={submit} style={{ padding: 22, display: "grid", gap: 14 }}>
          <div className="field-group">
            <label htmlFor="niche">Niche / idea</label>
            <input id="niche" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Indoor gardening for apartment dwellers" maxLength={200} required />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
            <div className="field-group">
              <label htmlFor="country">Target market</label>
              <select id="country" className="ng-select" value={country} onChange={(e) => setCountry(e.target.value)}>
                {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.label}</option>)}
              </select>
            </div>
            <div className="field-group">
              <label htmlFor="language">Language</label>
              <select id="language" className="ng-select" value={language} onChange={(e) => setLanguage(e.target.value)}>
                {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
              </select>
            </div>
          </div>
          {create.error && <p role="alert" style={{ color: "#ff9aaa", fontSize: 12, margin: 0 }}>{create.error.message}</p>}
          <div>
            <button className="button button--primary" disabled={create.isPending || !!running} type="submit">
              {create.isPending ? "Submitting…" : "Submit research job"}
            </button>
          </div>
        </form>
      </section>

      <section className="panel">
        <div className="panel__heading">
          <div>
            <h2>Research history</h2>
            <p>Only your own research jobs are shown.</p>
          </div>
        </div>
        <div style={{ padding: "8px 22px 18px", overflowX: "auto" }}>
          {history.isLoading ? (
            <p style={{ color: "var(--muted)", fontSize: 13 }}>Loading…</p>
          ) : history.error ? (
            <p style={{ color: "#ff9aaa", fontSize: 13 }}>{history.error.message}</p>
          ) : !history.data?.length ? (
            <p style={{ color: "var(--muted)", fontSize: 13 }}>No research jobs yet.</p>
          ) : (
            <table className="ng-table">
              <thead>
                <tr><th>Query</th><th>Target market</th><th>Language</th><th>Status</th><th>Created</th><th /></tr>
              </thead>
              <tbody>
                {history.data.map((row) => (
                  <Fragment key={row.id}>
                  <tr>
                    <td>{row.query}</td>
                    <td>{labelFor(COUNTRIES, row.target_country)}</td>
                    <td>{labelFor(LANGUAGES, row.language)}</td>
                    <td>
                      <span className={`ng-status ng-status--${row.status}`}>
                        {row.status === "processing" ? STAGE_LABEL[row.stage] ?? "Researching..." : STATUS_LABEL[row.status] ?? row.status}
                      </span>
                      {row.status === "failed" && row.error_message && <div style={{ fontSize: 11, color: "var(--muted)" }}>{row.error_message}</div>}
                    </td>
                    <td>{new Date(row.created_at).toLocaleString()}</td>
                    <td>
                      {row.status === "completed" && (
                        <Link to="/research/$id/report" params={{ id: row.id }} className="button button--primary button--small" style={{ marginRight: 6 }}>
                          View Opportunity Report
                        </Link>
                      )}
                      {row.status === "completed" && (
                        <button className="button button--quiet button--small" onClick={() => setOpen(open === row.id ? null : row.id)}>
                          {open === row.id ? "Hide research data" : "View research data"}
                        </button>
                      )}
                      {(row.status === "pending" || row.status === "failed") && (
                        <button className="button button--quiet button--small" disabled={!!running} onClick={() => run.mutate(row.id)}>
                          {row.status === "failed" ? "Retry" : "Run research"}
                        </button>
                      )}
                    </td>
                  </tr>
                  {open === row.id && (
                    <tr><td colSpan={6}>
                      <ScoreBreakdown researchQueryId={row.id} />
                      <EvidenceTable researchQueryId={row.id} />
                      <AmazonEvidence researchQueryId={row.id} />
                      <CommunityTestPanel researchQueryId={row.id} />
                      <CostSummaryPanel researchQueryId={row.id} />
                    </td></tr>
                  )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}

const STATUS_LABEL: Record<string, string> = {
  pending: "Pending",
  processing: "Researching...",
  completed: "Completed",
  failed: "Failed",
};

const STAGE_LABEL: Record<string, string> = {
  keyword_demand: "Collecting search demand...",
  amazon_supply: "Analyzing marketplace supply...",
  complete: "Research complete",
};

interface Evidence {
  keyword: string;
  search_volume: number | null;
  cpc: number | null;
  competition: string | null;
  competition_index: number | null;
}

function EvidenceTable({ researchQueryId }: { researchQueryId: string }) {
  const q = useQuery({
    queryKey: ["research_data", researchQueryId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("research_data")
        .select("processed_data, collected_at, cache_hit")
        .eq("research_query_id", researchQueryId)
        .eq("data_type", "google_keyword_demand")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  if (q.isLoading) return <p style={{ fontSize: 13, color: "var(--muted)" }}>Loading…</p>;
  if (q.error) return <p style={{ fontSize: 13, color: "#ff9aaa" }}>{q.error.message}</p>;
  const rows = ((q.data?.processed_data as { keywords?: Evidence[] } | null)?.keywords ?? [])
    .slice()
    .sort((a, b) => (b.search_volume ?? -1) - (a.search_volume ?? -1));
  if (!rows.length) return <p style={{ fontSize: 13, color: "var(--muted)" }}>No keyword data was returned for this query.</p>;
  const show = (v: number | string | null, f?: (n: number) => string) =>
    v === null || v === undefined ? "—" : typeof v === "number" && f ? f(v) : String(v);
  return (
    <div style={{ padding: "6px 0 12px" }}>
      <h3 style={{ fontSize: 13, margin: "0 0 6px" }}>Google demand</h3>
      <p style={{ fontSize: 11, color: "var(--muted)", margin: "0 0 8px" }}>
        Source: Google Ads keyword data (DataForSEO) · collected {q.data?.collected_at ? new Date(q.data.collected_at).toLocaleDateString() : "—"} · {rows.length} keywords
      </p>
      <table className="ng-table">
        <thead><tr><th>Keyword</th><th>Search volume</th><th>CPC</th><th>Competition</th><th>Competition index</th></tr></thead>
        <tbody>
          {rows.map((k) => (
            <tr key={k.keyword}>
              <td>{k.keyword}</td>
              <td>{show(k.search_volume, (n) => n.toLocaleString())}</td>
              <td>{show(k.cpc, (n) => `$${n.toFixed(2)}`)}</td>
              <td>{show(k.competition)}</td>
              <td>{show(k.competition_index)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

interface AmazonProduct {
  title: string | null;
  asin: string | null;
  result_type: string | null;
  price: number | null;
  currency: string | null;
  bought_past_month: number | null;
  rating: number | null;
  review_count: number | null;
  is_amazon_choice: boolean;
  is_best_seller: boolean;
  relevant: boolean;
}

interface AmazonMetrics {
  relevant_product_count: number;
  paid_result_count: number;
  organic_result_count: number;
  paid_result_ratio: number | null;
  median_price: number | null;
  median_rating: number | null;
  median_review_count: number | null;
  products_with_bought_past_month: number;
  estimated_recent_purchase_signal: number | null;
  amazon_choice_count: number;
  best_seller_count: number;
  strong_competitor_ratio: number | null;
  strong_competitor_rule: string;
}

interface AmazonEvidenceRow {
  keyword: string;
  results_count: number | null;
  items_count: number | null;
  collected_at: string;
  products: AmazonProduct[];
  metrics: AmazonMetrics;
  selection?: { keyword: string; score: number; reasons: string[] };
}

function Metric({ label, value }: { label: string; value: string | null }) {
  return (
    <div style={{ minWidth: 130 }}>
      <div style={{ fontSize: 10, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.4 }}>{label}</div>
      <div style={{ fontSize: 13 }}>{value ?? "Unavailable"}</div>
    </div>
  );
}

function AmazonEvidence({ researchQueryId }: { researchQueryId: string }) {
  const q = useQuery({
    queryKey: ["research_data_amazon", researchQueryId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("research_data")
        .select("processed_data, collected_at, cache_hit, source_query")
        .eq("research_query_id", researchQueryId)
        .eq("data_type", "amazon_marketplace_supply")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  if (q.isLoading) return <p style={{ fontSize: 13, color: "var(--muted)" }}>Loading…</p>;
  if (q.error) return <p style={{ fontSize: 13, color: "#ff9aaa" }}>{q.error.message}</p>;
  const rows = (q.data ?? []).map((r) => r.processed_data as unknown as AmazonEvidenceRow);
  if (!rows.length) return null;
  const pct = (v: number | null) => (v === null ? null : `${Math.round(v * 100)}%`);
  const money = (v: number | null, c: string | null) => (v === null ? null : `${c === "USD" ? "$" : ""}${v.toFixed(2)}`);
  return (
    <div style={{ padding: "6px 0 16px" }}>
      <h3 style={{ fontSize: 13, margin: "12px 0 6px" }}>Amazon marketplace</h3>
      <p style={{ fontSize: 11, color: "var(--muted)", margin: "0 0 10px" }}>
        Source: Amazon product data (DataForSEO) · {rows.length} keyword{rows.length === 1 ? "" : "s"} researched
      </p>
      {rows.map((r) => {
        const m = r.metrics;
        const sample = r.products.filter((p) => p.relevant && p.title).slice(0, 5);
        return (
          <div key={r.keyword} className="panel" style={{ marginBottom: 12, padding: "14px 16px" }}>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "baseline", marginBottom: 8 }}>
              <strong style={{ fontSize: 13 }}>{r.keyword}</strong>
              {r.selection && (
                <span style={{ fontSize: 11, color: "var(--muted)" }}>
                  selected because: {r.selection.reasons.join("; ")}
                </span>
              )}
            </div>
            {m.relevant_product_count === 0 ? (
              <p style={{ fontSize: 12, color: "var(--muted)", margin: 0 }}>Insufficient data — no relevant products found.</p>
            ) : (
              <>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 16, marginBottom: 10 }}>
                  <Metric label="Approx. results" value={r.results_count?.toLocaleString() ?? null} />
                  <Metric label="Relevant products" value={String(m.relevant_product_count)} />
                  <Metric label="Median price" value={money(m.median_price, r.products.find((p) => p.currency)?.currency ?? null)} />
                  <Metric label="Median rating" value={m.median_rating?.toFixed(1) ?? null} />
                  <Metric label="Median reviews" value={m.median_review_count?.toLocaleString() ?? null} />
                  <Metric label="Sponsored ratio" value={pct(m.paid_result_ratio)} />
                  <Metric label="Recent purchase activity" value={m.products_with_bought_past_month ? `${m.products_with_bought_past_month} products` : "0"} />
                  <Metric label="Amazon Choice" value={String(m.amazon_choice_count)} />
                  <Metric label="Best Seller" value={String(m.best_seller_count)} />
                  <Metric label="Strong competitors" value={pct(m.strong_competitor_ratio)} />
                </div>
                {sample.length > 0 && (
                  <div>
                    <div style={{ fontSize: 10, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.4, marginBottom: 4 }}>Sample competing products</div>
                    <ul style={{ margin: 0, paddingLeft: 18, fontSize: 12, color: "var(--muted)" }}>
                      {sample.map((p) => (
                        <li key={p.asin ?? p.title}>
                          {p.title}
                          {p.price !== null && ` — ${money(p.price, p.currency)}`}
                          {p.rating !== null && ` · ${p.rating}★ (${p.review_count ?? 0})`}
                          {(p.bought_past_month ?? 0) > 0 && ` · ${p.bought_past_month}+ bought last month`}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </>
            )}
          </div>
        );
      })}
    </div>
  );
}
