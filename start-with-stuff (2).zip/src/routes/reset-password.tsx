import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthCard";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Set a new password — NicheGap AI" },
      { name: "description", content: "Choose a new password for your NicheGap AI account." },
      { property: "og:title", content: "Set a new password — NicheGap AI" },
      { property: "og:description", content: "Choose a new password for your NicheGap AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) return setError(error.message);
    navigate({ to: "/dashboard" });
  }

  return (
    <AuthShell title="Set a new password" subtitle="Open this page from the link in your reset email.">
      <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div className="field-group">
          <label htmlFor="new-password">New password</label>
          <input id="new-password" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
        </div>
        {error && <p role="alert" style={{ color: "#ff9aaa", fontSize: 12, margin: 0 }}>{error}</p>}
        <button className="button button--primary button--large" disabled={busy} type="submit">
          {busy ? "Saving…" : "Update password"}
        </button>
      </form>
    </AuthShell>
  );
}
