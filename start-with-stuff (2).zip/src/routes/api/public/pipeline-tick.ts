// Background research worker endpoint, called by the database scheduler (pg_cron + pg_net).
// Auth: bearer token must match a server-only DB row that browsers cannot read.
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/pipeline-tick")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const m = /^Bearer ([A-Za-z0-9]+)$/.exec(request.headers.get("authorization") ?? "");
        const { verifyWorkerToken, processPipelineTick, recordWorkerHeartbeat } = await import("@/lib/nichegap/pipeline.server");
        if (!(await verifyWorkerToken(m?.[1] ?? null))) return new Response("Unauthorized", { status: 401 });
        let r: Awaited<ReturnType<typeof processPipelineTick>>;
        try { r = await processPipelineTick(); }
        catch (e) { console.error("pipeline tick crashed", e); await recordWorkerHeartbeat("error", { error: "tick crashed" }); return new Response("Worker error", { status: 500 }); }
        // No customer data in the response: counts only.
        return Response.json({ ok: true, jobs: r.jobs.length, reconciled: r.reconciled }, { headers: { "Cache-Control": "no-store" } });
      },
    },
  },
});
