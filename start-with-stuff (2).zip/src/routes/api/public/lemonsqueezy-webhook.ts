// Lemon Squeezy webhook. Every request must carry a valid X-Signature (HMAC of the raw body).
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/lemonsqueezy-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const raw = await request.text();
        if (raw.length > 512_000) return new Response("Too large", { status: 413 });
        const { handleWebhook } = await import("@/lib/nichegap/billing.server");
        const r = await handleWebhook(raw, request.headers.get("x-signature"));
        return Response.json({ ok: r.status === 200 }, { status: r.status, headers: { "Cache-Control": "no-store" } });
      },
    },
  },
});
