import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NicheGap — Find underserved product opportunities" },
      { name: "description", content: "NicheGap researches real search demand, marketplace competition and customer discussions to score product opportunities." },
      { property: "og:title", content: "NicheGap — Find underserved product opportunities" },
      { property: "og:description", content: "Real market evidence, deterministic scoring and evidence-checked analysis for your next product idea." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <div className="nj">
      <header className="nj-top">
        <Link to="/" className="nj-brand"><img src="/nichegap-icon.png" alt="" width={28} height={28} /><span>NicheGap</span></Link>
        <div className="nj-account"><Link to="/auth" className="button button--quiet button--small">Sign in</Link></div>
      </header>
      <main className="nj-main">
        <section className="nj-hero">
          <div className="nj-eyebrow">Real market evidence · NicheGap analysis · AI-assisted interpretation</div>
          <h1 className="nj-h1">Find underserved product opportunities</h1>
          <p className="nj-lead">NicheGap researches search demand, marketplace competition and real customer discussions, then scores the opportunity so you can decide with evidence.</p>
          <Link to="/dashboard" className="button button--primary nj-cta">Get started</Link>
        </section>
      </main>
    </div>
  );
}
