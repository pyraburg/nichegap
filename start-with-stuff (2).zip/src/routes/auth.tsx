import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AuthShell } from "@/components/AuthCard";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — NicheGap AI" },
      { name: "description", content: "Sign in or create your NicheGap AI account to run market research." },
      { property: "og:title", content: "Sign in — NicheGap AI" },
      { property: "og:description", content: "Sign in or create your NicheGap AI account." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

type Mode = "signin" | "signup" | "forgot";

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setInfo(null);
    try {
      if (mode === "signin") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      } else if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/research`, data: { full_name: fullName || null } },
        });
        if (error) throw error;
        if (data.session) navigate({ to: "/dashboard" });
        else setInfo("Check your email to confirm your account, then sign in.");
      } else {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`,
        });
        if (error) throw error;
        setInfo("If an account exists for that email, a reset link is on its way.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  }

  const titles: Record<Mode, [string, string]> = {
    signin: ["Welcome back", "Sign in to your research workspace."],
    signup: ["Create your account", "Start researching product opportunities."],
    forgot: ["Reset your password", "We'll email you a secure reset link."],
  };

  return (
    <AuthShell title={titles[mode][0]} subtitle={titles[mode][1]}>
      <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {mode === "signup" && (
          <div className="field-group">
            <label htmlFor="full-name">Full name (optional)</label>
            <input id="full-name" value={fullName} onChange={(e) => setFullName(e.target.value)} autoComplete="name" />
          </div>
        )}
        <div className="field-group">
          <label htmlFor="email">Email</label>
          <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
        </div>
        {mode !== "forgot" && (
          <div className="field-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "signup" ? "new-password" : "current-password"}
            />
          </div>
        )}
        {error && <p role="alert" style={{ color: "#ff9aaa", fontSize: 12, margin: 0 }}>{error}</p>}
        {info && <p style={{ color: "#9be8c2", fontSize: 12, margin: 0 }}>{info}</p>}
        <button className="button button--primary button--large" disabled={busy} type="submit">
          {busy ? "Please wait…" : mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}
        </button>
      </form>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 16, fontSize: 12 }}>
        {mode === "signin" ? (
          <>
            <button className="text-button" onClick={() => setMode("signup")}>Create an account</button>
            <button className="text-button" onClick={() => setMode("forgot")}>Forgot password?</button>
          </>
        ) : (
          <button className="text-button" onClick={() => setMode("signin")}>Back to sign in</button>
        )}
      </div>
      <p style={{ marginTop: 18, fontSize: 11, color: "var(--muted)" }}>
        <Link to="/">← Back to NicheGap</Link>
      </p>
    </AuthShell>
  );
}
