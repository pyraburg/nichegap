# Port NicheGap AI Desktop to a Lovable web app

Import the uploaded `nichegap-desktop.zip` (Electron + React desktop app) into this project as a web app, per the user's decisions:

- **Storage:** local in the browser (no accounts, no backend) — scans, favorites, and settings persist in browser storage, closest to the desktop app's local JSON file.
- **AI:** keep bring-your-own-key — Settings collects provider URL, model, and API key; requests are proxied through a server function so the key is never used directly from the page.
- **Hosted mode:** stripped out — no account connection, subscriptions, billing, or update checks.

## What gets ported

- The full UI: app shell (sidebar, topbar, toasts), Dashboard, New scan, Research library, Favorites, Settings, and Results views from `src/App.tsx` (1,017 lines), plus the app's custom stylesheet (`src/styles.css`, 540 lines) and icons from `resources/`.
- All local workflows: create scan, results view, favorites toggling, 30-day action plans, scan deletion, Markdown export (as a browser download), dashboard summary stats.
- Google-autocomplete keyword signals (the app's keyword enrichment feature).
- The scan prompt, scoring rules, and response-normalization logic from `electron/main.cjs` — reused verbatim in the server layer.

## What gets dropped

- Electron main process, preload, auto-updater, Windows packaging scripts, and the `dist/` build output.
- Hosted mode: account connection/polling, tRPC calls to the hosted server, entitlements, checkout/billing portal. The Settings view and sidebar show only the local (BYOK) mode.
- File-save dialog for export → replaced by a `.md` file download.

## Architecture

```text
src/
  lib/nichegap/
    types.ts          — ported from src/types/app.ts (minus hosted/billing types)
    store.ts          — localStorage data layer (settings, scans, favorites, dashboard summary)
                        implements the same operations the Electron main process owned
    ai.functions.ts   — createServerFn: runChatCompletion (BYOK proxy) + fetchKeywordSignals
    ai.server.ts      — provider call, prompt, JSON parsing, scoring (server-only helpers)
  routes/index.tsx    — the app (single workspace, state-based views as in the original)
  styles.css          — Tailwind base + appended NicheGap component styles
```

- The original app's `window.nichegap` API surface becomes a small client module (`store.ts` + server fns) with the same method signatures, so `App.tsx` ports nearly unchanged.
- `runChatCompletion` receives `{ providerBaseUrl, model, apiKey, messages, temperature }` from the client per request (key lives in browser storage, travels only over HTTPS, is used server-side, and is never logged or persisted server-side). Timeout + error handling mirror the Electron implementation.
- `fetchKeywordSignals` calls Google's public suggest endpoint server-side (avoids browser CORS) and classifies intent with the same rules.
- Views stay as internal state navigation (no new URL routes) — matches the original single-window UX.
- Head metadata on `/`: title/description/og for "NicheGap AI research desk". App icon from `resources/icon.png` becomes the favicon in `public/`.
- `lucide-react` is used heavily — install it if not already present.

## Implementation steps

1. Copy/normalize types and port the localStorage store (settings with API key, scan CRUD, favorites, dashboard summary — logic mirrored from `electron/main.cjs`).
2. Add the two server functions (BYOK chat completion proxy, keyword signals) with zod validation.
3. Port `App.tsx` and the stylesheet into the index route; wire navigation, toasts, and export-as-download; remove hosted/billing/update UI.
4. Update head metadata, favicon, and SEO tags on `/`.
5. Verify: build passes, then drive the running app with Playwright — dashboard renders, settings save a key, a scan flow runs end to end, favorites and export work.

## Notes

- The Settings "test connection" button goes through the server proxy (real request to the configured provider).
- No Lovable Cloud is needed: storage is browser-local and AI calls are BYOK.
