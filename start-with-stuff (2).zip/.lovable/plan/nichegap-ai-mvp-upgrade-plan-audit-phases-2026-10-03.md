# NicheGap AI — MVP upgrade plan (audit + phases)

## Audit: what exists today
- Web port of the desktop app: Dashboard, New scan, Library, Favorites, Results, Settings, one-page navigation.
- Data lives only in the browser (no accounts, no database).
- AI: user pastes their own provider key; one AI call invents 6 pain points with scores. This conflicts with the brief: scores and demand are AI-generated, not evidence-based.
- Real data: only free Google autocomplete keyword suggestions.
- Missing: accounts, database, credits, Stripe, cache, preview step, cost tracking, admin.

## Changes and why
- Replace browser storage + own-key mode with accounts and Lovable Cloud (brief requires accounts, credits, saved reports). Existing browser scans are dropped (they are AI-only, not evidence-based).
- AI moves to Lovable AI built-in (no keys exposed, usage cost logged per call), behind a provider layer so admins can switch provider/model later.
- Reuse: the dark UI, sidebar shell, cards, export-to-Markdown, autocomplete keyword fetcher.

## Phases
1. **Foundation** (start now): Lovable Cloud, email sign-up/login, profiles, roles table (admin), credit balances (monthly vs top-up), credit ledger, research queries/data cache, reports, AI usage + external API usage tables. Separate pages: /auth, /dashboard, /research, /reports, /reports/$id, /billing, /admin.
2. **Data provider layer**: modular providers (Google autocomplete now; DataForSEO and Apify plug in once keys are added). Each stores provider, query, raw data, timestamp, expiry, cost.
3. **Cache**: normalized query matching; reuse fresh data, mark stale.
4. **Preview**: free preview (sources, signal counts, themes) before "Generate Full Opportunity Report — 1 Credit".
5. **Pipeline + Opportunity Score**: cheap model for extraction/classification, stronger model for the report; deterministic score from collected evidence; report sections labelled Real data / Calculated / AI interpretation / AI recommendation.
6. **Credits**: reserve on start, finalize on success, release on failure; monthly first, then top-up; out-of-credits message with next refill date.
7. **Stripe**: $9.99/mo (10 credits) + configurable top-ups (5/$5.99, 15/$14.99, 40/$34.99); webhook-only crediting, idempotent events.
8. **Dashboard/mobile + Admin**: credits remaining, recent reports; admin view of cost per report, provider/model settings.

## Needs from you later
- DataForSEO and Apify API keys (phase 2), Stripe setup (phase 7).

## Technical notes
- Credit reserve/finalize via security-definer SQL functions; RLS on every table; roles in `user_roles` with `has_role`.
- AI via server functions with `requireSupabaseAuth`; tokens and estimated cost written to `ai_usage`.
